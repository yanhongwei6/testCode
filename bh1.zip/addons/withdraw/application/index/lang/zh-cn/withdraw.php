<?php
return [
    'Withdraw'         => '余额提现',
    'Withdraw money'   => '提现金额',
    'Withdraw type'    => '提现方式',
    'Withdraw now'     => '立即提现',
    'Withdraw log'     => '提现日志',
    'Withdraw account' => '收款账户',
    'Balance'          => '余额',
    'Current balance'  => '当前余额',
    'Operate date'     => '申请时间'
];