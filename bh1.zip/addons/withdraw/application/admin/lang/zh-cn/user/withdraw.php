<?php

return [
    'User_id'          => '会员ID',
    'Money'            => '金额',
    'Handingfee'       => '手续费',
    'Taxes'            => '税费',
    'Type'             => '类型',
    'Account'          => '提现账户',
    'Memo'             => '备注',
    'Status'           => '状态',
    'Status created'   => '申请中',
    'Status successed' => '成功',
    'Status rejected'  => '已拒绝',
    'Settledmoney'     => '最终到账',
    'Orderid'          => '订单号',
    'Transactionid'    => '流水号',
    'Createtime'       => '添加时间',
    'Updatetime'       => '更新时间',
    'Transfertime'     => '转账时间'
];
