<?php

return [
    'Id'          => 'ID',
    'User_id'     => '会员ID',
    'Successions' => '连续签到次数',
    'Createtime'  => '创建时间'
];
