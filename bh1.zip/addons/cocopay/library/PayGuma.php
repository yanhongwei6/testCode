<?php
namespace addons\cocopay\library;

use \addons\recharge\model\Order;
use think\config;

class PayGuma{
    var $url;
    var $orderinfo;
    var $setting; //支付接口配置信息
    public function __construct($orderinfo,$setting){
        $this->url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
        $this->orderinfo = $orderinfo;
        $this->setting = $setting;
    }

    public function basePay($payinfo){
        $orderinfo = $this->orderinfo;
        $return = [
            'type' => 'tmpl',
            'tmpl' => 'guma_'.$payinfo['payno'],
            'payinfo' => $payinfo,
            'orderinfo' => $orderinfo,
        ];
        return $return;
    }
    public function callback(){
        
    }
}