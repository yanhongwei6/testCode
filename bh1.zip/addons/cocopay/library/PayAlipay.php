<?php
namespace addons\cocopay\library;

use \addons\recharge\model\Order;
use think\config;

class PayAlipay{
    var $orderinfo;
    var $setting; //支付接口配置信息
    public function __construct($orderinfo,$setting){
        $this->url = "";
        $this->orderinfo = $orderinfo;
        $this->setting = $setting;
    }

    public function basePay($payinfo){
        require APP_PATH.'../addons/cocopay/library/aop/AopClient.php';
        require APP_PATH.'../addons/cocopay/library/aop/request/AlipayTradeAppPayRequest.php';

        $aop = new \AopClient();
        $aop->appId = $this->setting['appid'];
        $aop->rsaPrivateKey = $this->setting['privkey'];
        $aop->signType = 'RSA2';
        $aop->alipayrsaPublicKey = $this->setting['publickey'];
        $request = new \AlipayTradeAppPayRequest();
        $body = [
            'subject' => $this->orderinfo['memo'],
            'out_trade_no' => $this->orderinfo['ordersn'],
            'timeout_express' => '10m',
            'total_amount' => 0.01,//$this->orderinfo['money'],
            'product_code' => 'QUICK_MSECURITY_PAY',
        ];
        $bizcontent = json_encode($body);
        $request->setNotifyUrl(APP_URL."/addons/cocopay/pay/".$this->setting['tag']);
        $request->setBizContent($bizcontent);
        $result = $aop->sdkExecute($request);

        trace($result);

        $return = [
            'type' => 'Navite',
            'param' => ['data'=>$result,'payment'=>'alipay'],
        ];
        return $return;
    }
    public function callback(){
        require APP_PATH.'../addons/cocopay/library/aop/AopClient.php';
        $data = request()->post();
        $data['fund_bill_list'] = htmlspecialchars_decode($data['fund_bill_list']);
        $aop = new \AopClient;
        $aop->alipayrsaPublicKey = $this->setting['publickey'];
        $flag = $aop->rsaCheckV1($data, NULL, "RSA2");
        if($flag){
            Order::pay_success($data['out_trade_no'],$data['total_amount']);
            return "success";
        }
        else{
            return "fail";
        }
    }
}