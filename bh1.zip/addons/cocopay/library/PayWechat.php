<?php
namespace addons\cocopay\library;

use \addons\recharge\model\Order;
use think\config;

class PayWechat{
    var $appid;
    var $customno;
    var $customkey;
    var $url;
    var $orderinfo;
    var $setting; //支付接口配置信息
    public function __construct($orderinfo,$setting){
        $this->appid = $setting['appid'];
        $this->customno = $setting['customno'];
        $this->customkey = $setting['customkey'];
        $this->url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
        $this->orderinfo = $orderinfo;
        $this->setting = $setting;
    }

    public function basePay($payinfo){
        $orderinfo = $this->orderinfo;
        $amount = 1;//$orderinfo['money']*100;
        $payData = array(
            'appid' => $this->appid,
            'mch_id' => $this->customno,
            'nonce_str'  => (string)rand(100000,999999),
            'body'   => $orderinfo['memo'],
            'out_trade_no'  => $orderinfo['ordersn'],
            'total_fee'  => (string)$amount,
            'notify_url'=> APP_URL."/addons/cocopay/pay/".$this->setting['tag'],
            'trade_type'=> $payinfo['payno'],
            'spbill_create_ip'  => request()->ip(),
        );
        trace($payData);
        ksort($payData);
        $signstr = '';
        foreach($payData as $k => $v){
            $signstr .= $k."=".$v."&";
        }
        $signstr .= "key=".$this->customkey;
        trace($this->customkey);
        $payData['sign'] = strtoupper(md5($signstr));
        $result = $this->pay_post($this->url,$this->arrayToXml($payData));
        $results = $this->xmlToArray($result);
        trace($result);
        if($results['return_code'] == 'SUCCESS' && $results['return_msg'] == 'OK'){
            $params = ['appid'=>$results['appid'],'partnerid'=>$results['mch_id'],'prepayid'=>$results['prepay_id'],'package'=>'Sign=WXPay','noncestr'=>substr(strtoupper(md5(date('YmdHis').'feot')), 10, 16),'timestamp'=>time()];
            ksort($params);
            $paramstr = '';
            foreach ($params as $k => $v) {
                $paramstr .= $paramstr ? '&'.$k.'='.$v : $k.'='.$v;
            }
            $paramstr .= '&key='.$this->customkey;
            $params['sign'] = strtoupper(md5($paramstr));
            unset($params['appid']);
            $params['ordersn'] = $orderinfo['ordersn'];
            $params['payment'] = $payinfo['paytype'];

            $return = [
                'type' => 'Navite',
                'param' => $params,
            ];
        }
        else{
            $return = [
                'type' => 'error',
                'message' => $results['return_msg'],
            ];
        }
        return $return;
    }
    public function callback(){
        $param = file_get_contents("php://input");
        file_put_contents(ROOT_PATH."wechat.log", $param);
        $returnArr = $this->xmlToArray($param);

        $payData = array(
            'appid' => $this->appid,
            'mch_id' => $this->customno,
            'nonce_str'  => (string)rand(100000,999999),
            'transaction_id'   => $returnArr['transaction_id'],
        );
        ksort($payData);
        $signstr = '';
        foreach($payData as $k => $v){
            $signstr .= $k."=".$v."&";
        }
        $signstr .= "key=".$this->customkey;
        $payData['sign'] = strtoupper(md5($signstr));
        $url = "https://api.mch.weixin.qq.com/pay/orderquery";
        $result = $this->pay_post($url,$this->arrayToXml($payData));
        $arr = $this->xmlToArray($result);

        $return = [
            'return_code' => 'FAIL',
            'return_msg' => 'ERROR',
        ];
        trace($arr);
        if($arr['return_code'] == 'SUCCESS' && $arr['return_msg'] == 'OK'){
            Order::pay_success($arr['out_trade_no'],$arr['total_fee'] / 100);
            $return = [
                'return_code' => 'SUCCESS',
                'return_msg' => 'OK',
            ];
        }

        return $this->arrayToXml($return);
    }
    function arrayToXml($arr)  //数组转XML
    {
        $xml = "<xml>";
        foreach ($arr as $key=>$val)
        {
            if (is_numeric($val)){
                $xml.="<".$key.">".$val."</".$key.">";
            }else{
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
            }
        }
        $xml.="</xml>";
        return $xml;
    }
    function xmlToArray($xml) //XML转数组
    {
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $values;
    }
    function pay_post($url,$data,$timeout = 10){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        //设置header
        curl_setopt($ch, CURLOPT_HEADER, FALSE);

        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_TIMEOUT, (int)$timeout);
        $response=curl_exec($ch);
        $httpCode=curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $response;
    }
}