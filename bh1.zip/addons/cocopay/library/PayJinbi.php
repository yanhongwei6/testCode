<?php
namespace addons\cocopay\library;

use \addons\recharge\model\Order;
use think\config;
use app\common\model\User;

class PayJinbi{
    var $orderinfo;
    var $setting; //支付接口配置信息
    public function __construct($orderinfo,$setting){
        $this->url = "";
        $this->orderinfo = $orderinfo;
        $this->setting = $setting;
    }

    public function basePay($payinfo){
        $orderinfo = $this->orderinfo;
        $amount = $orderinfo['money'];
        
        $user_id = $orderinfo['user_id'];
        $user_money = User::where("id",$user_id)->value("score");

        if($amount > $user_money){
            $return = [
                'type' => 'error',
                'message' => '金币不足',
            ];
        }
        else{
            User::score((0-$amount),$user_id,$orderinfo['memo']);
            Order::pay_success($orderinfo['ordersn'],$amount);
            $return = [
                'type' => 'success',
                'message' => '支付成功',
            ];
        }
        return $return;
    }
}