<?php
namespace addons\cocopay\controller;

use app\common\controller\Api;
use app\admin\model\Paytype as PayModel;
use app\admin\model\Payinfo as InfoModel;
/**
 * 第三方支付插件
 */
class Pay extends Api
{
    protected $noNeedLogin = ['*'];

    public function _initialize(){
        parent::_initialize();
    }
    public function _empty($name){
        $tag = $name;
        $setting = PayModel::where('tag',$tag)->find();
        $classname = "\addons\cocopay\library\Pay".ucwords($setting['codetag']);
        $model = new $classname([],$setting);
        echo $model->callback();exit;
    }
}
