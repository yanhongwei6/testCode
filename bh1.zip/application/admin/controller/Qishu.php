<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use redis\Redis;
use app\index\server\gateway\Client;
/**
 * 期数列管理
 *
 * @icon fa fa-circle-o
 */
class Qishu extends Backend
{
    
    /**
     * Qishu模型对象
     * @var \app\admin\model\Qishu
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\Qishu;

    }
     /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax())
        {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField'))
            {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                    ->with('game')
                    ->where($where)
                    ->order($sort, $order)
                    ->count();

            $list = $this->model
                    ->with('game')
                    ->where($where)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();
            foreach ($list as $key => $row) {
                $row->getRelation('game')->visible(['name']);
            }
            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);
            $field = 'SUM(bettotal) as betall,SUM(winlos) as winall';
            $result['extend'] = $this->model->where($where)->field($field)->find();
            return json($result);
        }
        return $this->view->fetch();
    }
    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    public function senumber($ids = null){
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $config = config('redis');
        $redis = new Redis($config);
        $list = json_decode($redis->get('user_bets_record_list'),true) ?: [];
        $betall = 0;
        $bettype = [];
        foreach ($list as $k => $v) {
            $betall += $v['bets'];
            if (isset($bettype[$v['playtype']])) {
                $bettype[$v['playtype']] += $v['bets'];
            }else{
                $bettype[$v['playtype']] = $v['bets'];
            }
        }
        $row->number = explode(',', $row->number);
        $data = [
            'betall' => $betall,
            'bettype' => $bettype,
            'gname' => \app\admin\model\Game::getGameName($row->game)
        ];
        $type = \app\admin\model\Game::getGameSign($row->game);
        
        switch ($redis->get($type."_status")) {
            case 2:
                $disable = '';
                break;
            default:
                $disable = 'disabled';
                break;
        }
        $this->assign('disabled',$disable);
        $this->assign('sign',$type);
        $this->assign('row',$row);
        $this->assign('data',$data);
        return $this->view->fetch();
    }
    /**
     * 绑定推送团组
     */
    public function bind(){
        $user_id = $this->auth->id;
        $client_id = $this->request->request('client_id');
        $group_id = $this->request->request('room');
        Client::bindUid($client_id,$user_id,'admin_'.$group_id,'packet',1,1);
        $this->success('绑定ID：'.$this->auth->id);
    }
    /**
     * 设置开奖号
     */
    public function setOpenNumber(){
        $param = $this->request->param();
        $openNumber = isset($param['number']) ? $param['number'] : [];
        $gameId = $param['gname'];
        $issue = $param['issue'];
        $gameSign = \app\admin\model\Game::getGameSign($gameId);
        if (empty($gameSign)) {
            $gameSign = 'ffc';
        }
        $where['issue'] = $issue;
        $where['game'] = $gameId;
        $field = 'is_now,number,opentime';
        $info = \app\admin\model\Qishu::where($where)->field($field)->find();
        if (empty($info)) {
            $this->error(__('No Results were found'));
        }
        if ($info['is_now'] == 'no') {
            $this->error(__('不是当期开奖，不允许设置开奖号'));
        }
        if ($info['number'] && $info['opentime']) {
            $this->error(__('当期已开奖'));
        }
        try {
            $number = implode(',', $openNumber);
            $data['number'] = $number;
            $data['opentime'] = time();
            $result = \app\admin\model\Qishu::where($where)->update($data);
            if ($result) {
                $this->success('设置成功');
            }else{
                $this->error('网络错误');
            }
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }
}
