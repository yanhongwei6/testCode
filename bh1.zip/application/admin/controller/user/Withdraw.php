<?php

namespace app\admin\controller\user;

use app\common\controller\Backend;

/**
 * 提现管理
 *
 * @icon fa fa-circle-o
 */
class Withdraw extends Backend
{
    
    /**
     * Withdraw模型对象
     * @var \app\admin\model\user\Withdraw
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\user\Withdraw;
        $this->view->assign("statusList", $this->model->getStatusList());
    }
    
    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    

    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax())
        {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField'))
            {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                    ->with(['user','admin','withdrawtype'])
                    ->where($where)
                    ->order($sort, $order)
                    ->count();

            $list = $this->model
                    ->with(['user','admin','withdrawtype'])
                    ->where($where)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();

            foreach ($list as $row) {
                $row->audittime = date('Y-m-d H:i',$row->audittime);
                $row->freezingtime = date('Y-m-d H:i',$row->freezingtime);
                $row->updatetime = date('Y-m-d H:i',$row->updatetime);
                $row->forzer = \app\admin\model\Admin::getAdminNickname($row->forzer);
                $row->thawer = \app\admin\model\Admin::getAdminNickname($row->thawer);
                $row->getRelation('user')->visible(['nickname']);
				$row->getRelation('admin')->visible(['nickname']);
            }
            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);
            $field = 'SUM(money) as total,status';
            $extends = $this->model->where($where)->field($field)->group('status')->select();
            $created = 0;
            $successed = 0;
            $forzen = 0;
            $complete = 0;
            $rejected = 0;
            foreach ($extends as $k => $v) {
                switch ($v['status']) {
                    case 'created':
                        $created = $v['total'];
                        break;
                    case 'successed':
                        $successed = $v['total'];
                        break;
                    case 'forzen':
                        $forzen = $v['total'];
                        break;
                    case 'complete':
                        $complete = $v['total'];
                        break;
                    case 'rejected':
                        $rejected = $v['total'];
                        break;
                }
            }
            $field = 'SUM(money) as allmoney,SUM(handingfee) as handall,SUM(taxes) as taxesall';
            $result['counts'] = $this->model->where($where)->field($field)->find();
            $data = [
                'created' => $created,
                'successed' => $successed,
                'forzen' => $forzen,
                'complete' => $complete,
                'rejected' => $rejected
            ];
            $result['extend'] = $data;
            return json($result);
        }
        return $this->view->fetch();
    }
    /**
     * 提现审核
     */
    public function cash_auditor(){
        $id = $this->request->request('id');
        $type = $this->request->request('type');
        if (!$id) $this->error('修改信息错误');
        $orderinfo = $this->model->where('id',$id)->find();
        if (empty($orderinfo)) $this->error('订单信息不存在');
        switch ($type) {
            case 'pass':
                if ($orderinfo->status != 'created') $this->error('订单状态信息错误');
                break;
            case 'frozen':
                if ($orderinfo->status != 'successed') $this->error('订单状态信息错误');
                break;
            case 'complete':
                if ($orderinfo->status != 'forzen') $this->error('订单状态信息错误');
                break;
            default:
                if ($orderinfo->status != 'created') $this->error('订单状态信息错误');
                break;
        }
        $funName = $type.'Server';
        $result = \app\admin\model\user\Withdraw::$funName($orderinfo,$this->auth->id);
        if ($result['errcode']) {
            $this->success($result['errmsg']);
        }
        $this->error($result['errmsg']);
    }
}
