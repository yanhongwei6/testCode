<?php

return [
    'Userid'         => '用户ID',
    'Truename'       => '真实姓名',
    'Number'         => '银行卡号',
    'Address'        => '办卡网点',
    'Phone'          => '银行预留手机号',
    'Status'         => '状态',
    'Status created' => '待审核',
    'Status pass'    => '通过',
    'Status refuse'  => '拒绝',
    'Remark'         => '备注',
    'Createtime'     => '申请时间',
    'Updatetime'     => '审核时间',
    'User.nickname'  => '昵称'
];
