<?php

return [
    'Userid'           => '用户',
    'Truename'         => '真实姓名',
    'Birthday'         => '出生年月',
    'Card_front_image' => '身份证正面',
    'Card_back_image'  => '身份证反面',
    'Alipay'           => '支付宝账号',
    'Wechat'           => '微信账号',
    'Bank_status'      => '银行卡',
    'Remark'           => '备注',
    'Status'           => '状态',
    'Status created'   => '待审核',
    'Status succeed'   => '审核通过',
    'Status refuse'    => '拒绝',
    'Createtime'       => '创建时间',
    'Updatetime'       => '更新时间',
    'User.nickname'    => '昵称'
];
