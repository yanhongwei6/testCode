<?php

return [
    'Start_issue'   => '抢庄期期号',
    'End_issue'     => '下庄期期号',
    'Userid'        => '用户ID',
    'Game'          => '游戏',
    'Money'         => '抢庄金额',
    'Number'        => '连庄次数',
    'Rushtime'      => '抢庄时间',
    'Endtime'       => '下庄时间',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'User.id'       => 'ID',
    'User.username' => '用户名',
    'User.nickname' => '昵称',
    'Game.name'     => '游戏名称'
];
