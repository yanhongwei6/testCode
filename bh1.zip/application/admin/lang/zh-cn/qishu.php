<?php

return [
    'Issue'      => '期数',
    'Game'       => '游戏ID',
    'Number'     => '开奖号',
    'Is_now'     => '是否当期',
    'Is_now yes' => '是',
    'Is_now no'  => '否',
    'Bettotal'   => '投注总金额',
    'Winlos'     => '输赢金额',
    'Opentime'   => '开奖时间',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
