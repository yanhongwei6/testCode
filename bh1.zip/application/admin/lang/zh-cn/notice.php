<?php

return [
    'Title'         => '活动标题',
    'Content'       => '活动内容',
    'Banner'        => '活动图片',
    'Url'           => '跳转地址',
    'Status'        => '状态',
    'Status normal' => '正常',
    'Status hidden' => '屏蔽',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间'
];
