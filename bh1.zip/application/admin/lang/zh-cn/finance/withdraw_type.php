<?php

return [
    'Name'          => '提现名称',
    'Sign'          => '提现标识',
    'Description'   => '描述',
    'Image'         => '提现方式图',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Status'        => '状态',
    'Status normal' => '启用',
    'Status hidden' => '屏蔽'
];
