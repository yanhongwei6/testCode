<?php

return [
    'Userid'        => '用户',
    'Issue'         => '期号',
    'Gameid'        => '上庄游戏',
    'Money'         => '上庄积分',
    'Number'        => '连庄次数',
    'Createtime'    => '上庄时间',
    'Updatetime'    => '更新时间',
    'User.id'       => 'ID',
    'User.nickname' => '昵称',
    'Game.name'     => '游戏名称'
];
