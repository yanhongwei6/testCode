<?php

return [
    'Name'          => '游戏名称',
    'Sign'          => '游戏标识',
    'Url'           => '前台地址',
    'Log_image'     => '游戏LOGO',
    'Rule_content'  => '游戏规则',
    'Intro_content' => '游戏介绍',
    'Status'        => '启用状态',
    'Status normal' => '正常',
    'Status hidden' => '停用',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Timesting'     => '单局时间【秒】',
];
