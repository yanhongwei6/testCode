<?php

namespace app\admin\model\user;

use think\Model;
use think\Db;

class Withdraw extends Model
{

    

    

    // 表名
    protected $name = 'withdraw';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'status_text',
        'transfertime_text'
    ];
    

    
    public function getStatusList()
    {
        return ['created' => __('Status created'), 'successed' => __('Status successed'), 'forzen' => __('Status frozen'), 'complete' => __('Status complete'), 'rejected' => __('Status rejected')];
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getTransfertimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['transfertime']) ? $data['transfertime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setTransfertimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


    public function user()
    {
        return $this->belongsTo('app\admin\model\User', 'user_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }


    public function admin()
    {
        return $this->belongsTo('app\admin\model\Admin', 'auditor', 'id', [], 'LEFT')->setEagerlyType(0);
    }


    public function withdrawtype()
    {
        return $this->belongsTo('app\admin\model\finance\WithdrawType', 'type', 'sign', [], 'LEFT')->setEagerlyType(0);
    }
    /**
     * 审核通过
     * @param $orderinfo object 订单详情
     * @param $adminid int 管理员ID
     */
    public static function passServer($orderinfo,$adminid){
        $memo = "审核通过";
        $orderinfo->memo = $memo;
        $orderinfo->status = 'successed';
        $orderinfo->audittime = time();
        $orderinfo->auditor = $adminid;
        Db::startTrans();
        try {
            $result = $orderinfo->save();
            if ($result) {
                Db::commit();
                return ['errcode'=>1,'errmsg'=>'操作成功'];
            }
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>'操作失败'];
        } catch (Exception $e) {
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>$e->getMessage()];
        }
    }
    /**
     * 冻结资金
     * @param $orderinfo object 订单详情
     * @param $adminid int 管理员ID
     */
    public static function frozenServer($orderinfo,$adminid){
        $memo = "资金冻结";
        $orderinfo->memo = $memo;
        $orderinfo->status = 'forzen';
        $orderinfo->freezingtime = time();
        $orderinfo->forzer = $adminid;
        Db::startTrans();
        try {
            $result = $orderinfo->save();
            if ($result) {
                Db::commit();
                return ['errcode'=>1,'errmsg'=>'操作成功'];
            }
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>'操作失败'];
        } catch (Exception $e) {
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>$e->getMessage()];
        }
    }
    /**
     * 资金解冻
     * @param $orderinfo object 订单详情
     * @param $adminid int 管理员id
     */
    public static function completeServer($orderinfo,$adminid){
        $orderid = date('YmdHis'). sprintf("%02d", $adminid) . mt_rand(1000, 9999);
        $memo = "资金解冻完成";
        $orderinfo->memo = $memo;
        $orderinfo->status = 'complete';
        $orderinfo->transactionid = $orderid;
        $orderinfo->transfertime = time();
        $orderinfo->handingfee = $orderinfo->money*config('site.withdraw_handingfee')/100;
        $orderinfo->taxes = $orderinfo->money*config('site.withdraw_taxes')/100;
        $orderinfo->thawer = $adminid;
        Db::startTrans();
        try {
            $result = $orderinfo->save();
            if ($result) {
                \app\common\model\User::money(-$orderinfo->money, $orderinfo->user_id, "提现");
                Db::commit();
                return ['errcode'=>1,'errmsg'=>'操作成功'];
            }
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>'操作失败'];
        } catch (Exception $e) {
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>$e->getMessage()];
        }
    }
    /**
     * 拒绝审核
     * @param $orderinfo object 订单详情
     * @param $adminid int 管理员ID
     */
    public static function refuseServer($orderinfo,$adminid){
        $reason = request()->param('remark') ?: "管理员拒绝提现申请";
        $orderinfo->memo = $reason;
        $orderinfo->status = 'rejected';
        $orderinfo->updatetime = time();
        $orderinfo->auditor = $adminid;
        Db::startTrans();
        try {
            $result = $orderinfo->save();
            if ($result) {
                //用户资金回退
                \app\common\model\User::where('id',$orderinfo->user_id)->setInc('money',$orderinfo->money);
                Db::commit();
                return ['errcode'=>1,'errmsg'=>'操作成功'];
            }
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>'操作失败'];
        } catch (Exception $e) {
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>$e->getMessage()];
        }

    }
    
}
