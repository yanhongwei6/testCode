<?php

namespace app\admin\model\finance;

use think\Model;

class Paytype extends Model
{
    // 表名
    protected $name = 'paytype';
    
}
