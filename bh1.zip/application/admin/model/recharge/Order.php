<?php

namespace app\admin\model\recharge;
use \addons\recharge\model\Order as Orderpay;
use think\Model;
use think\Db;

class Order extends Model
{

    

    

    // 表名
    protected $name = 'recharge_order';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'paytime_text',
        'status_text'
    ];
    

    
    public function getStatusList()
    {
        return ['created' => __('Status created'), 'paid' => __('Status paid'), 'refuse' => __('Status refuse'), 'expired' => __('Status expired')];
    }


    public function getPaytimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['paytime']) ? $data['paytime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    protected function setPaytimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


    public function user()
    {
        return $this->belongsTo('app\admin\model\User', 'user_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
    public function admin()
    {
        return $this->belongsTo('app\admin\model\Admin', 'auditor', 'id', [], 'LEFT')->setEagerlyType(0);
    }
    public function payinfo()
    {
        return $this->belongsTo('app\admin\model\finance\Payinfo', 'paytype', 'id', [], 'LEFT')->setEagerlyType(0);
    }
    /**
     * 修改订单支付成功状态
     * $orderinfo 订单详情信息
     */
    public static function paid_server($orderinfo,$adminid){
        Db::startTrans();
        try {
            $result = Orderpay::pay_success($orderinfo->orderid,$orderinfo->amount,'充值成功',$adminid);
            if ($result) {
                Db::commit();
                return ['errcode'=>1,'errmsg'=>'操作成功'];
            }
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>'操作失败'];
        } catch (Exception $e) {
            Db::rollback();
            return ['errcode'=>0,'errmsg'=>$e->getMessage()];
        }
    }
    /**
     * 修改订单支付失败状态
     * $orderinfo 订单详情信息
     */
    public static function refuse_server($orderinfo,$adminid){
        $memo = request()->param('remark') ?: '充值申请被拒绝';
        $orderinfo->status = 'refuse';
        $orderinfo->memo = $memo;
        $orderinfo->auditor = $adminid;
        $orderinfo->updatetime = time();
        $result = $orderinfo->save();
        if ($result) {
            return ['errcode'=>1,'errmsg'=>'操作成功'];
        }
        return ['errcode'=>0,'errmsg'=>'操作失败'];
    }
    /**
     * 修改订单为过期订单
     * @param $orderinfo 订单详情信息
     */
    public static function expired_server($orderinfo,$adminid){
        $memo = '充值订单已过期';
        $orderinfo->status = 'expired';
        $orderinfo->memo = $memo;
        $orderinfo->auditor = $adminid;
        $orderinfo->updatetime = time();
        $result = $orderinfo->save();
        if ($result) {
            return ['errcode'=>1,'errmsg'=>'操作成功'];
        }
        return ['errcode'=>0,'errmsg'=>'操作失败'];
    }
}
