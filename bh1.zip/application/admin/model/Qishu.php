<?php

namespace app\admin\model;

use think\Model;


class Qishu extends Model
{

    

    

    // 表名
    protected $name = 'qishu';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'opentime_text',
        'is_now_text'
    ];
    

    

    public function getIsNowList(){
        return ['yes' => __('Is_now yes'), 'no' => __('Is_now no')];
    }

    public function getOpentimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['opentime']) ? $data['opentime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setOpentimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }
    public function getIsNowTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_now']) ? $data['is_now'] : '');
        $list = $this->getIsNowList();
        return isset($list[$value]) ? $list[$value] : '';
    }
    public function game()
    {
        return $this->belongsTo('Game', 'game', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
