<?php

namespace app\admin\model\user;

use think\Model;

class WithdrawType extends Model
{
    // 表名
    protected $name = 'withdraw_type';
    
}
