<?php

namespace app\admin\model;

use think\Model;


class Bets extends Model
{

    

    

    // 表名
    protected $name = 'bets';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'bettime_text',
        'opentime_text',
        'settledtime_text',
        'playtype_text',
        'winlose_text',
        'status_text'
    ];
       
    public function getPlaytypeList()
    {

        return ['large' => __('Playtype large'),'little' => __('Playtype little'),' leopard' => __('Playtype leopard')];
    }

    public function getWinloseList()
    {
        return ['win'=>__('Winlose win'),'lose'=>__('Winlose lose'),'draw'=>__('Winlose draw')];
    }
    public function getStatusList()
    {
        return ['wait'=>__('Status wait'),'settlement'=>__('Status settlement'),'settled'=>__('Status settled')];
    }
    public function getPlaytypeTextAttr($value, $data)
    {        
        $value = $value ? $value : (isset($data['playtype']) ? $data['playtype'] : '');
        $list = $this->getPlaytypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getWinloseTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['winlose']) ? $data['winlose'] : '');
        $list = $this->getPlaytypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getStatusTextAttr($value,$data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getPlaytypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getBettimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['bettime']) ? $data['bettime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getOpentimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['opentime']) ? $data['opentime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getSettledtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['settledtime']) ? $data['settledtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setBettimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setOpentimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setSettledtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


    public function user()
    {
        return $this->belongsTo('User', 'userid', 'id', [], 'LEFT')->setEagerlyType(0);
    }
     public function game()
    {
        return $this->belongsTo('Game', 'game', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
