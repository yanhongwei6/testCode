<?php

namespace app\admin\model\finance;

use think\Model;


class Payinfo extends Model
{

    

    

    // 表名
    protected $name = 'payinfo';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'paytype_text',
        'ispc_text',
        'iswap_text',
        'subtype_text',
        'banktype_text',
        'status_text'
    ];
    

    protected static function init()
    {
        self::afterInsert(function ($row) {
            $pk = $row->getPk();
            $row->getQuery()->where($pk, $row[$pk])->update(['weigh' => $row[$pk]]);
        });
    }

    
    public function getPaytypeList()
    {
        return ['1' => __('Paytype 1'), '2' => __('Paytype 2'), '3' => __('Paytype 3'), '4' => __('Paytype 4'), '5' => __('Paytype 5'), '6' => __('Paytype 6')];
    }

    public function getIspcList()
    {
        return ['0' => __('Ispc 0'), '1' => __('Ispc 1')];
    }

    public function getIswapList()
    {
        return ['0' => __('Iswap 0'), '1' => __('Iswap 1')];
    }

    public function getSubtypeList()
    {
        return ['1' => __('Subtype 1'), '2' => __('Subtype 2'), '3' => __('Subtype 3')];
    }

    public function getBanktypeList()
    {
        return ['0' => __('Banktype 0'), '1' => __('Banktype 1'), '2' => __('Banktype 2'), '3' => __('Banktype 3')];
    }

    public function getStatusList()
    {
        return ['0' => __('Status 0'), '1' => __('Status 1')];
    }


    public function getPaytypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['paytype']) ? $data['paytype'] : '');
        $list = $this->getPaytypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getIspcTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ispc']) ? $data['ispc'] : '');
        $list = $this->getIspcList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getIswapTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['iswap']) ? $data['iswap'] : '');
        $list = $this->getIswapList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getSubtypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['subtype']) ? $data['subtype'] : '');
        $list = $this->getSubtypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getBanktypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['banktype']) ? $data['banktype'] : '');
        $list = $this->getBanktypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function paytype()
    {
        return $this->belongsTo('app\admin\model\finance\Paytype', 'pid', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
