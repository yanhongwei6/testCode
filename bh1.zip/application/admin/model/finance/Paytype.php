<?php

namespace app\admin\model\finance;

use think\Model;


class Paytype extends Model
{

    

    

    // 表名
    protected $name = 'paytype';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'rsatype_text',
        'point_status_text',
        'recom_status_text',
        'status_text'
    ];
    

    protected static function init()
    {
        self::afterInsert(function ($row) {
            $pk = $row->getPk();
            $row->getQuery()->where($pk, $row[$pk])->update(['weigh' => $row[$pk]]);
        });
    }

    
    public function getRsatypeList()
    {
        return ['0' => __('Rsatype 0'), '1' => __('Rsatype 1'), '2' => __('Rsatype 2')];
    }

    public function getPointStatusList()
    {
        return ['0' => __('Point_status 0'), '1' => __('Point_status 1')];
    }

    public function getRecomStatusList()
    {
        return ['0' => __('Recom_status 0'), '1' => __('Recom_status 1')];
    }

    public function getStatusList()
    {
        return ['1' => __('Status 1'), '0' => __('Status 0')];
    }


    public function getRsatypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['rsatype']) ? $data['rsatype'] : '');
        $list = $this->getRsatypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPointStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['point_status']) ? $data['point_status'] : '');
        $list = $this->getPointStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getRecomStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['recom_status']) ? $data['recom_status'] : '');
        $list = $this->getRecomStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
