<?php

namespace app\api\controller;

use app\common\controller\Api;
use redis\Redis;
use think\Validate;
use app\common\library\exception\Exception;
use think\Db;
use addons\recharge\model\MoneyLog;
/**
 * 首页接口
 */
class Withdraw extends Api
{
    protected $noNeedLogin = [''];
    protected $noNeedRight = ['*'];
    /**
     * 提现操作
     */
    public function cashChannel()
    {
        $cashtype = $this->request->request('cashtype');
        $bankinfo = $this->request->request('bankinfo');
        $cashprice = $this->request->request('cash_money');
        $token = $this->request->post('__token__');
        
        $typeArr = ['alipay','wechat','bank'];
        if (!in_array($cashtype, $typeArr)) throw new Exception("提现信息有误，请刷新后重试~", 0);
        if (empty($cashprice)) throw new Exception("提现金额不正确", 0);

        $config = get_addon_config('withdraw');
        if (isset($config['minmoney']) && $cashprice < $config['minmoney']) {
            $this->error('提现金额不能低于' . $config['minmoney'] . '元');
        }
        if ($config['monthlimit']) {
            $count = \addons\withdraw\model\Withdraw::where('user_id', $this->auth->id)->whereTime('createtime', 'month')->count();
            if ($count >= $config['monthlimit']) {
                $this->error("已达到本月最大可提现次数");
            }
        }
        $userid = $this->auth->id;
        $config = config('redis');
        $redis = new Redis($config);
        $useBetMoney = 0;
        $list = json_decode($redis->get('user_bets_record_list'),true) ?: [];
        foreach ($list as $k => $v) {
            if ($v['userid'] == $userid) {
                $useBetMoney += $v['bets'];
            }
        }
        if ($this->auth->money - $useBetMoney < $cashprice) {
            throw new Exception("提现余额不足", 0);
        }
        if ($cashtype == 'bank') {
            $bankdata = \app\common\model\Banklist::where('id',$bankinfo)->field('truename,number')->find();
            if (!is_numeric($bankinfo)||empty($bankdata)) {
                throw new Exception("提现信息有误，请刷新后重试~", 0);
            }
            $data['account'] = $bankdata->number;
            $data['truename'] = $bankdata->truename;

        }else{
            $authinfo = \app\common\model\UserAuth::where('userid',$userid)->field('truename,alipay,wechat')->find();
            $data['truename'] = $authinfo->truename;
            $data['account'] = ($cashtype == 'wechat') ? $authinfo->wechat : $authinfo->alipay;
        }
        //验证Token
        if (!Validate::is($token, "token", ['__token__' => $token])) {
            $this->error("网络超时，请刷新后重试！", '', ['__token__' => $this->request->token()]);
        }
         //刷新Token
        $this->request->token();
        Db::startTrans();
        try {
            $orderid = date("Ymdhis") . sprintf("%08d", $this->auth->id) . mt_rand(1000, 9999);
            $data['user_id'] = $userid;
            $data['money'] = $cashprice;
            $data['type'] = $cashtype;
            $data['orderid'] = $orderid;
            $data['status'] = 'created';
            $data['createtime'] = time();
            \addons\withdraw\model\Withdraw::create($data);
            \app\common\model\User::money(-$cashprice, $this->auth->id, "提现");
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        $this->success("提现申请成功！请等待后台审核！", url("index/center/ddcenter?targe=1"));
        return;
    }
}
