<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\Ems;
use app\common\library\Sms;
use fast\Random;
use think\Validate;
use app\common\library\exception\Exception;
/**
 * 会员接口
 */
class User extends Api
{
    protected $noNeedLogin = ['login', 'mobilelogin', 'register', 'resetpwd', 'changeemail', 'changemobile', 'third'];
    protected $noNeedRight = '*';

    public function _initialize()
    {
        parent::_initialize();
    }

    /**
     * 会员中心
     */
    public function index()
    {
        $this->success('', ['welcome' => $this->auth->nickname]);
    }

    /**
     * 会员登录
     *
     * @param string $account  账号
     * @param string $password 密码
     */
    public function login()
    {
        $account = $this->request->request('account');
        $password = $this->request->request('password');
        if (!$account || !$password) {
            $this->error(__('Invalid parameters'));
        }
        $ret = $this->auth->login($account, $password);
        if ($ret) {
            $data = ['userinfo' => $this->auth->getUserinfo()];
            $this->success(__('Logged in successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }

    /**
     * 手机验证码登录
     *
     * @param string $mobile  手机号
     * @param string $captcha 验证码
     */
    public function mobilelogin()
    {
        $mobile = $this->request->request('mobile');
        $captcha = $this->request->request('captcha');
        if (!$mobile || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        if (!Sms::check($mobile, $captcha, 'mobilelogin')) {
            $this->error(__('Captcha is incorrect'));
        }
        $user = \app\common\model\User::getByMobile($mobile);
        if ($user) {
            if ($user->status != 'normal') {
                $this->error(__('Account is locked'));
            }
            //如果已经有账号则直接登录
            $ret = $this->auth->direct($user->id);
        } else {
            $ret = $this->auth->register($mobile, Random::alnum(), '', $mobile, []);
        }
        if ($ret) {
            Sms::flush($mobile, 'mobilelogin');
            $data = ['userinfo' => $this->auth->getUserinfo()];
            $this->success(__('Logged in successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }

    /**
     * 注册会员
     *
     * @param string $username 用户名
     * @param string $password 密码
     * @param string $email    邮箱
     * @param string $mobile   手机号
     * @param string $code   验证码
     */
    public function register()
    {
        $username = $this->request->request('username');
        $password = $this->request->request('password');
        $email = $this->request->request('email');
        $mobile = $this->request->request('mobile');
        $code = $this->request->request('code');
        if (!$username || !$password) {
            $this->error(__('Invalid parameters'));
        }
        if ($email && !Validate::is($email, "email")) {
            $this->error(__('Email is incorrect'));
        }
        if ($mobile && !Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        $ret = Sms::check($mobile, $code, 'register');
        if (!$ret) {
            $this->error(__('Captcha is incorrect'));
        }
        $ret = $this->auth->register($username, $password, $email, $mobile, []);
        if ($ret) {
            $data = ['userinfo' => $this->auth->getUserinfo()];
            $this->success(__('Sign up successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }

    /**
     * 注销登录
     */
    public function logout()
    {
        $this->auth->logout();
        $this->success(__('Logout successful'));
    }

    /**
     * 修改会员个人信息
     *
     * @param string $avatar   头像地址
     * @param string $username 用户名
     * @param string $nickname 昵称
     * @param string $bio      个人简介
     */
    public function profile()
    {
        $user = $this->auth->getUser();
        $nickname = $this->request->request('nickname');
        $bio = $this->request->request('bio');
        $mobile = $this->request->request('mobile');
        $email = $this->request->request('email');
        $gender = $this->request->request('gender');
        $avatar = $this->request->request('avatar', '', 'trim,strip_tags,htmlspecialchars');
        if (!$nickname) throw new Exception("请输入用户昵称", 0);
        if (!$mobile) throw new Exception("请输手机号码", 0);
        $reg = config('site.mobile_reg');
        if (!preg_match($reg, $mobile)) {
            throw new Exception("手机号码格式错误", 0);
        }
        if (!$email) throw new Exception("请输入电子邮箱", 0);
        $user->nickname = $nickname;
        $user->bio = $bio;
        $user->avatar = $avatar;
        $user->mobile = $mobile;
        $user->email = $email;
        $user->gender = $gender;
        $user->save();
        $this->success('修改成功');
    }

    /**
     * 修改邮箱
     *
     * @param string $email   邮箱
     * @param string $captcha 验证码
     */
    public function changeemail()
    {
        $user = $this->auth->getUser();
        $email = $this->request->post('email');
        $captcha = $this->request->request('captcha');
        if (!$email || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::is($email, "email")) {
            $this->error(__('Email is incorrect'));
        }
        if (\app\common\model\User::where('email', $email)->where('id', '<>', $user->id)->find()) {
            $this->error(__('Email already exists'));
        }
        $result = Ems::check($email, $captcha, 'changeemail');
        if (!$result) {
            $this->error(__('Captcha is incorrect'));
        }
        $verification = $user->verification;
        $verification->email = 1;
        $user->verification = $verification;
        $user->email = $email;
        $user->save();

        Ems::flush($email, 'changeemail');
        $this->success();
    }

    /**
     * 修改手机号
     *
     * @param string $email   手机号
     * @param string $captcha 验证码
     */
    public function changemobile()
    {
        $user = $this->auth->getUser();
        $mobile = $this->request->request('mobile');
        $captcha = $this->request->request('captcha');
        if (!$mobile || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        if (\app\common\model\User::where('mobile', $mobile)->where('id', '<>', $user->id)->find()) {
            $this->error(__('Mobile already exists'));
        }
        $result = Sms::check($mobile, $captcha, 'changemobile');
        if (!$result) {
            $this->error(__('Captcha is incorrect'));
        }
        $verification = $user->verification;
        $verification->mobile = 1;
        $user->verification = $verification;
        $user->mobile = $mobile;
        $user->save();

        Sms::flush($mobile, 'changemobile');
        $this->success();
    }

    /**
     * 第三方登录
     *
     * @param string $platform 平台名称
     * @param string $code     Code码
     */
    public function third()
    {
        $url = url('user/index');
        $platform = $this->request->request("platform");
        $code = $this->request->request("code");
        $config = get_addon_config('third');
        if (!$config || !isset($config[$platform])) {
            $this->error(__('Invalid parameters'));
        }
        $app = new \addons\third\library\Application($config);
        //通过code换access_token和绑定会员
        $result = $app->{$platform}->getUserInfo(['code' => $code]);
        if ($result) {
            $loginret = \addons\third\library\Service::connect($platform, $result);
            if ($loginret) {
                $data = [
                    'userinfo'  => $this->auth->getUserinfo(),
                    'thirdinfo' => $result
                ];
                $this->success(__('Logged in successful'), $data);
            }
        }
        $this->error(__('Operation failed'), $url);
    }

    /**
     * 重置密码
     *
     * @param string $mobile      手机号
     * @param string $newpassword 新密码
     * @param string $captcha     验证码
     */
    public function resetpwd()
    {
        $type = $this->request->request("type");
        $mobile = $this->request->request("mobile");
        $email = $this->request->request("email");
        $newpassword = $this->request->request("newpassword");
        $captcha = $this->request->request("captcha");
        if (!$newpassword || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if ($type == 'mobile') {
            if (!Validate::regex($mobile, "^1\d{10}$")) {
                $this->error(__('Mobile is incorrect'));
            }
            $user = \app\common\model\User::getByMobile($mobile);
            if (!$user) {
                $this->error(__('User not found'));
            }
            $ret = Sms::check($mobile, $captcha, 'resetpwd');
            if (!$ret) {
                $this->error(__('Captcha is incorrect'));
            }
            Sms::flush($mobile, 'resetpwd');
        } else {
            if (!Validate::is($email, "email")) {
                $this->error(__('Email is incorrect'));
            }
            $user = \app\common\model\User::getByEmail($email);
            if (!$user) {
                $this->error(__('User not found'));
            }
            $ret = Ems::check($email, $captcha, 'resetpwd');
            if (!$ret) {
                $this->error(__('Captcha is incorrect'));
            }
            Ems::flush($email, 'resetpwd');
        }
        //模拟一次登录
        $this->auth->direct($user->id);
        $ret = $this->auth->changepwd($newpassword, '', true);
        if ($ret) {
            $this->success(__('Reset password successful'));
        } else {
            $this->error($this->auth->getError());
        }
    }
    /**
     * 获取用户信息
     **/
    public function getuserinfo(){
        $targe = $this->request->request('targe');
        $userinfo = \app\common\model\User::get_user_info($targe);
        $this->success(__('请求成功'),['user'=>$userinfo]);
    }
    /**
     * 用户实名认证
     */
    public function userauth(){
        if ($this->request->isAjax()) {
            $userid = $this->auth->id;
            $truename = $this->request->post('truename') ?: '';
            $birthday = $this->request->post('birthday') ?: '';
            $idcard = $this->request->post("idcard");
            $card_front = $this->request->post('card_front') ?: '/';
            $card_back  = $this->request->post('card_back');
            $payment_method = $this->request->post('payment_method');
            if (!$truename) throw new Exception("请输入认证姓名", 0);
            if (!$birthday) throw new Exception("请选择出生年月", 0);
            if (!$idcard) throw new Exception("请输入认证身份证编号", 0);
            if (!$card_front) throw new Exception("请上传身份证正面照", 0);
            if (!$card_back) throw new Exception("请上传身份证反面照", 0);
            $model = new \app\common\model\UserAuth();
            $where['userid'] = $userid;
            $info = $model->where($where)->find();
            $data = [
                'userid' => $userid,
                'truename' => $truename,
                'birthday' => $birthday,
                'idcard'   => $idcard,
                'card_front_image' => $card_front,
                'card_back_image'  => $card_back,
                'createtime'=> time()
            ];
            if ($payment_method) {
                $alipay = $this->request->post('alipay');
                if (!$alipay) throw new Exception("请输入认证支付宝账号", 0);
                $data['alipay'] = $alipay;
            }else{
                $wechat = $this->request->post('wechat');
                if (!$wechat) throw new Exception("请输入认证微信账号", 0);
                $data['wechat'] = $wechat;
            }
            if (empty($info)) {
                $result = \app\common\model\UserAuth::create($data);
            }else{
                $msg = '';
                if ($info->status == 'created') {
                    $msg = '您提交的资料正在审核中...';
                }elseif($info->status == 'succeed'){
                    $msg = '您的资料已认证成功';
                }
                if ($msg) throw new Exception($msg, 0);
                $data['status'] = 'created';
                $result = $model->where($where)->update($data);
            }
            if ($result) {
                $this->success('资料提交成功,待审核中...');
            }else{
                throw new Exception("网络错误,请刷新后重试~", 0);
            }
        }        
    }
    /**
     * 检测用户认证信息
     */
    public function check_auth(){
        if ($this->request->isAjax()) {
            $userid = $this->auth->id;
            $model = new \app\common\model\UserAuth();
            $where['userid'] = $userid;
            $info = $model->where($where)->find();
            if (empty($info)) {
                throw new Exception("您还未进行实名认证，是否前往认证?", 10);
            }else{
                switch ($info->status) {
                    case 'created':
                        $msg = '您提交的资料正在审核中...';
                        throw new Exception($msg, 0);
                        break;
                    case 'refuse':
                        $msg = '您提交的资料审核未通过,是否重新认证？';
                        throw new Exception($msg, 10);
                    default:
                        $this->success('请求成功',['url'=>url('index/center/cash')]);
                        break;
                }
            }
        }
    }
    /**
     * 检测用户提现数据
     */
    public function cashinfo(){
        $userid = $this->auth->id;
        $banklist = \app\common\model\Banklist::getUserBanklist($userid);
        $auth = \app\common\model\UserAuth::where("userid",$userid)->field('truename,alipay,wechat,mobile')->find();
        $this->success('请求成功',['banklist'=>$banklist,'authinfo'=>$auth]);
    }
    /**
     * 单独认证微信支付宝账号
     */
    public function authdata(){
        $userid = $this->auth->id;
        $type = $this->request->param('type');
        $account = $this->request->param('account');
        $info = \app\common\model\UserAuth::where('userid',$userid)->field('alipay,wechat')->find();
        if ($type == 'alipay') {
            $msg = '支付宝账号';
        }else{
            $msg = '微信账号';
        }
        if ($info[$type]) throw new Exception("您的".$msg."已认证", 0);
        $info->$type = $account;
        $result = $info->save();
        if ($result) {
            $this->success('认证成功');
        }else{
            throw new Exception("网络错误,请刷新后重试~", 0);
        }
    }
}
