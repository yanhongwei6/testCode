<?php

namespace app\api\controller;

use app\common\controller\Api;

/**
 * 首页接口
 */
class Record extends Api
{
    protected $noNeedLogin = [''];
    protected $noNeedRight = ['*'];
    /**
     * 充值记录
     */
    public function rechargeRecord()
    {
        $limit = 10;
        $page = request()->param('page') ?: 1;
        $userid = $this->auth->id;
        $where = [
            'user_id' => $userid,
            'is_del'  => 'normal'
        ];
        $field = 'id,orderid,truename,amount,payamount,paytype,paytime,memo,createtime,status';
        $model = new \app\common\model\Recharge();
        $total = $model->where($where)->field($field)->count();
        $list = $model->where($where)
                        ->field($field)
                        ->order('id desc')
                        ->page($page,$limit)
                        ->select();
        $this->success('请求成功',['pages'=>ceil($total/$limit),'list'=>$list]);
    }
    /**
     * 提现记录
     */
    public function cashRecord()
    {
        $limit = 10;
        $page = request()->param('page') ?: 1;
        $userid = $this->auth->id;
        $where = [
            'user_id' => $userid,
            'is_del' => 'normal'
        ];
        $field = 'id,money,handingfee,taxes,type,account,memo,orderid,status,createtime';
        $model = new \app\common\model\Cash();
        $total = $model->where($where)->field($field)->count();
        $list = $model->where($where)
                    ->field($field)
                    ->order('id desc')
                    ->page($page,$limit)
                    ->select();
        $this->success('请求成功',['pages'=>ceil($total/$limit),'list'=>$list]);
    }
}
