<?php

namespace app\api\controller;

use app\common\controller\Api;
use GatewayClient\Gateway;
use app\api\server\play\FfcStatus;
use redis\Redis;
/**
 * 首页接口
 */
class Index extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 游戏界面
     * @param sting $type 游戏分类
     * @param sting $ykid 游客ID
     */
    public function playinfo(){
        $config = config('redis');
        $redis = new Redis($config);
        $type = $this->request->request('type') ?: 'ffc';
        $ykid = $this->request->request('ykid') ?: '';
        $model = new FfcStatus();
        $this->success('请求成功',$model->playstatus($redis,$type,$this->auth,$ykid));
    }
}
