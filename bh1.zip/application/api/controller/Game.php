<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\api\server\BonusServer;
use \think\Hook;
use think\Cookie;
class Game extends Api
{

    protected $noNeedLogin = 'index,production_number,lottery,settlement,systemscreen,rotbot';
    protected $noNeedRight = '*';
    protected $layout = '';


    // public function index()
    // {
    //     $type = $this->request->request('type');
    //     $serverName = "\app\api\server\\".ucfirst($type)."Server";
    //     // var_dump($serverName);
    //     $serverModel = new $serverName();
    //     $result = $serverModel->noissueno(100,10);
    //     var_dump($result);
    // }
    //测试钩子函数
    public function index(){
        $param = [
            1 => 24,
            3 => -55.55,
            2 => 22,
        ];
        // Cookie::set('user_name','TPshop 老师',10);
        var_dump(Cookie::get('user_name'));
        // $result = Hook::listen('user_bets_settled',$param);
        // var_dump($result);
    }
    /**
     * 生产新一轮期号
     * @param $type string 游戏标识
     * @param $current string 当前期号
     */
    public function production_number(){
        $type = $this->request->request('type');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        //生成期号
        $result = $serverModel::createNumber();
        var_dump($result);
    }
    /**
     * 用户抢庄
     * @param $type游戏类型
     */
    public function member_village(){
        $type = $this->request->param('type');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        $result = $serverModel::memberVillage($this->auth);
        $this->success("抢庄成功",$result);
    }
    /**
     * 系统验证是否抢庄
     */
    public function systemscreen(){
        $type = $this->request->request('type');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        $result = $serverModel::system_selected_zhuang();
        $this->success('系统选庄成功',$result);
    }
    /**
     * 抢庄推送
     * @param $type string 游戏唯一标识
     * @param $current string 当前期号
     */
    public function rush_village(){
        $type = $this->request->request('type');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        $result = $serverModel::rushVillage();
        $this->success('验证抢庄状态',$result);
    }
    /**
     * 游戏下注
     * @param $type string 游戏唯一标识
     * @param $current string 当前期号
     */
    public function userBets(){
        $type = request()->param('type');
        $playtype = request()->param('playtype');
        $price = request()->param('price');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        $result = $serverModel::userBets($this->auth,$playtype,$price);
        $this->success("下注成功",$result);
    }
    /**
     * 游戏开奖
     * @param $type string 游戏唯一标识
     * @param $current string 当前期号
     */
    public function lottery(){
        $type = $this->request->request('type');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        $result = $serverModel::lottery();
        var_dump($result);
    }
    /**
     * 游戲結算
     */
    public function settlement(){
        $type = $this->request->request('type');
        $serverName = "\app\api\server\\".ucfirst($type)."Server";
        $serverModel = new $serverName();
        $result = $serverModel::settlement();
        var_dump($result);
    }
    /**
     * 机器人自动下注
     */
    public function rotbot(){
        $type = $this->request->request('type');
        $result = \app\api\server\RobotServer::robot_bet($type);
    }
}
