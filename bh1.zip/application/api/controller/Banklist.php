<?php

namespace app\api\controller;

use app\common\controller\Api;

/**
 * 银行接口
 */
class Banklist extends Api
{
    protected $noNeedLogin = [''];
    protected $noNeedRight = ['*'];
   	public function addbank(){
   		$userid = $this->auth->id;
   		$banknumber = $this->request->request('number');
   		$bankcode = $this->request->request('modules');
   		$default = $this->request->request('open');
   		$address = $this->request->request('address');
   		if (!$banknumber) throw new Exception("请输入绑定银行卡号", 0);
   		if (!preg_match('/^([1-9]{1})(\d{14}|\d{18})$/', $banknumber)) throw new Exception("请输入正确的银行卡号", 0);
   		if ($bankcode == 'default') throw new Exception("请选择所属银行", 0);
   		if (!$address) throw new Exception("请输入办卡网点地址", 0);
   		$auth = \app\common\model\UserAuth::where('userid',$userid)->field('truename,mobile,status')->find();
   		switch ($auth['status']) {
   			case 'created':
   				throw new Exception("您提交的资料正在审核中...", 0);
   				break;
   			case 'refuse':
   				throw new Exception("您提交的资料审核未通过,是否重新认证？", 0);
   				break;
   		}
   		$data = [
   			'userid'	=> $userid,
   			'truename' 	=> $auth['truename'],
   			'number'	=> $banknumber,
   			'address'	=> $address,
   			'phone'		=> $auth['mobile'],
   			'bankcode'	=> $default,
   			'createtime'=> time()
   		];
   		$count = \app\common\model\Banklist::where('userid',$userid)->count();
   		if ($count >= 5) {
   			throw new Exception("您最多可绑定5张银行卡", 0);
   		}
   		if ($this->request->request('open') == 'on') {
   			$data['default'] = 'Y';
   			\app\common\model\Banklist::where('userid',$userid)->update(['default'=>'N']);
   		}
   		// trace($data);
   		$result = \app\common\model\Banklist::create($data);
   		if ($result) {
   			$this->success('添加成功');
   		}else{
   			throw new Exception("网络错误，请刷新后重试~", 0);
   		}
   	}
}
