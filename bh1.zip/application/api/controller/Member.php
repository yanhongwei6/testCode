<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\Ems;
use app\common\library\Sms;
use fast\Random;
use think\Validate;
use app\common\library\exception\Exception;
/**
 * 会员接口
 */
class User extends Api
{
    protected $noNeedLogin = [];
    protected $noNeedRight = '*';
    
    /**
     * 用户提现渲染接口
     * @param string $token 用户登录token
     */
    public function cashinfo(){
        
    }



   
}
