<?php

// 应用行为扩展定义文件
return [
 //接口初始化
 'api_init'  => ['app\\api\\behavior\\AopTest'],
 'api_end'  => ['app\\api\\behavior\\AopTest'],
 'user_bets_settled' => ['app\\api\\behavior\\User'],
 'qishu_open_number' => ['app\\api\\behavior\\OpenNumber'],
 'qishu_open_result' => ['app\\api\behavior\\OpenNumber'],
 'dealer_settlement' => ['app\\api\behavior\\OpenNumber'],
];