<?php

namespace app\api\server;

use app\common\model\Qishu;
use redis\Redis;
use app\common\library\exception\Exception;
use think\Hook;
use think\Db;
use think\Cookie;
class FfcServer
{

    use \app\api\server\traits\FfcTraits;
    const TYPE = 'ffc';
    /**
     * 创建新期号
     * 更新新一期期号
     * @param $current string 当期期号
     */
    public static function createNumber(){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        if ($current) {
            $issueArr = explode('_', $current);//切割期号
            if (!is_array($issueArr)||count($issueArr) <= 1) {
                throw new Exception("当期参数格式不正确", 0);
            }
            $issue = $issueArr[1];
            $current_createtime = Qishu::where('issue',$issue)->value('createtime') ?: 0;
            if (!empty($current_createtime)) {
                $current_date = date('Ymd',$current_createtime);
                $current_qishu_arr = explode($current_date, $issue);
                if (!is_array($current_qishu_arr)||count($current_qishu_arr) <= 1) {
                    throw new Exception("当期期数未知", 0);
                }
                $current_qishu = (int)$current_qishu_arr[1];
            }else{
                $issue = 0;
                $current_date = 0;
                $current_qishu = 0; 
            }
        }else{
            $issue = 0;
            $current_date = 0;
            $current_qishu = 0;
        }
        $nowdate = date('Ymd',time());
        if ($current_date != $nowdate) {
            $current_qishu = '01';
            $qihao = $nowdate.$current_qishu;
        }else{
            $current_qishu++;
            if ($current_qishu < 10) {
                $current_qishu = '0'.$current_qishu;
            }
            $qihao = $current_date.$current_qishu;
        }
        $gameId = \app\common\model\Game::where('sign',self::TYPE)->value('id');
        $qihao_data = Qishu::where(['issue'=>$qihao,'game'=>$gameId])->find();
        if (!empty($qihao_data)) {
            $redis->set('current_'.self::TYPE.'_issue',self::TYPE.'_'.$qihao);
            return self::createNumber();
        }
        $update_current_data = Qishu::where('issue',$issue)->update(['is_now'=>'no']);
        //判断期号是否存在
        $data['issue'] = $qihao;
        $data['game'] = $gameId;
        $data['is_now'] = 'yes';
        $data['createtime'] = time();
        $data['updatetime'] = time();
        $result = Qishu::create($data);
        $redis->set('current_'.self::TYPE.'_issue',self::TYPE.'_'.$qihao);
        self::rushVillage();
        return $result;
    }
    
    /**
     * 用户抢庄
     */
    public static function memberVillage($auth){
        $config = config('redis');
        $redis = new Redis($config);
        if ($redis->get('forbid_rush_village')||$redis->get(self::TYPE."_status") != 1) {
            throw new Exception("当前状态不允许抢庄", 0);
        }
        $minMoney = config('site.member_rush_village_min_money');//抢庄最低金额
        $rushNum = config('site.rush_sum');
        $rushtype = request()->param('rushtype');
        $type = explode('-', $rushtype)[0];
        $price = isset($rushNum[$type]) ? $rushNum[$type]:$minMoney;

        if ($auth->money < $price) {
            throw new Exception("您的余额不足，不能抢庄", 0);
        }
        if (Cookie::get('member_rush_village')) {
           throw new Exception("您已抢庄完成", 0);
        }else{
            Cookie::set('member_rush_village',1,35);
        }
        $data = [
            'userid' => $auth->id,
            'price'  => $price
        ];
        //抢庄数据入队
        $redis->rpush(self::TYPE."_rush_village",json_encode($data));
        $list = json_decode($redis->get(self::TYPE."_rush_village_list"),true) ?: [];
        //释放队列
        while (1) {
            $value = $redis->lpop(self::TYPE.'_rush_village');
            if ($value) {
                $value = json_decode($value,true);
                $list[] = $value;
            }else{
                break;
            }     
        }
        $redis->set(self::TYPE."_rush_village_list",json_encode($list));
        return ['info',$data];
    }
    /**
     * 系统选庄
     */
    public static function rushVillage(){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        $issueArr = explode('_', $current);//切割期号
        if (!is_array($issueArr)||count($issueArr) <= 1) {
            throw new Exception("当期参数格式不正确", 0);
        }
        $issue = $issueArr[1];
        $gameId = \app\common\model\Game::where('sign',self::TYPE)->value('id');
        $where['number'] = ['elt',3];
        $where['game'] = $gameId;
        $where['status'] = 'normal';
        //检测当期庄是否有庄或结束
        $village = \app\common\model\Village::where($where)->order('id desc')->field('id,number,userid,money')->find();
        $time = time();
        if (!empty($village)&&$village->number < 3) {
            //检查当前连庄金额是否足够
            $uinfo = \app\common\model\User::get($village->userid);
            //余额不足自动下庄
            if ($uinfo['money'] <= $village->money) {
                $data['end_issue'] = $issue;
                $data['endtime'] = time();
                $data['status'] = 'fished';
                \app\common\model\village::where('id',$village->id)->update($data);
                $redis->set('forbid_rush_village',0);
                $redis->set('rush_village_user',json_encode(['userid'=>0,'screen_money'=>config('site.member_rush_village_min_money'),'xzuser'=>$village->userid]));
                return ['userid'=>0,'money'=>config('site.member_rush_village_min_money')];
            }
            $data['number'] = $village->number+1;
            if ($village->number == 2) {
                $village->end_issue = $issue;
                $village->status = 'fished';
                $village->endtime = time();
            }
            $village->number = $village->number+1;
            $village->save();
            \app\common\model\village::where('id',$village->id)->update($data);
            $data['issue'] = $issue;
            unset($data['end_issue']);
            $data['gameid'] = $gameId;
            $data['userid'] = $village->userid;
            $data['createtime'] = $time;
            $data['updatetime'] = $time;
            \app\common\model\VillageRecord::create($data);
            $redis->set('rush_village_user',json_encode(['userid'=>$village->userid,'screen_money'=>$village->money,'xzuser'=>0]));
            return ['userid'=>$village->userid,'money'=>$village->money];
        }else{
            $redis->set('forbid_rush_village',0);
            $xzuserInfo = json_decode($redis->get('rush_village_user'),true);
            $redis->set('rush_village_user',json_encode(['userid'=>0,'screen_money'=>config('site.member_rush_village_min_money'),'xzuser'=>$xzuserInfo['userid']]));
            return ['userid'=>0,'money'=>config('site.member_rush_village_min_money')];
        }
    }
    /**
     * 系统选庄
     */
    public static function system_selected_zhuang(){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        $issueArr = explode('_', $current);//切割期号
        if (!is_array($issueArr)||count($issueArr) <= 1) {
            throw new Exception("当期参数格式不正确", 0);
        }
        $issue = $issueArr[1];
        $gameId = \app\common\model\Game::where('sign',self::TYPE)->value('id');
        $time = time();
        $list = json_decode($redis->get(self::TYPE."_rush_village_list"),true) ?: [];
        $list_price = array_column($list,'price');
        array_multisort($list_price,SORT_DESC,$list);
        $arrData = [];
        if (!empty($list)) {
            foreach ($list as $k => $v) {
                if ($v['price'] == $list[0]['price']) {
                    $arrData[$v['userid']] = $v['price'];
                }
            }
        }
        $arrKey = array_keys($arrData);
        $redis->set('screen_user',json_encode($arrKey));
        if (!empty($arrKey)) {
            $userid = $arrKey[array_rand($arrKey)];
            $randMoney = $arrData[$userid];
            $data['number'] = 1;
            $data['start_issue'] = $issue;
            $data['userid'] = $userid;
            $data['game'] = $gameId;
            $data['money'] = $randMoney;
            $data['rushtime'] = $time;
            $data['status'] = 'normal';
            $data['createtime'] = $time;
            $data['updatetime'] = $time;
            \app\common\model\Village::create($data);
            $redata['issue'] = $issue;
            $redata['userid'] = $userid;
            $redata['gameid'] = $gameId;
            $redata['money'] = $randMoney;
            $redata['number'] = 1;
            $redata['createtime'] = $time;
            $redata['updatetime'] = $time;
            \app\common\model\VillageRecord::create($redata);
            $redis->set('rush_village_user',json_encode(['userid'=>$userid,'screen_money'=>$randMoney]));
            return ['forbid_rush_village'=>$redis->get('forbid_rush_village'),'rush_village_user'=>['userid'=>$userid,'screen_money'=>$randMoney]];
        }
        $redis->set('forbid_rush_village',0);
        $redis->set('rush_village_user',json_encode(['userid'=>0,'screen_money'=>config('site.member_rush_village_min_money')]));
        return ['forbid_rush_village'=>$redis->get('forbid_rush_village'),'rush_village_user'=>['userid'=>0,'screen_money'=>config('site.member_rush_village_min_money')]];
    }
    /**
     * 用户投注
     */
    public static function userBets($auth,$playtype,$price){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        $issueArr = explode('_', $current);//切割期号
        if ($redis->get('ffc_status') != 2) {
            throw new Exception("当前状态不可下注", 0);
        }
        if (!is_array($issueArr)||count($issueArr) <= 1) {
            throw new Exception("当期参数格式不正确", 0);
        }
        if (!$playtype) {
            throw new Exception("请选择下注玩法", 0);
        }
        if (!$price) {
            throw new Exception("请选择下注筹码", 0);
        }
        $userid = $auth->id;
        $money = $auth->money;
        //用户已投注金额
        // $useBetMoney = $redis->get('user_bets_money_'.$userid) ?: 0;
        $useBetMoney = 0;
        $list = json_decode($redis->get('user_bets_record_list'),true) ?: [];
        $betall = 0;
        $large = 0;
        $little = 0;
        $leopard = 0;
        foreach ($list as $k => $v) {
            if ($v['userid'] == $userid) {
                $useBetMoney += $v['bets'];
            }
            $betall += $v['bets'];
            switch ($v['playtype']) {
                case 'large':
                    $large += $v['bets'];
                    break;
                case 'little':
                    $little += $v['bets'];
                    break;
                default:
                    $leopard += $v['bets'];
                    break;
            }
        }
        switch ($playtype) {
            case 'large':
                $playtype = 'large';
                $large += $price;
                break;
            case 'little':
                $playtype = 'little';
                $little += $price;
                break;
            case 'leopard':
                $playtype = 'leopard';
                $leopard += $price;
                break;
            default:
                $playtype = 'leopard';
                $leopard += $price;
                break;
        }
        $issue = $issueArr[1];
        $gameId = \app\common\model\Game::where('sign',self::TYPE)->value('id');
        $betAll = $price + $useBetMoney;
        $messageInfo = [
            'issue' => $issue,
            'gameid' => $gameId,
            'betall' => $betall+$price,
            'large' => $large,
            'little' => $little,
            'leopard' => $leopard
        ];
        $time = time();
        if ( $betAll > $money) {
            throw new Exception("您的金额不足，是否前往充值？", 0);
        }
        \app\index\server\gateway\Client::setDatatoAll($messageInfo);
        $data = [
            'issue' => $issue,
            'userid' => $userid,
            'game' => $gameId,
            'bets' => $price,
            'playtype' => $playtype,
            'bettime' => $time,
        ];
        //数据入队
        $redis->rpush("user_bets_list_record",json_encode($data));
        //释放队列
        while (1) {
            $value = $redis->lpop('user_bets_list_record');
            if ($value) {
                $value = json_decode($value,true);
                $value['opentime'] = $time;
                $list[] = $value;
            }else{
                break;
            }     
        }
        $redis->set('user_bets_record_list',json_encode($list,JSON_UNESCAPED_UNICODE));
        return ['errcode'=>1,'msg'=>'下注成功','data'=>$data];
    }
    /**
     * 開獎
     */
    public static function lottery(){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        $issueArr = explode('_', $current);//切割期号
        if (!is_array($issueArr)||count($issueArr) <= 1) {
            return '当期参数格式不正确';
        }
        $issue = $issueArr[1];
        $config = config('redis');
        $redis = new Redis($config);
        // $redis->set('user_bets_record_list',json_encode($list,JSON_UNESCAPED_UNICODE));
        $list = json_decode($redis->get('user_bets_record_list'),true) ?: [];
        if (config('site.ffc_set_open_result')) {
            $number = self::setOpenPrize();
        }elseif (config('site.ffc_must_win')) {
            $number = self::must_win_number($list);
        }
        $redis->set('ffc_open_number',json_encode($number));
        $param = ['type'=>self::TYPE,'issue'=>$issue,'number'=>$number];
        Hook::listen('qishu_open_number',$param);
        return $number;
    }
    /**
     * 设置开奖结果
     */
    public static function setOpenPrize(){
        if (config('site.ffc_set_open_number')) {
            $number = config('site.ffc_set_open_number');
            return explode(',', $number);;
        }elseif(config('site.ffe_open_result')){
            return self::randNumber(config('site.ffe_open_result'));
        }else{
            $arr = [];
            for ($i=0; $i < 3; $i++) { 
                $arr[] = rand(1,9);
            }
            return $arr;
        }
    }
    /**
     * 生成随机号码
     */
    public static function randNumber($type){
        $arr = [];
        if ($type == '豹子') {
            $num = rand(1,9);
            $arr = [$num,$num,$num];
        }else{
            for ($i=0; $i < 3; $i++) { 
                $arr[] = rand(1,9);
            }
        }
        $total = array_sum($arr);
        if ($type == '大') {
            if ($total < 14) {
               $arr = self::randNumber($type);
            }
        }elseif($type == '小'){
            if ($total >= 14) {
               $arr = self::randNumber($type);
            }
        }
        return $arr;
    }
    /**
     * 稳赢开奖号设置
     */
    public static function must_win_number($list){
        $big = 0;
        $small = 0;
        $ping = 0;
        $odds = config('site.ffc_odds');
        foreach ($list as $v) {
            switch ($v['playtype']) {
                case 'large':
                    $big += $v['bets']*$odds['large'];
                    break;
                case 'little':
                    $small += $v['bets']*$odds['little'];
                    break;
                default:
                    $ping += $v['bets']*$odds['leopard'];
                    break;
            }
        }
        
        if ($big <= $small + $ping) {
            return self::randNumber('大');
        }elseif($small <= $big + $ping){
            return self::randNumber('小');
        }elseif($ping <= $big + $small){
            return self::randNumber('豹子');
        }
    }
    /**
     * 单局结算
     * @param $current string 当期期号
     */
    public static function settlement(){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        $issueArr = explode('_', $current);//切割期号
        if (!is_array($issueArr)||count($issueArr) <= 1) {
            return '当期参数格式不正确';
        }
        $issue = $issueArr[1];
        return self::settlement_count();
    }
    /**
     * 结算入库
     */
    public static function settlement_count(){
        $config = config('redis');
        $redis = new Redis($config);
        $current = $redis->get('current_'.self::TYPE.'_issue');
        $issueArr = explode('_', $current);//切割期号
        $issue = $issueArr[1];
        $list = json_decode($redis->get('user_bets_record_list'),true);
        trace($list);
        $openNumber = json_decode($redis->get('ffc_open_number'),true);
        $odds  = config('site.ffc_odds');
        $time = time();
        $result = '';
        $number = array_sum($openNumber)%10;
        if ($openNumber[0] == $openNumber[1] && $openNumber[1] == $openNumber[2]) {
            $result = 'leopard';//豹子
        }
        $betAll = 0;
        $winAll = 0;
        $betLarge = 0;
        $betLittle = 0;
        $userGroup = [];
        $zhuangGroup = [];
        if (!empty($list)) {
            foreach ($list as $k => $v) {
                if ($v['playtype'] == 'large') {
                    $betLarge += $v['bets'];
                }elseif($v['playtype'] == 'little'){
                    $betLittle += $v['bets'];
                }
                if ($result == 'leopard') {
                    //压豹子赢豹子赔率
                    if (self::result_isbaozi($openNumber,$v['playtype'])) {
                        $v['winlose'] = 'win';
                        $v['wlamount'] = $v['bets']*$odds[$v['playtype']];
                        $v['status'] = 'settled';
                        $v['odds'] = $odds[$v['playtype']];
                        $v['settledtime'] = $time;
                        $v['createtime'] = $time;
                        $v['updatetime'] = $time;
                    }else{
                        //不压豹子，庄通杀，赢下注一半，返还一半
                        $v['winlose'] = 'lose';
                        $v['wlamount'] = $v['bets']/2;
                        $v['status'] = 'settled';
                        $v['odds'] = $odds[$v['playtype']];
                        $v['settledtime'] = $time;
                        $v['createtime'] = $time;
                        $v['updatetime'] = $time;
                    }
                }else{
                    if (self::result_bigsmall($number,$v['playtype'])) {
                        $v['winlose'] = 'win';
                        $v['wlamount'] = $v['bets']*$odds[$v['playtype']];
                        $v['status'] = 'settled';
                        $v['odds'] = $odds[$v['playtype']];
                        $v['settledtime'] = $time;
                        $v['createtime'] = $time;
                        $v['updatetime'] = $time;
                    }else{
                        $v['winlose'] = 'lose';
                        $v['wlamount'] = 0;
                        $v['status'] = 'settled';
                        $v['odds'] = $odds[$v['playtype']];
                        $v['settledtime'] = $time;
                        $v['createtime'] = $time;
                        $v['updatetime'] = $time;
                    }
                }
                $list[$k] = $v;
                $betAll += $v['bets'];
                $winAll += $v['wlamount'];
                if (!isset($userGroup[$v['userid']])) {
                    $userGroup[$v['userid']] = [];
                    $userGroup[$v['userid']]['winOrLos'] = $v['wlamount']-$v['bets'];
                }else{
                    $userGroup[$v['userid']]['winOrLos'] += $v['wlamount']-$v['bets'];
                }
            }
        }
        Db::startTrans();
        try {
            if (!empty($list)) {
                $result = \app\common\model\Bets::insertAll($list);
                if ($result) {
                    Hook::listen('user_bets_settled',$userGroup);//注单结算
                    $param = ['type'=>self::TYPE,'issue'=>$issue,'bet_all'=>$betAll,'win_all'=>$winAll];
                    Hook::listen('qishu_open_result',$param);
                    $params = ['number'=>$openNumber,'bet_large'=>$betLarge,'bet_little'=>$betLittle,'betall'=>$betAll,'type'=>self::TYPE,'issue'=>$issue];
                    Hook::listen('dealer_settlement',$params);
                    // $redis->lPop('user_bets_record_list');
                    $dataArr = [];
                    foreach ($userGroup as $uid => $item) {
                        $item['uid'] = $uid;
                        if ($item['winOrLos'] > 0) {
                            $item['status'] = 'win';
                        }elseif($item['winOrLos'] < 0){
                            $item['status'] = 'lose';
                        }else{
                            $item['status'] = 'draw';
                        }
                        $dataArr[] = $item;
                    }

                    $redis->set("send_winlose_info",json_encode($dataArr));

                    Db::commit();
                    return true;
                }
            }
            Db::rollback();
            return false;
        } catch (Exception $e) {
            Db::rollback();
            throw new Exception($e->getMessage(), 0);
        }
    }
}
