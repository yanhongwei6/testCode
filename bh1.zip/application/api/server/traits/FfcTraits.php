<?php



namespace app\api\server\traits;

use think\Db;

use think\Exception;

use think\exception\PDOException;

use think\exception\ValidateException;



trait FfcTraits
{	
	/**
	 * @param $numArr array 开奖号码
	 * @param $playtype string 下注玩法
	 */
	public static function result_bigsmall($resultNum,$playtype){
		$result = '';
		if ($resultNum > 4) {
			$result = 'large';
		}else{
			$result = 'little';
		}
		return ($result == $playtype) ? 1 : 0;
	}
	/**
	 * @param $resultArr array 开奖号码
	 * @param $playtype string 下注玩法
	 */
	public static function result_isbaozi($resultArr,$playtype){
		return ($resultArr[0] == $resultArr[1]&& $resultArr[1]==$resultArr[2]) ? 1 : 0;
	}
}

