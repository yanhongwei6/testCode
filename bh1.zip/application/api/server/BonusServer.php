<?php

namespace app\api\server;

class BonusServer
{

    /**
     * 禁止开出号码
     * @param $type int 1=单局控制（优先）,0=全局配置
     */
    public function noissueno($total,$number,$type=0){
        $numArr = random_number($total,$number);
        if ($type) {
            return $this->system_control($numArr,$total,$number);
        }
        return $this->singlebureau_control($numArr,$total,$number);

    }
    /**
     * 系统全局控制
     * @param $arr 红包随机数组
     */
    protected function system_control($arr,$total,$number){
        $forbidNum = config('site.niuniu_noissueno');
        $dataArr = [];
        $result = true;
        foreach ($arr as $k => $v) {
            $strNum = substr($v, -4);
            $strNum = str_replace('.', '', $strNum);
            $number = array_sum(str_split($strNum));
            if ( $forbidNum = $number) {
                $result = false;
            }
        }
        if (!$result) {
            $arr = random_number($total,$number);
            $this->system_control($arr,$total,$number);
        }
        return $arr;
    }
    /**
     * 单局控制
     * @param 
     */
    protected function singlebureau_control($arr,$total,$number){
        
    }

    
}
