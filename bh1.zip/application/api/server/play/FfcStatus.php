<?php

namespace app\api\server\play;
use app\common\model\User;
use app\index\server\gateway\Client;
/**
 * 机器人操作
 */
class FfcStatus
{
	protected $numArr = [0,0,0];//默认开奖号配置
	private $status_show = 0;
	private $bet_flag = 0;//是否可以投注状态
	private $screen_show = 0;//是否可以抢庄状态
	private $openresult_show = 0;//是否显示获取开奖结果滚动条

	/**
	 * 游戏状态接口
	 * @param object $redis redis组件
	 * @param string $type 游戏类别
	 * @param object $auth 用户登录信息
	 * @param string $ykid 游客ID
	 */
	public function playstatus($redis,$type,$auth,$ykid = ''){
        switch ($redis->get($type."_status")) {
            case 1:
                $status_info = ['status'=>1,'message'=>'抢庄中'];
                if (!Cookie::get('member_rush_village')) {
                    $this->screen_show = 1;
                }
                break;
            case 2:
                $this->bet_flag = 1;
                $status_info = ['status'=>2,'message'=>'投注中'];
                break;
            case 3:
                $status_info = ['status'=>3,'message'=>'获取开奖结果'];
                $this->openresult_show = 1;
                break;
            case 4:
                $number = $redis->get('ffc_open_number');
                $this->numArr = json_decode($number,true);
                $this->status_show = 1; 
                $status_info = ['status'=>4,'message'=>'公布开奖'];
                break;
            case 5:
                $status_info = ['status'=>5,'message'=>'结算中'];
                break;
            default:
                $status_info = ['status'=>0,'message'=>'准备下一局'];
                break;
        }
        $resultNum = array_sum($this->numArr);
        $resultNums = $resultNum%10;
        $resultTips = '';
        if ($this->numArr[0]==$this->numArr[1]&&$this->numArr[1]==$this->numArr[2]) {
            $resultTips = '豹子';
        }else{
            if ($resultNums > 4) {
                $resultTips = '大';
            }else{
                $resultTips = '小';
            }
        }
        //获取期号
        $current = $redis->get('current_'.$type.'_issue');
        $issueArr = explode('_', $current);
        return [
        	'basedata' => [
	        	'issue'	=> $issueArr,
	        	'playstatus' => $status_info,
	        	'status'=>$this->status_show,
	        	'number'=>$this->numArr,
	        	'result_num'=>$resultNums,
	        	'result_tips'=>$resultTips,
	        	'screen_show'=>$this->screen_show,
	        	'openresult_show' => $this->openresult_show,
	        	'bet_flag'	=> $this->bet_flag,
	        	'room'	=> $type
	        ],
	        'rushinfo' => [
	        	'rushstatus'	=> $redis->get('screen_screen'),
	        	'rushlist'		=> $redis->get('screen_user'),
	        ],
	        'zhuanginfo' => $this->rushdata($redis),
	        'userlist' => $this->playuserinfo($type,$auth,$ykid)
        ];
    }
    /**
     * 庄家信息获取
     * @param object $redis redis组件
     */
    protected function rushdata($redis){
    	$zhuang = [];
        $zhuanginfo = [];
        $rushVillageUser = $redis->get('rush_village_user');
        if ($rushVillageUser) {
            $rushVillage = json_decode($rushVillageUser,true);
            $zhuanginfo = \app\common\model\User::where('id',$rushVillage['userid'])->field('id,nickname,avatar')->find();
        }
        if (empty($zhuanginfo)) {
            $zhuang['id'] = 0;
            $zhuang['nickname'] = '系统坐庄';
            $zhuang['avatar'] = config('site.default_header_image');
            $zhuang['screen_money'] = config('member_rush_village_min_money');
        }else{
            $zhuang['id'] = $zhuanginfo->id;
            $zhuang['nickname'] = $zhuanginfo->nickname;
            $str = substr($zhuanginfo->avatar, 0,5);
            if ($str == 'data:') {
                $zhuang['avatar'] = config('site.default_header_image');
            }else{
                $zhuang['avatar'] = $zhuanginfo->avatar;
            }
            $zhuang['screen_money'] = $rushVillage['screen_money'];   
        }
        return $zhuang;
    }
    /**
     * 获取当前玩家信息
     * @param string $type 游戏分类
     * @param string $ykid 游客ID
     * @param object $auth 
     */
    protected function playuserinfo($type,$auth,$ykid = ''){
    	$uidArr = Client::getUserIdInGroup($type);
        $uidList = [];
        $ykList = [];
        foreach ($uidArr as $v) {
            if (is_numeric($v)) {
                $uidList[] = $v;
                unset($uidArr[$v]);
            }else{
                $ykList[] = [
                    'id'   => $v,
                    'nickname' => '游客',
                    'avatar'   => config('site.default_header_image')
                ];
            }
        }
        if ($auth->id&&!in_array($auth->id, $uidArr)) {
            $uidList[$auth->id] = $auth->id;
        }
        $listData = \app\common\model\User::get_user_list($uidList);
        $listArr = collection($listData)->toArray();
        $list = array_merge($listArr,$ykList);
        //生成游客唯一ID
        if (!$auth->id&&!$ykid) {
            $ykid = uniqid();
        }
        return ['list'=>$list,'ykid'=>$ykid];
    }
}