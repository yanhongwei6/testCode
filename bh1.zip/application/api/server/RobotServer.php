<?php

namespace app\api\server;
use app\common\model\User;
use redis\Redis;
/**
 * 机器人操作
 */
class RobotServer
{
	/**
	 * 机器人下注
	 */
	public static function robot_bet($type){
		$config = config('redis');
        $redis = new Redis($config);
		$limit = rand(5,15);
		$robotList = User::where('type','computer')->where('rand()')->limit($limit)->select();
		shuffle($robotList);
		$pricelist = config('site.rush_price_list');
		$priceArr = explode(',', $pricelist);
		$playtype = config('site.rush_ffc_playtype');
		$playArr = [];
		foreach ($playtype as $k => $v) {
			$playArr[] = explode('-', $k)[1];
		}

		$time = 10;
		foreach ($robotList as $key => $val) {
			$s = randFloat(0,2);
			$time -= $s;
			if ($time > 0&&$redis->get('ffc_status') == 2) {
				$priceId = array_rand($priceArr,1);
				$serverName = "\app\api\server\\".ucfirst($type)."Server";
				$serverModel = new $serverName();
				$playKey = array_rand($playArr,1);
				$serverModel::userBets($val,$playArr[$playKey],$priceArr[$priceId]);
				sleep($s);
			}else{
				continue;
			}
		}
		return true;

	}
	
}