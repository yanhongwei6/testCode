<?php

namespace app\api\behavior;
use think\Db;
use app\common\model\User as UserTable;
use app\common\model\MoneyLog;
/**
 * 
 */
class User
{
	/**
	 * 注单结算
	 * @param $param array 注单详情数据
	 */
	public function userBetsSettled(&$param){
		$userIds = array_keys($param);
		$keyArr = implode(',', $userIds);
		$where['id'] = ['in',$userIds];
		$userList = UserTable::where($where)->column('money,score','id');
		$data = [];
		 //拼接批量更新sql语句
        $sql = "UPDATE hb_user SET `money`= CASE id";
        foreach ($param as $k => $v) {
        	$log = [];
			if (!isset($userList[$k])) continue;
            $log['user_id'] = $k;
            $log['money'] = $v['winOrLos'];
            $log['before'] = $userList[$k]['money'];
            $log['after'] = (float)$userList[$k]['money']+(float)$v['winOrLos'];
            $log['createtime'] = time();
            if ($v >= 0) {
                $log['memo'] = '下注获得';
            }else{
                $log['memo'] = '下注失去';
            }
			$data[] = $log;
			$sql .= " WHEN ".$k." THEN money+".$v['winOrLos'];
        }
        $sql .= " END WHERE id IN (".$keyArr.")";
        $result = Db::execute($sql);
        if ($result) {
        	MoneyLog::insertAll($data);
        	return true;
        }
        return false;
	}
}