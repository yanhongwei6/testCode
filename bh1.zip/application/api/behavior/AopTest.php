<?php
namespace app\api\behavior;
//行为类
class AopTest{
  //绑定api初始化
  public function apiInit(&$params){
   //参数获取
   $id = input('id');//获取请求参数
   $uid = session('UID');//获取session 登录uid
   //打印输出
   echo PHP_EOL.'<br/>';
   echo 'ip检查'.$params.' GET:'.$id.'<br/>';
   echo ' uid='.$uid.'<br/>';
   echo PHP_EOL.'<br/>';
   //获取当前模块 控制器名 方法名称
   $request= \think\Request::instance();
   $controller_name = $request->controller();
   $model_name = $request->module();
   $action_name = $request->action();
   echo ' controller_name='.$controller_name.' model_name='.$model_name.' action_name='.$action_name.'<br/>';
   //构建数组
   $data = array();
   $data['status'] = 0;
   $data['msg'] = '没有权限';
   //exit(json_encode($data));//以json格式返回数据
  }
  //绑定api结束
  public function apiEnd(&$params){
   echo PHP_EOL;
   echo '日志记录'.$params;
   echo PHP_EOL;
  }
}