<?php

namespace app\api\behavior;
use app\common\model\Qishu;
use redis\Redis;
/**
 * 
 */
class OpenNumber
{
	/**
	 * 存入开奖号
	 * @param $type string 游戏
     * @param $number array 开奖号
	 */
	public function qishuOpenNumber(&$param){
        $type = $param['type'];
        $issue = $param['issue'];
        $number = $param['number'];
        if (!$type) {
            return false;
        }
        $gameId = \app\common\model\Game::where('sign',$type)->value('id');
		$num = implode(',', $number);
        $where = [
            'game' => $gameId,
            'issue' => $issue
        ];
        $qishu = Qishu::where($where)->find();
        if (empty($qishu)||($qishu&&$qishu->number)) {
            return false;
        }
        $qishu->number = $num;
        $qishu->opentime = time();
        $qishu->save();
        return true;
	}
    /**
     * 结算平台入账
     */
    public function qishuOpenResult(&$param){
        $betall = $param['bet_all'];
        $winall = $param['win_all'];
        $type = $param['type'];
        $issue = $param['issue'];
        if (!$type) {
            return false;
        }
        $gameId = \app\common\model\Game::where('sign',$type)->value('id');
        $where = [
            'game' => $gameId,
            'issue' => $issue
        ];
        $qishu = Qishu::where($where)->find();
        if (!empty($qishu)) {
            $qishu->bettotal = $betall;
            $qishu->winlos = $winall- $betall;
            $qishu->save();
        }
    }
    /**
     * 庄家结算
     */
    public function dealerSettlement(&$param){
        $config = config('redis');
        $redis = new Redis($config);
        $betLarge = $param['bet_large'];
        $betLittle = $param['bet_little'];
        $betall = $param['betall'];
        $number = $param['number'];
        $rushVillageUser = json_decode($redis->get('rush_village_user'),true);
        if (empty($rushVillageUser['userid'])) return true;
        $screenMoney = $rushVillageUser['screen_money'];
        $where = [
            'userid' => $rushVillageUser['userid'],
            'issue'  => $param['issue'],
            'gameid' => \app\common\model\Game::where('sign',$param['type'])->value('id')
        ];
        $zhuangInfo = \app\common\model\VillageRecord::where($where)->find();
        if (empty($zhuangInfo)) return true;
        $userinfo = \app\common\model\User::where('id',$rushVillageUser['userid'])->column('money,score','id');
        if ($number[0] == $number[1]&&$number[1] == $number[2]) {
           //开豹子
           $zhuangInfo->winlose = $betall/2;
           $zhuangInfo->save();
           $after = (float)$userinfo['money'] + (float)$betall/2;
           $memo = '庄家结算（豹子）';
           $money =  $betall/2;
        }else{
            $nums = array_sum($number)%10;
            $winlose = $betLarge - $betLittle;
            if (!$winlose) return false;
            if ($nums > 4) {
                if ( $winlose > 0 ) {
                    if ($winlose > $screenMoney) {
                        $money = $screenMoney;
                    }else{
                        $money = $winlose;
                    }
                    $memo = '庄家赢(大)';
                }else{
                    if ( abs($winlose) > $screenMoney ) {
                        $money = -$screenMoney;
                    }else{
                        $money = -$winlose;
                    }
                    $memo = '庄家输(小)';
                }
            }else{
                if ($winlose > 0 ) {
                    if ($winlose > $screenMoney ) {
                        $money = -$screenMoney;
                    }else{
                        $money = -$winlose;
                    }
                    $memo = '庄家输(小)';
                }else{
                    if ( abs($winlose) > $screenMoney ) {
                        $money = $screenMoney;
                    }else{
                        $money = $winlose;
                    }
                    $memo = '庄家赢(大)';
                }
            }
            $after = (float)$userinfo['money'] + (float)$money;
        }
        $data = [
            'userid'  => $rushVillageUser['userid'],
            'money'   => $money,
            'before'  => $userinfo[$rushVillageUser['userid']],
            'after'   => $after,
            'memo'    => $memo,
            'createtime' => time()
       ];
       //庄家修改金额
       \app\common\model\User::where('id',$rushVillageUser['userid'])->update(['money'=>$after]);
       //添加上庄日志
       \app\common\model\MoneyLog::create($data);
       return true;
    }
}