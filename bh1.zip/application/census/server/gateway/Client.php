<?php

namespace app\census\server\gateway;
use GatewayClient\Gateway;
use app\common\model\User;
use think\Cache;
class Client
{

    const  REGISTER_IP = '127.0.0.1:1238';

    const  REGISTER_PORT = '1238';

    /**
     * 绑定socket信息
     * @param $clientId str
     * @param $userId int 绑定会员ID
     * @param $groupId str 房间号
     * @param $type 通信类型 chat=聊天 packet=红包
     * @param $bindGroup int 是否绑定房间
     */
    public static function bindUid($clientId,$userId=0,$groupId=0,$type='chat',$bindGroup=0,$isAdmin=0){
        Gateway::$registerAddress = self::REGISTER_IP.':'.self::REGISTER_PORT;
        Gateway::bindUid($clientId, $userId);
        if ($bindGroup&&$userId) 
        {   
            if (!is_numeric($userId)) {
                $userinfo = [
                    'id'    => $userId,
                    'nickname' => '遊客',
                    'avatar'   => config('site.default_header_image'),
                    'client_id'=> $clientId,
                    'type'  => 'visitor'
                ];
            }else{
                if ($isAdmin) {
                    $userinfo = 'admin_'.$userId;
                }else{
                    $userinfo = User::get_user_info($userId);
                }
            }
            $message = [
                'type' =>'join',
                'content' => [
                    'msg'   => '加入房间',
                    'userinfo' => $userinfo,
                    'cache'=>['datacache'=>Cache::get($clientId),'time'=>time(),'room'=>$groupId]
                ]
            ];
            Gateway::joinGroup($clientId, $groupId);
            Gateway::sendToGroup($groupId,json_encode($message));
        }
    }
    /**
     * 监听发红包事件
     * @param $data 向团组发送数据
     * @param $groupId 团组ID
     */
    public static function sendPacket($data,$groupId=0){
        Gateway::$registerAddress = self::REGISTER_IP.':'.self::REGISTER_PORT;
        $data['type'] = 'packet';
        Gateway::sendToGroup($groupId, json_encode($data));
    }
    /**
     * 获取房间里面的ID
     * @param $groupId 团组房间号ID
     */
    public static function getUserIdInGroup($groupId){
        Gateway::$registerAddress = self::REGISTER_IP.':'.self::REGISTER_PORT;
        $uidArr = Gateway:: getUidListByGroup($groupId);
        return $uidArr;
    }
    /**
     * 获取UID下绑定的clientId
     *
     */
    public static function getClientByUid($uid){
        Gateway::$registerAddress = self::REGISTER_IP.':'.self::REGISTER_PORT;
        $clientArr = Gateway::getClientIdByUid($uid);
        if (empty($clientArr)) {
            return ['code'=>1,'data'=>['targe'=>$uid,'arr'=>$clientArr]];
        }else{
            return ['code'=>0,'data'=>['uid'=>$uid,'client'=>$clientArr]];
        }
    }
    /**
     * 发送消息给所有人
     * $betall float 下注金额
     */
    public static function setDatatoAll($betall){
        Gateway::$registerAddress = self::REGISTER_IP.':'.self::REGISTER_PORT;
        $message = ['type'=>'admin','money'=>$betall];
        Gateway::sendToAll(json_encode($message));
    }
}
