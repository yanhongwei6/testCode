<?php

namespace app\census\server\swoole;


class Client
{

    public static function client(){
        /**
         * 创建--同步--客户端
         * 需要等待服务端处理完 才能接收到数据
         */
         
        //创建对象
        $client = new Swoole\Client(SWOOLE_SOCK_TCP,SWOOLE_SOCK_SYNC);//创建tcp socket(默认ipv4)  同步客户端
         
        //连接内网
        /**
         * 参数1 地址  参数2 端口  参数3 连接时间
         */
        if($client->connect('服务器内网ip',9501,5000)){//如果连接成功
            //客户端发送数据
            $client->send('我是张泽山');
        };
         
        //接收返回信息  从服务器端接收数据
        $response = $client->recv();
        echo $response.PHP_EOL;
         
        //关闭客户端
        $client->close();
    }

    

}
