<?php

namespace app\census\controller;

use app\common\controller\Frontend;
use GatewayClient\Gateway;
use app\index\server\gateway\Client;
class Calculus extends Frontend
{
    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';
    protected $layout = 'default';
    protected $action;
    private $act_index,$act_log,$act_explain,$act_interface,$act_results;
    //面包削
    public function _initialize()
    {
        parent::_initialize();
        switch ($this->request->action()) {
            case 'log':
                $this->act_log = 'active';
                break;
            case 'explain':
                $this->act_explain = 'active';
                break;
            case 'interface':
                $this->act_interface = 'active';
                break;
            case 'results':
                $this->act_results = 'active';
                break;
            default:
                $this->act_index = 'active';
                break;
        }
        $this->view->assign('')
        $this->view->assign('active',['index'=>$this->act_index,'log'=>$this->act_log,'explain'=>$this->act_explain,'interface'=>$this->act_interface,'results'=>$this->act_results]);
    }
    /**
     * qq人数在线统计
     */
    public function index()
    {
        

        return $this->view->fetch();
    }
    /**
     * 动态展示
     */
    public function log(){


        return $this->view->fetch('log');
    }
    /**
     * 统计说明
     */
    public function explain(){


        return $this->view->fetch('shuoming');
    }
    /**
     * 接口调用
     */
    public function interface(){


        return $this->view->fetch('jiekou');
    }
    public function results(){

        return $this->view->fetch('result');
    }
}
