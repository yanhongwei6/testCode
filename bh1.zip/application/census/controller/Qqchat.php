<?php

namespace app\census\controller;

use app\common\controller\Frontend;
use GatewayClient\Gateway;
use app\index\server\gateway\Client;
class Qqchat extends Frontend
{
    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';
    protected $layout = 'default';
    protected $action;
    private $act_index,$act_show,$act_explain,$act_interface;
    //面包削
    public function _initialize()
    {

        parent::_initialize();
        switch ($this->request->action()) {
            case 'show':
                $this->act_show = 'active';
                break;
            case 'explain':
                $this->act_explain = 'active';
                break;
            case 'interface':
                $this->act_interface = 'active';
                break;
            default:
                $this->act_index = 'active';
                break;
        }
        $this->view->assign('active',['index'=>$this->act_index,'show'=>$this->act_show,'explain'=>$this->act_explain,'interface'=>$this->act_interface]);
        trace($this->action);
    }
    /**
     * qq人数在线统计
     */
    public function index()
    {
        

        return $this->view->fetch();
    }
    /**
     * 动态展示
     */
    public function show(){


        return $this->view->fetch('zhanshi');
    }
    /**
     * 统计说明
     */
    public function explain(){


        return $this->view->fetch('shuoming');
    }
    /**
     * 接口调用
     */
    public function interface(){


        return $this->view->fetch('jiekou');
    }
}
