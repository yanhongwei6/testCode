<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\phpstudy_pro\WWW\bh\addons\recharge\view\hook\user_sidenav_after.html";i:1575946187;}*/ ?>
<ul class="list-group">
    <li class="list-group-heading"><?php echo __('充值中心'); ?></li>
    <li class="list-group-item <?php echo $actionname=='recharge'?'active':''; ?>"><a href="<?php echo url('index/recharge/recharge'); ?>"><i class="fa fa-cny fa-fw"></i> <?php echo __('充值余额'); ?></a></li>
    <li class="list-group-item <?php echo $actionname=='moneylog'?'active':''; ?>"><a href="<?php echo url('index/recharge/moneylog'); ?>"><i class="fa fa-list fa-fw"></i> <?php echo __('余额日志'); ?></a></li>
</ul>