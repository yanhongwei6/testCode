<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:78:"D:\phpstudy_pro\WWW\bh\public/../application/census\view\tencent\shuoming.html";i:1579178726;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\layout\default.html";i:1579178611;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\common\tenmenu.html";i:1579178780;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>首页</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/style.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/responsive.css">
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 header-top">
                    <img src="http://www.77tj.org/assets/images/logo.png" class="logo" alt="亿豪统计">
                </div>
                <div class="col-md-8 header-top header-top-menu">
                    <span>
                        <a href="<?php echo url('qqchat/index'); ?>" class="active">QQ在线统计</a>
                        <a href="<?php echo url('tencent/index'); ?>">腾讯在线统计</a>
                        <a href="<?php echo url('calculus/index'); ?>">数据演算</a>
                    </span>
                </div>
            </div>
        </div>
        <div class="header-top-image">
            <div>
                <p><img alt="" src="http://www.77tj.org/assets/images/time.png">2020-01-08 15:45:00&nbsp;&nbsp; 腾讯同时在线人数</p>
                <p><strong>314,415,591</strong>历史最高：335,684,644</p>
                <span>所有数据均来自腾讯</span>
            </div>
        </div>
        <div class="container">
	<div class="row container-content">
		<div class="col-md-2">
 	<a href="<?php echo url('tencent/index'); ?>" class="<?php echo $active['index']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon1.png">统计结果</a>
    <a href="<?php echo url('tencent/show'); ?>" class="<?php echo $active['show']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon2.png">动态展示</a>
    <a href="<?php echo url('tencent/explain'); ?>" class="<?php echo $active['explain']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon3.png">统计说明</a>
    <a href="<?php echo url('tencent/interface'); ?>" class="<?php echo $active['interface']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon4.png">接口调用</a>
</div>
        <div class="col-md-10">
         	<p><strong style="color:red">统计说明：由于腾讯QQ在线在刷新或重新打开“腾讯官网”、“动态展示”页面时数据会发生变化，</strong> </p>
			<p><strong style="color:red">所以本站采集腾讯官网当时时间点的实时数据，以供用户查询腾讯QQ在线历史数据。</strong></p>
			<p>查询最新在线人数：打开浏览器输入“im.qq.com”进入点击页面右上角的“当前在线人数” </p>
			<p>如图：<br><img alt="" src="http://www.77tj.org/assets/images/laiyuan1.png"></p>
			<p>等页面加载完成后拖动底部的按钮查询某时间点，整分钟的在线人数显示在顶部；</p>
			<p>如图：<br><img alt="" src="http://www.77tj.org/assets/images/laiyuan2.png"></p>
			<p>页面刷新或打开新的页面所查询的数据，因腾讯缓存技术数据会产生变化，本站不做记录。详情请查</p>
			<p>看顶部的“统计说明”。亦可在本网站的“动态展示”中查询历史数据，所有数据均来源于腾讯，查</p>
			<p>询方式跟官网查询一致。</p>
			<p>备注：统计数据全部来源于<a href="https://im.qq.com/" style="text-decoration:underline;" target="_blank">腾讯官网</a>,每分钟腾讯QQ在线人数的数据。</p>
        </div>
    </div>
</div>
        <div class="footer">
            <p>Copyright © 1998- 2016 HuaQi. All Rights Reserved.</p>
            <p>华旗公司 版权所有</p>
        </div>
        <script type="text/javascript" scr="/assets/static/js/jquery.3.4.1.js"></script>
    </body>
</html>