<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:73:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\index.html";i:1577847426;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<div class="vipcenter">
    <div class="vipheader">
    <a href="userinfo.html">
    <div class="touxiang"><img src="<?php echo cdnurl($user['avatar']); ?>" alt=""></div>
    <div class="name"><?php echo $user['nickname']; ?></div>
    <div class="gztt">认证会员，已关注</div>
    </a>
    </div>
    <div class="vipsan">
    <div class="col-xs-4 text-center"><a><h4>等级</h4><p>Vip1</p></a></div>
    <div class="col-xs-4 text-center"><a><h4><?php echo __('Money'); ?></h4><p><?php echo $user['money']; ?></p></a></div>
    <div class="col-xs-4 text-center"><a><h4><?php echo __('Score'); ?></h4><p><?php echo $user['score']; ?></p></a></div>
    </div>
    <ul class="vipul">
      <li>
        <a href="<?php echo url('center/auth'); ?>">
          <div class="icc"><i class="iconfont icon-xitongmingpian"></i></div>
          <div class="lzz">会员认证</div>
          <?php if($auth_status == 'created'): ?>
            <div class="rizi lvzi">
              审核中
            </div>
          <?php elseif($auth_status == 'succeed'): ?>
            <div class="rizi lvzi">
              已认证
            </div>
          <?php else: ?>
            <div class="rizi">
              <i class="iconfont icon-jiantouri"></i>
            </div>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="#">
         <div class="icc"><i class="iconfont icon-huodongfj"></i></div>
         <div class="lzz">活动中心</div>
         <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
        </a>
      </li>
      <li>
        <a href="<?php echo url('center/ddcenter'); ?>">
         <div class="icc"><i class="iconfont icon-liebiao"></i></div>
         <div class="lzz">记录中心</div>
         <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
        </a>
      </li>
      <li>
        <a href="<?php echo url('center/userinfo'); ?>">
          <div class="icc"><i class="iconfont icon-yonghux"></i></div>
          <div class="lzz">个人资料</div>
          <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
        </a>
      </li>
      <li>
          <a href="<?php echo url('center/signin'); ?>">
            <div class="icc"><i class="iconfont icon-qiandao"></i></div>
            <div class="lzz">用户签到</div>
            <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
          </a>
      </li>
      <li>
          <a href="<?php echo url('center/invite'); ?>">
            <div class="icc"><i class="iconfont icon-sanjiaozuo"></i></div>
            <div class="lzz">邀请好友</div>
            <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
          </a>
      </li>
      <li>
          <a href="<?php echo url('center/recharge'); ?>">
            <div class="icc"><i class="iconfont icon-chakangonglve"></i></div>
            <div class="lzz">充值中心</div>
            <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
          </a>
      </li>
      <li>
          <a href="javascript:;" check_auth coco-url="<?php echo url('center/recharge'); ?>">
            <div class="icc"><i class="iconfont icon-jifeny"></i></div>
            <div class="lzz">用户提现</div>
            <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
          </a>
      </li>
      <li>
          <a href="javascript:;" login_out coco-url="<?php echo url('index/user/logout'); ?>">
            <div class="icc"><i class="iconfont icon-tuichux"></i></div>
            <div class="lzz">退出</div>
            <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
          </a>
      </li>
    </ul>
</div>
<script type="text/javascript">
  $(document).on("click","*[check_auth]",function(){
        var url = $(this).attr("href");
        if(!url){
            url = $(this).attr("coco-url");
        }
        $.ajax({
            type:"POST",
            url:"/api/user/check_auth",
            dataType:"JSON",
            success:function(result){
                if (!result.code) {
                    layer.msg(result.msg);
                    return false;
                }else if(result.code == 10){
                  coco_confirm(result.msg,function() {
                      location.href = '/index/center/auth';
                  }, '', function() {
                      return false;
                  });
                }else{
                  location.href = '/index/center/cash';
                }
            },
            error:function(XMLHttpRequest, textStatus, errorThrown){
                var codetext = XMLHttpRequest.responseText;
                codejson = eval("(" + codetext + ")");
                console.log(codejson);
            }
        })

        return false;
    })
  $(document).on("click","*[login_out]",function(){
      var url = $(this).attr("coco-url");
      $.ajax({
          type:"POST",
          url:url,
          dataType:"JSON",
          success:function(result){
              console.log(result);
              layer.msg(result.msg);
              if (result.code == 1) {
                  layer.msg(result.msg);
                  return false;
              }
          },
          error:function(XMLHttpRequest,textStatus,errorThrown){
              var codetext = XMLHttpRequest.responseText;
              codejson = eval("(" + codetext + ")");
              console.log(codejson);
          }
      })
  })
</script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>