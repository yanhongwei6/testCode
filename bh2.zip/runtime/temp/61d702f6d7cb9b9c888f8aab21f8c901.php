<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\phpstudy_pro\WWW\bh\addons\withdraw\view\hook\user_sidenav_after.html";i:1575946328;}*/ ?>
<ul class="list-group">
    <li class="list-group-heading"><?php echo __('提现中心'); ?></li>
    <li class="list-group-item <?php echo $actionname=='withdraw'?'active':''; ?>"><a href="<?php echo url('index/withdraw/withdraw'); ?>"><i class="fa fa-dollar fa-fw"></i> <?php echo __('余额提现'); ?></a></li>
    <li class="list-group-item <?php echo $actionname=='moneylog'?'active':''; ?>"><a href="<?php echo url('index/withdraw/withdrawlog'); ?>"><i class="fa fa-list fa-fw"></i> <?php echo __('提现日志'); ?></a></li>
</ul>