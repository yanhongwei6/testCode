<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:76:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\ddcenter.html";i:1577533034;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<style type="text/css">
   .active{
      background: none;
   }
</style>
<!-- <div class="menu-wrap">
   <nav class="menu">
      <div class="icon-list">
         <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
         <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
         <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
         <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
         <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
      </div>
   </nav>
   <button class="close-button" id="close-button">Close Menu</button>
	<div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
		<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
			<path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
		<desc>Created with Snap</desc><defs></defs></svg>
	</div>
</div> -->
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
	<a class="navbar-tit center-block">记录中心</a>
	<button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<br>
<ul id="myTab" class="nav nav-tabs">
   <li class="<?php if(!$targe): ?>active<?php endif; ?>"><a href="#sp1" data-toggle="tab">充值记录</a>
   </li>
   <li class="<?php if($targe): ?>active<?php endif; ?>"><a href="#sp2" data-toggle="tab">提现记录</a></li>
</ul>

<div id="myTabContent" class="tab-content">
   <div class="tab-pane fade <?php if(!$targe): ?>active in<?php endif; ?>" id="sp1">
      <ul class="ddlist" id="recharge-list" template coco-tag="recharge" coco-url="<?php echo url('api/record/rechargeRecord'); ?>" coco-data="{}" ajax-callback="suc_rec_back">
         
      </ul>
   </div>
   <div class="tab-pane fade <?php if($targe): ?>active in<?php endif; ?>" id="sp2">
     <ul class="ddlist" id="cash-list" template coco-tag="cash" coco-url="<?php echo url('api/record/cashRecord'); ?>" coco-data="{}" ajax-callback="suc_cas_back">
         
      </ul>
   </div>
</div>
<script type="text/html" id="recharge-tpl">
   {{# layui.each(d.data.list,function(index,item){ }}
   <li>
      <a href="javascript:;" class="rech-order" data-id="{{item.id}}">
         <p>订单时间：{{item.createtime_text}}</p>
         <p>订单号：{{item.orderid}}</p>
         <p><span>充值金额：{{item.amount}} 元</span></p>
         {{# if(item.status == 'created'){ }}
         <p>状态：<a href="javascript:;" class="btn btn-xs btn-primary">{{item.status_text}}</a></p>
         {{# }else if(item.status == 'paid'){ }}
         <p>状态：<a href="javascript:;" class="btn btn-xs btn-success">{{item.status_text}}</a></p>
         {{# }else if(item.status == 'refuse'){ }}
         <p>状态：<a href="javascript:;" class="btn btn-xs btn-danger">{{item.status_text}}</a></p>
         {{# }else if(item.status == 'expired'){ }}
         <p>状态：<a href="javascript:;" class="btn btn-xs btn-primary">{{item.status_text}}</a></p>
         {{# }else{ }}
         未知
         {{# } }}
      </a>
   </li>
   {{# }) }}
</script>
<script type="text/html" id="cash-tpl">
   {{# layui.each(d.data.list,function(index,item){ }}
   <li>
      <a href="javascript:;" class="cash-order" data-id="{{item.id}}">
         <p>订单时间：{{item.createtime_text}}</p>
         <p>订单号：{{item.orderid}}</p>
         <p>提现金额：{{item.money}}</p>
         <p>提现方式：{{# if(item.type == 'wechat'){ }}微信{{# }else if(item.type == 'alipay'){ }}支付宝{{# }else{ }}银行卡{{# } }}</p>
         <p><span>状态：
            {{# if(item.status == 'created'){ }}
            <a href="javascript:;" class="btn btn-xs btn-primary">{{item.status_text}}</a>
            {{# }else if(item.status == 'successed'){ }}
            <a href="javascript:;" class="btn btn-xs btn-success">{{item.status_text}}</a>
            {{# }else if(item.status == 'forzen'){ }}
            <a href="javascript:;" class="btn btn-xs btn-success">{{item.status_text}}</a>
            {{# }else if(item.status == 'complete'){ }}
            <a href="javascript:;" class="btn btn-xs btn-success">{{item.status_text}}</a>
            {{# }else if(item.status == 'rejected'){ }}
            <a href="javascript:;" class="btn btn-xs btn-danger">{{item.status_text}}</a>
            {{# } }}
         </span></p>
      </a>
   </li>
   {{# }) }}
</script>
<div class="rech-detail" style="display: none;">
   <div class="rech-content">
      <div class="rech-detail-title">充值详情</div>
      <div class="rech-detail-content">
         <a href="javascript:;" class="rech-order"> 
            <p><span class="rech-order-title">订单时间</span>：<span class="rech-order-time">2019-10-10 15:33:22</span></p>
            <p><span class="rech-order-title">订单号</span>：<span class="rech-order-str">0000000000000</span></p>
            <p><span class="rech-order-title">充值人</span>：<span class="rech-order-people">张三</span></p>
            <p><span class="rech-order-title">充值金额</span>：<span class="rech-order-money">0.00</span>元</p>
            <p><span class="rech-order-title">状态</span>：<span class="rech-order-status"></span></p>
            <p><span class="rech-order-title">备注</span>：<span class="rech-order-content"></span> </p>
         </a>
      </div>
      <div class="rech-btn">
         <a href="javascript:;" class="btn btn-lg btn-success btn-close-details">确定</a>
      </div>
   </div>
</div>
<div class="cash-detail" style="display: none;">
   <div class="cash-content">
      <div class="cash-detail-title">提现详情</div>
      <div class="cash-detail-content">
         <a href="javascript:;" class="cash-order">
            <p><span class="cash-order-title">订单时间</span>：<span class="cash-order-time">2019-10-10 15:33:22</span></p>
            <p><span class="cash-order-title">订单号</span>：<span class="cash-order-str">0000000000000</span></p>
            <p><span class="cash-order-title">提现方式</span>：<span class="cash-order-type">张三</span></p>
            <p><span class="cash-order-title">提现金额</span>：<span class="cash-order-money">0.00</span>元</p>
            <p><span class="cash-order-title">手续费</span>：<span class="cash-order-handingfee">0.00</span>元</p>
            <p><span class="cash-order-title">税费</span>：<span class="cash-order-taxes">0.00</span>元</p>
            <p><span class="cash-order-title">状态</span>：<span class="cash-order-status"></span></p>
            <p><span class="cash-order-title">备注</span>：<span class="cash-order-content">11111</span> </p>
         </a>
      </div>
      <div class="rech-btn">
         <a href="javascript:;" class="btn btn-lg btn-success btn-close-cash-details">确定</a>
      </div>
   </div>
</div>
<script type="text/javascript">
   function suc_rec_back(obj,datajson){
      for (var i = 0; i < datajson.data.list.length; i++) {
         addStorege('recharge_record_'+datajson.data.list[i].id,JSON.stringify(datajson.data.list[i]));
      }
   }
   function suc_cas_back(obj,datajson){
      for (var i = 0; i < datajson.data.list.length; i++) {
         addStorege('cash_record_'+datajson.data.list[i].id,JSON.stringify(datajson.data.list[i]));
      }
   }
</script>

	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>