<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\auth.html";i:1577446846;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<div class="menu-wrap">
  <nav class="menu">
    <div class="icon-list">
      <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
      <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
      <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
      <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
      <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
    </div>
  </nav>
  <button class="close-button" id="close-button">Close Menu</button>
  <div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
      <path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
    <desc>Created with Snap</desc><defs></defs></svg>
  </div>
</div>
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
  <a class="navbar-tit center-block">个人信息</a>
  <button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<div class="usercenter  accdv">
    <input type="hidden" id="show" value="<?php echo $show; ?>">
    <form class="userset-form tm-input-view" id="formid">
      <div class="row">
        <div class="col-md-2">真实姓名：</div>
        <div class="col-md-10">
          <input type="text" name="truename" class="form-control" placeholder="请输入真实姓名" value="<?php echo $info->truename; ?>">
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">身份证号：</div>
        <div class="col-md-10">
          <input type="text" name="idcard" class="form-control" placeholder="请输入您的身份证号码" value="<?php echo $info->idcard; ?>">
        </div>
      </div>
      <div class="row">
          <div class="col-md-2">出生年月：</div>
          <div class="col-md-10">
            <input type="text" name="birthday" id="datetime" class="form-control" value="<?php echo $info['birthday']; ?>">
          </div>
      </div>
      <div class="row" style="margin: 0 auto;">
        <div class="col-md-2">认证收款方式：</div>
        <div class="col-md-10">
          <div class="form-group m-r-10">
            <select class="form-control" name="payment_method" id="payment_method">
              <option value="alipay" selected="selected">支付宝</option>
              <option value="wechat">微信</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row alipay" style="margin: 0 auto;">
          <div class="col-md-2">支付宝账号：</div>
          <div class="col-md-10">
            <input type="text" name="alipay" class="form-control" placeholder="请输入支付宝账号" value="<?php echo !empty($info['alipay'])?$info['alipay']: ''; ?>">
          </div>
      </div>
      <div class="row wechat" style="display: none;margin: 0 auto;">
          <div class="col-md-2">微信号：</div>
          <div class="col-md-10">
            <input type="text" name="wechat" class="form-control" placeholder="请输入微信账号" value="<?php echo !empty($info['wechat'])?$info['wechat']: ''; ?>">
          </div>
      </div>
      <div class="row">
        <div class="col-md-2">身份证正面：</div>
        <div class="col-md-10 card-front" front coco_upload ajax-url="/api/common/upload" ajax-callback="suc_image" need-nums="1">
          <input type="hidden" name="card_front" id="front" class="form-control input-image" value="<?php echo !empty($info['card_front_image'])?$info['card_front_image']: ''; ?>">
          <div class="upload_file">
              <div class="item-head">
                <div class="thumb-img">
                </div>
              </div>
              <i class=""></i>
              <img src="<?php echo !empty($info['card_front_image'])?$info['card_front_image']: '/static/images/front.jpg'; ?>" class="front-image" style="width: 100%;height:100%">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">身份证反面：</div>
        <div class="col-md-10 card-back" front coco_uploads ajax-url="/api/common/upload" ajax-callback="suc_image" need-nums="1">
          <input type="hidden" name="card_back" id="back" class="form-control input-image" value="<?php echo !empty($info['card_back_image'])?$info['card_back_image']: ''; ?>">
          <div class="uploads_file">
              <div class="item-head">
                <div class="thumb-img">
                </div>
              </div>
              <i class=""></i>
              <img src="<?php echo !empty($info['card_back_image'])?$info['card_back_image']: '/static/images/back.jpg'; ?>" class="back-image" style="width: 100%;height: 100%">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10"><button type="button" class="btn btn-danger btn-block btn-lg submit-userinfo" coco_post_form_ajax coco-url="<?php echo url('api/user/userauth'); ?>" formid="formid" ajax-callback="back_fun">确 定</button></div>
      </div>
    </form>
  </div>
  <div class="show-tips" style="display: none;">
    <div class="show-content">
      <div class="show-tips-title"><h3>拒绝提示</h3></div>
      <div class="show-tips-content">
        您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证您的认证资料与身份证真实信息不符，请重新认证
      </div>
      <div><a href="javascript:;" class="btn btn-close-tips">确定</a></div>
    </div>
  </div>
  <script type="text/javascript">
    function suc_image(obj,datajson,type){
      if (type == 'back') {

        $("#back").val(datajson.data.url);
        $(".back-image").attr('src',datajson.data.url);
      }else{
        $("#front").val(datajson.data.url);
        $(".front-image").attr('src',datajson.data.url);
      }
    }
    function back_fun(obj,datajson){
      layer.msg(datajson.msg);
      if (datajson.code == 1) {
        setTimeout(function(){
          window.location.href="index/center/index";
        },1500)
      }
    }
    layui.use(['upload','laydate'], function() {
      var laydate = layui.laydate;
      laydate.render({
        elem: '#datetime' //指定元素
          ,
        theme: '#3B96FF'
      });
      var upload = layui.upload;
       $("*[coco_uploads]").each(function(){
            obj = $(this);
            var url = obj.attr('ajax-url');
            var ajax_callback = obj.attr('ajax-callback');
            var multiple = obj.attr('multiple');
            var image_nums = 1;
            var need_nums = obj.attr('need-nums') ;
            if (need_nums == 'func') {
                var numsfun = obj.attr('numsfun');
                image_nums = eval(numsfun)(obj);
                if (isEmpty(image_nums)) {
                    return false;
                }
            }
            var datajson = {};
            var datastr = obj.attr('ajax-data');
            if(datastr == 'func'){
                var datafun = obj.attr("datafun");
                datajson = eval(datafun)(obj);
                if(!datajson){
                    return false;
                }
            }else{
                datajson = eval("(" + datastr + ")");
            }
            var uploadIndex = upload.render({
                elem: '.uploads_file'
                ,url: url
                ,headers: {token:token,timestamp:timestamp} // 请求头部信息
                ,acceptMime: 'image/*' //筛选出的文件类型
                ,accept: 'images' //指定允许上传时校验的文件类型，可选值有：images（图片）、file（所有文件）、video（视频）、audio（音频）
                // ,exts: true //允许上传的文件后缀。一般结合 accept 参数类设定
                ,size: 5000 //最大允许上传的文件大小
                ,field: 'file'
                ,method: 'post'  //可选项。HTTP类型，默认post
                ,data: datajson //可选项。额外的参数，如：{id: 123, abc: 'xxx'}
                ,auto: true //选择文件后不自动上传
                // ,multiple: isEmpty(multiple) ? false : true //允许多文件上传。设置 true即可开启
                // ,number: image_nums //设置同时可上传的文件数量
                // ,drag: false   //是否接受拖拽的文件上传，设置 false 可禁用。
                // ,bindAction: '#testListAction' //指向一个按钮触发上传
                ,error: function(index, upload){
                    coco_close_loading();
                    coco_confirm('是否重新上传？', function() {
                        uploadIndex.upload();
                    })
                }
                ,done: function(datajson, index, upload){
                    console.log(datajson,'111');
                    coco_close_loading();
                    if(ajax_callback)
                        eval(ajax_callback)(obj,datajson,'back');
                }
            });
            $('.uploads_file').next().hide();
        });
    });

  </script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>