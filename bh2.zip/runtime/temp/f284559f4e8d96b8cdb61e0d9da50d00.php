<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:76:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\userinfo.html";i:1577349483;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<div class="menu-wrap">
  <nav class="menu">
    <div class="icon-list">
      <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
      <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
      <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
      <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
      <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
    </div>
  </nav>
  <button class="close-button" id="close-button">Close Menu</button>
  <div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
      <path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
    <desc>Created with Snap</desc><defs></defs></svg>
  </div>
</div>
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
  <a class="navbar-tit center-block">个人信息</a>
  <button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<div class="usercenter  accdv">
    <form class="userset-form tm-input-view" id="formid">
      <div class="row">
        <div class="col-md-10" front coco_upload ajax-url="/api/common/upload" ajax-callback="suc_image" need-nums="1">
          <input type="hidden" name="avatar" id="avatar" class="form-control" value="<?php echo $user->getData('avatar'); ?>">
          <div class="header-image  upload_file">
              <div class="item-head">
                <div class="thumb-img">
                </div>
              </div>
              <img src="<?php echo cdnurl($user['avatar']); ?>" id="show-image">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">昵称：</div>
        <div class="col-md-10">
          <input type="text" name="nickname" class="form-control" value="<?php echo $user['nickname']; ?>">
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">性别：</div>
        <div class="col-md-10">
          <label class="checkbox-inline">
            <input type="radio" name="gender" value="1" <?php if($user['gender']): ?>checked=""<?php endif; ?>> 男
          </label>
          <label class="checkbox-inline">
            <input type="radio" name="gender" value="0" <?php if(!$user['gender']): ?>checked=""<?php endif; ?>> 女
          </label>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">手机号：</div>
        <div class="col-md-10"><input type="text" name="mobile" class="form-control" value="<?php echo $user['mobile']; ?>"></div>
      </div>
      <div class="row">
        <div class="col-md-2">邮箱：</div>
        <div class="col-md-10"><input type="text" name="email" class="form-control" value="<?php echo $user['email']; ?>"></div>
      </div>
      <div class="row">
          <div class="col-md-2">生日：</div>
          <div class="col-md-10">
            <input type="text" name="birthday" id="datetime" class="form-control" value="<?php echo $user['birthday']; ?>">
          </div>
      </div>
      <div class="row">
        <div class="col-md-2">个人描述</div>
        <div class="col-md-10">
          <textarea class="form-control" rows="3" name="bio"><?php echo $user['bio']; ?></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-10"><button type="button" class="btn btn-danger btn-block btn-lg submit-userinfo" coco_post_form_ajax coco-url="<?php echo url('api/user/profile'); ?>" formid="formid" ajax-callback="back_fun">确 定</button></div>
      </div>
    </form>
  </div>
  
  <script type="text/javascript">
    function suc_image(obj,datajson){
      if (datajson.code == 1) {
        $("#avatar").val(datajson.data.url);
        $("#show-image").attr("src",datajson.data.url);
      }
    }
    function back_fun(obj,datajson){
      layer.msg(datajson.msg);
      if (datajson.code == 1) {
        setTimeout(function(){
          document.location.href="/index/center/index";
        },2000)
      }
    }
    layui.use('laydate', function() {
      var laydate = layui.laydate;
      laydate.render({
        elem: '#datetime' //指定元素
          ,
        theme: '#3B96FF'
      });
    });
  </script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>