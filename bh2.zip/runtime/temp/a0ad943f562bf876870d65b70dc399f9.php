<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\cash.html";i:1577842322;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<!-- <div class="menu-wrap">
   <nav class="menu">
      <div class="icon-list">
         <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
         <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
         <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
         <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
         <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
      </div>
   </nav>
   <button class="close-button" id="close-button">Close Menu</button>
	<div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
		<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
			<path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
		<desc>Created with Snap</desc><defs></defs></svg>
	</div>
</div> -->
<style type="text/css">
	.bind-bank-content{
		width: 98%;
		margin: auto;
		padding: 10px 5px;
	}
</style>
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
	<a class="navbar-tit center-block">提现</a>
	<button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<br>
<div class="cash-userinfo">
	<div class="cash-user-header"><img src="<?php echo $user['avatar']; ?>"></div>
	<div class="cash-user-info">
		<div class="cash-user-detail cash-user-username"><span><?php echo $user['nickname']; ?></span></div>
		<div class="cash-user-detail"><span>金额：</span><span class="cash-user-money"><?php echo $user['money']; ?></span>元</div>
		<div class="cash-user-detail"><a href="<?php echo url('center/ddcenter',['targe'=>1]); ?>" class="btn cash-btn-record">提现记录</a></div>
	</div>
</div>
<form id="formid">
	<?php echo token();; ?>
	<div class="cash-contents">
		<div>
			<ul>
				<li>
					<div class="cash-type-log">
						<img src="/static/images/alipay.jpg">
					</div>
					<div class="cash-type btn active" data-type="alipay">支付宝</div>
				</li>
				<li>
					<div class="cash-type-log">
						<img src="/static/images/wechat.png">
					</div>
					<div class="cash-type btn" data-type="wechat">微信</div>
				</li>
				<li>
					<div class="cash-type-log">
						<img src="/static/images/bank.png">
					</div>
					<div class="cash-type btn" data-type="bank">银行卡</div>
				</li>
			</ul>
		</div>
		
	</div>
	<input type="hidden" name="cashtype" value="alipay" id="cashtype">
	<div class="cash-content-username"><span class="cash-content-title">姓名</span><input type="text" class="cash-content-value cash-username" placeholder="请输入姓名" disabled="disabled"></div>
	<div class="cash-content-account"><span class="cash-content-title">提现账号</span><input type="text" class="cash-content-value cash-account" placeholder="请输入提现账号" disabled="disabled"></div>
	<div class="cash-content-account-bank" style="display: none;">
		<span class="cash-content-title cash-content-banklist">转出至：</span>
		<div class="cash-content-select">
			<input type="hidden" name="bankinfo" id="bankinfo">
			<div class="cash-content-select-content">
				<a href="javascript:;" class="bank-more bank-more-other">选择其他银行卡</a>
				<div class="lab selection-opt-bank bank-more bank-more-bankinfo" style="display: none;">
					<div class="bank">
						<span class="bank-icon">
							<img src="/static/images/zhaoshangLog.jpg">
						</span>
						<span class="bank-name">招商银行</span>
					</div>
					<div class="bank-last_num">
						尾号：(<span>4039</span>)
					</div>
				</div>
			</div>
			<div class="cash-bank-list" style="display: none;">
				<div class="selection-opt">
			    	<div class="selection-checked">
			    		<span class="actives"></span>
			    	</div>
					<div class="lab selection-opt-bank">
						<div class="bank">
							<span class="bank-icon">
								<img src="/static/images/zhaoshangLog.jpg">
							</span>
							<span class="bank-name">招商银行</span>
						</div>
						<div class="bank-last_num">
							尾号：(4039)
						</div>
					</div>
			    </div>
			    <a href="javascript:;" class="add-bank">
					<span class="icon">
						<img src="/static/images/add.png">
					</span>
					<span>添加新银行卡</span>
				</a>
			</div>
		</div>
	</div>
	<div class="cash-content-money">
		<span class="cash-content-title">提现金额</span>
		<input type="number" class="custom-input cash-content-value cash-content-value-price" name="cash_money" placeholder="请输入提现金额">
	</div>
	<div class="cash-content-tips">
		提现金额不少于<span style="color:#ff2626d9;">100</span>元，预计在<span style="color:#ff2626d9;">1-2</span>个工作日到账
	</div>
	<div class="cashinfo-btn">
	   <a href="javascript:;" class="btn btn-lg btn-danger btn-cash-submit-data" coco_post_form_ajax coco-url="<?php echo url('api/withdraw/cashChannel'); ?>" formid="formid" ajax-callback="back_fun">提交</a>
	</div>
</form>

<div id="tixian-list" noflow_template coco-tag="tixian" coco-url="<?php echo url('api/user/cashinfo'); ?>" coco-data="{}" ajax-callback="suc_tixian"></div>
<script type="text/html" id="tixian-tpl"></script>
<script type="text/html" id="bind-bank">
	<div class="bind-bank-content">
		<form class="layui-form layui-form-pane" action="">
		  	<div class="layui-form-item">
			    <label class="layui-form-label">真实姓名</label>
			    <div class="layui-input-block">
			      	<input type="text" autocomplete="off" placeholder="请输入真实姓名" class="layui-input bind-bank-username" disabled="disabled">
			    </div>
		  	</div>
		  	<div class="layui-form-item">
			    <label class="layui-form-label">银行卡号</label>
			    <div class="layui-input-inline">
			      	<input type="text" name="number" lay-verify="bankrequire|bankrule" placeholder="请输入银行卡号" autocomplete="off" class="layui-input bank-number" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')">
			    </div>
		  	</div>
		  	<div class="layui-form-item">
		      	<label class="layui-form-label">所属银行</label>
		      	<div class="layui-input-inline">
			        <select name="modules" class="layui-input bankname" lay-filter="banklist" lay-search="banklist">
			          	<option value="default">请选择银行</option>
			          	<?php if(is_array($banklist) || $banklist instanceof \think\Collection || $banklist instanceof \think\Paginator): $i = 0; $__LIST__ = $banklist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
			          		<option value="<?php echo $item['bankcode']; ?>"><?php echo $item['bankname']; ?></option>
			          	<?php endforeach; endif; else: echo "" ;endif; ?>
			        </select>
		      	</div>
		    </div>
		  	<div class="layui-form-item">
			    <div class="layui-inline">
			      	<label class="layui-form-label">办卡网点</label>
			      	<div class="layui-input-block">
			        	<input type="text" name="address" id="address" lay-verify="bankaddressrequired" autocomplete="off" placeholder="请输入银行卡办卡网点" class="layui-input">
			      	</div>
			    </div>
			    <div class="layui-inline">
			      	<label class="layui-form-label">手机号码</label>
			      	<div class="layui-input-inline">
			        	<input type="text" placeholder="请输入银行预留手机号码" autocomplete="off" class="layui-input bind-bank-mobile" disabled="disabled">
			      	</div>
			    </div>
		  	</div>
		  	<div class="layui-form-item" pane="">
			    <label class="layui-form-label">是否默认</label>
			    <div class="layui-input-block">
			      	<input type="checkbox" checked="" name="open" lay-skin="switch" lay-filter="switchTest" title="开关">
			    </div>
		  	</div>
		  	<div class="layui-form-item" style="text-align: center;">
		    	<button class="layui-btn" lay-submit="" lay-filter="bindbank">确定</button>
		  	</div>
		</form>
	</div>
</script>

<script type="text/javascript">
   	$(document).ready(function(){  
      	bindKeyEvent($(".custom-input"));
   	});
   	function bindKeyEvent(obj){  
      obj.keyup(function () {  
         var reg = $(this).val().match(/\d+\.?\d{0,2}/);  
         var txt = '';  
         if (reg != null) {  
            txt = reg[0];  
         }  
         $(this).val(txt);  
      }).change(function () {  
         $(this).keypress();  
         var v = $(this).val();  
         if (/\.$/.test(v))  
         {  
            $(this).val(v.substr(0, v.length - 1));  
         }  
      });  
   	}
   	function back_fun(obj,datajson){
   		layer.msg(datajson.msg);
   		if (datajson.code == 1) {
   			setTimeout(function(){
   				document.location.href = datajson.data;
   			},2000)
   		}
   	}
   	function suc_tixian(obj,datajson){
   		$(".cash-username").val(datajson.data.authinfo.truename);
   		$(".bind-bank-username").val(datajson.data.authinfo.truename);
   		$(".cash-account").val(datajson.data.authinfo.alipay);
   		$(".bind-bank-mobile").val(datajson.data.authinfo.mobile);
   		var str = '';
   		for (var i = 0; i < datajson.data.banklist.length; i++) {
   			str += '<div class="selection-opt" data-targe="'+datajson.data.banklist[i].id+'"><div class="selection-checked">';
		    if (i == 0) {
		    	str += '<span class="actives"></span>';
		    }else{
		    	str += '<span></span>'
		    }		
		    str +='</div><div class="lab selection-opt-bank"><div class="bank"><span class="bank-icon"><img src="'+datajson.data.banklist[i].bankimg+'"></span><span class="bank-name">'+datajson.data.banklist[i].bankname+'</span></div><div class="bank-last_num">尾号：('+datajson.data.banklist[i].number+')</div></div></div>';
		    if (datajson.data.banklist[i].default == 'Y') {
		    	$(".bank-more-other").hide();
		    	$(".bank-more-bankinfo").find('.bank-icon').find('img').attr('src',datajson.data.banklist[i].bankimg);
		    	$(".bank-more-bankinfo").find(".bank-name").html(datajson.data.banklist[i].bankname);
		    	$(".bank-more-bankinfo").find(".bank-last_num").find('span').html(datajson.data.banklist[i].number);
		    	$("#bankinfo").val(datajson.data.banklist[i].id);
		    	$(".bank-more-bankinfo").show();

		    }
   		}
   		str += '<a href="javascript:;" class="add-bank"><span class="icon"><img src="/static/images/add.png"></span><span>添加新银行卡</span></a>';
		$(".cash-bank-list").html(str);
   		addStorege('cashinfo',JSON.stringify(datajson.data))
   	}
   	$(document).on("click",".cash-type",function(){
        var cashinfo = getStorege('cashinfo');
        cashinfo = JSON.parse(cashinfo);
        var type = $(this).data("type");
        switch(type){
            case 'alipay':
                if (!cashinfo.authinfo.alipay) {
                    coco_confirm('您未认证支付宝账号,是否认证？',function(){
                        layer.prompt({title: '请输入您的支付宝账号', formType: 3}, function(data, index){
                            ajaxpost('alipay',data);
                            layer.close(index);
                        });
                    });
                    return false;
                }
                $(".cash-content-account").show();
                $(".cash-content-account-bank").hide();
                $(".cash-account").val(cashinfo.authinfo.alipay);
            break;
            case "wechat":
                if (!cashinfo.authinfo.wechat) {
                    coco_confirm('您未认证微信账号,是否认证？',function(){
                        layer.prompt({title: '请输入您的微信账号', formType: 3}, function(data, index){
                            ajaxpost('wechat',data);
                            layer.close(index);
                        });
                    });
                    return false;
                }
                $(".cash-content-account").show();
                $(".cash-content-account-bank").hide();
                $(".cash-account").val(cashinfo.authinfo.wechat);
            break;
            default:
                $(".cash-content-account").hide();
                $(".cash-content-account-bank").show();
                $(".cash-bank-list").hide();
            break;
        }
        $("#cashtype").val(type);
        $(".active").removeClass("active");
        $(this).addClass("active");
    });
    function ajaxpost(type,account){
    	$.ajax({
    		url:"<?php echo url('api/user/authdata'); ?>",
    		type:"POST",
    		data:{type:type,account:account},
    		datajson:"JSON",
    		success:function(datajson){
    			layer.msg(datajson.msg);
    			if (datajson.code == 1) {
    				setTimeout(function(){
    					window.location.reload();
    				},2000)
    			}
    		},
    		error:function(XMLHttpRequest, textStatus, errorThrown){
    			coco_close_loading();
                var codetext = XMLHttpRequest.responseText;
                codejson = eval("(" + codetext + ")");
               	layer.msg(codejson.msg);
    		}
    	})
    }
    layui.use(['layer','laytpl','form'],function(){
    	var layer = layui.layer,laytpl = layui.laytpl,form = layui.form;
    	$(document).on("click",".add-bank",function(){
    		var string =  laytpl($("#bind-bank").html()).render({
			    name: '绑定银行卡'
			});
			layer.open({
	            type: 1,//这就是定义窗口类型的属性
	            title: '绑定银行卡',
	            shadeClose: true,
	            shade: 0.3,
	            anim:1,
	            offset: "auto",
	            shadeClose : true,
	            area: ['90%', '65%'],
	            content: string,
	        });
	        form.render();
    	})
        //监听指定开关
		form.on('switch(switchTest)', function(data){
		    if (this.checked) {
		    	layer.tips('温馨提示：已开启默认状态', data.othis);
		    }else{
		    	layer.tips('温馨提示：已关闭默认状态', data.othis);
		    }
		});
		$('.bank-number').keyup(function(){
			var bankArr = new Array();
	      	var codeArr = new Array();
	      	<?php $_result=config('banklist');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
	      		bankArr['<?php echo $key; ?>'] = '<?php echo $item; ?>';
	      	<?php endforeach; endif; else: echo "" ;endif; $_result=config('bankcode.bankcode');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
	      		codeArr['<?php echo $key; ?>'] = '<?php echo $item; ?>';
	      	<?php endforeach; endif; else: echo "" ;endif; ?>
		  	var banknum = $(this).val();
		  	var str = '';
		  	var bankname = '';
		  	var bankcode = '';
		  	str = banknum.substring(0,8);
		  	if (bankArr.hasOwnProperty(str)) {
		  		bankname = bankArr[str];
		  	}
		  	str = banknum.substring(0,6);
		  	if (bankArr.hasOwnProperty(str)) {
	            bankname = bankArr[str];
	        }
	        str = banknum.substring(0,5);
	        if (bankArr.hasOwnProperty(str)) {
	            bankname = bankArr[str];
	        }
	        str = banknum.substring(0,4);
	        if (bankArr.hasOwnProperty(str)) {
	            bankname = bankArr[str];
	        }
	        code = bankname.split("银行")[0]+'银行';
	  		bankcode = codeArr[code];
	  		if (bankcode === undefined) {
	  			$(".bankname").find("option[value='default']").attr("selected",true);
	  		}else{
	  			$(".bankname").find("option[value='"+bankcode+"']").attr("selected",true);
	  		}
	  		layui.form.render('select');
	  		return false;
		});
		 form.verify({
		   	//数组的两个值分别代表：[正则匹配、匹配不符时的提示文字]
		   	bankrequire:[
		   		/\S/,
		   		'请输入银行卡号'
		   	],
		   	bankrule: [
		    	/^(\d{16}|\d{19})$/,
		    	'请填入正确的银行卡号'
		   	],
		   	bankaddressrequired:[
		   		/\S/,
		   		'请输入办卡网点地址'
		   	]
		});
		form.on("submit(bindbank)", function (data) {
			var datajson = data.field;
			$.ajax({
	    		url:"<?php echo url('api/banklist/addbank'); ?>",
	    		type:"POST",
	    		data:datajson,
	    		datajson:"JSON",
	    		success:function(datajson){
	    			layer.msg(datajson.msg);
	    			if (datajson.code == 1) {
	    				setTimeout(function(){
	    					window.location.reload();
	    				},2000)
	    			}
	    			return false;
	    		},
	    		error:function(XMLHttpRequest, textStatus, errorThrown){
	    			coco_close_loading();
	                var codetext = XMLHttpRequest.responseText;
	                codejson = eval("(" + codetext + ")");
	               	layer.msg(codejson.msg);
	               	return false;
	    		}
	    	})
		   	return false;
		});
		form.render();
    })
</script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>