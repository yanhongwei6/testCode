<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:81:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\withdraw\withdrawlog.html";i:1575946328;s:65:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\default.html";i:1577345369;s:62:"D:\phpstudy_pro\WWW\bh\application\index\view\common\meta.html";i:1572536367;s:65:"D:\phpstudy_pro\WWW\bh\application\index\view\common\sidenav.html";i:1572536367;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
<title><?php echo (isset($title) && ($title !== '')?$title:''); ?> – <?php echo __('The fastest framework based on ThinkPHP5 and Bootstrap'); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="renderer" content="webkit">

<?php if(isset($keywords)): ?>
<meta name="keywords" content="<?php echo $keywords; ?>">
<?php endif; if(isset($description)): ?>
<meta name="description" content="<?php echo $description; ?>">
<?php endif; ?>
<meta name="author" content="FastAdmin">

<link rel="shortcut icon" href="/assets/img/favicon.ico" />

<link href="/assets/css/frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
  <script src="/assets/js/html5shiv.js"></script>
  <script src="/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    var require = {
        config: <?php echo json_encode($config); ?>
    };
</script>
        <link href="/assets/css/user.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">
    </head>

    <body>

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#header-navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo url('/'); ?>" style="padding:6px 15px;"><img src="/assets/img/logo.png" style="height:40px;" alt=""></a>
                </div>
                <div class="collapse navbar-collapse" id="header-navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="https://www.fastadmin.net" target="_blank"><?php echo __('Home'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/store.html" target="_blank"><?php echo __('Store'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/wxapp.html" target="_blank"><?php echo __('Wxapp'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/service.html" target="_blank"><?php echo __('Services'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/download.html" target="_blank"><?php echo __('Download'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/demo.html" target="_blank"><?php echo __('Demo'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/donate.html" target="_blank"><?php echo __('Donation'); ?></a></li>
                        <li><a href="https://forum.fastadmin.net" target="_blank"><?php echo __('Forum'); ?></a></li>
                        <li><a href="https://doc.fastadmin.net" target="_blank"><?php echo __('Docs'); ?></a></li>
                        <li class="dropdown">
                            <?php if($user): ?>
                            <a href="<?php echo url('user/index'); ?>" class="dropdown-toggle" data-toggle="dropdown" style="padding-top: 10px;height: 50px;">
                                <span class="avatar-img"><img src="<?php echo cdnurl($user['avatar']); ?>" alt=""></span>
                            </a>
                            <?php else: ?>
                            <a href="<?php echo url('user/index'); ?>" class="dropdown-toggle" data-toggle="dropdown"><?php echo __('User center'); ?> <b class="caret"></b></a>
                            <?php endif; ?>
                            <ul class="dropdown-menu">
                                <?php if($user): ?>
                                <li><a href="<?php echo url('user/index'); ?>"><i class="fa fa-user-circle fa-fw"></i><?php echo __('User center'); ?></a></li>
                                <li><a href="<?php echo url('user/profile'); ?>"><i class="fa fa-user-o fa-fw"></i><?php echo __('Profile'); ?></a></li>
                                <li><a href="<?php echo url('user/changepwd'); ?>"><i class="fa fa-key fa-fw"></i><?php echo __('Change password'); ?></a></li>
                                <li><a href="<?php echo url('user/logout'); ?>"><i class="fa fa-sign-out fa-fw"></i><?php echo __('Sign out'); ?></a></li>
                                <?php else: ?>
                                <li><a href="<?php echo url('user/login'); ?>"><i class="fa fa-sign-in fa-fw"></i> <?php echo __('Sign in'); ?></a></li>
                                <li><a href="<?php echo url('user/register'); ?>"><i class="fa fa-user-o fa-fw"></i> <?php echo __('Sign up'); ?></a></li>
                                <?php endif; ?>

                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="content">
            <style>
    .panel-recharge h3 {
        margin-bottom: 15px;
        margin-top: 10px;
        color: #444;
        font-size: 16px;
    }

    .row-recharge > div {
        margin-bottom: 10px;
    }

    .row-recharge > div > label {
        width: 100%;
        height: 40px;
        display: block;
        font-size: 14px;
        line-height: 40px;
        color: #999;
        background: #fff;
        -webkit-border-radius: 3px;
        -moz-border-radius: 3px;
        border-radius: 3px;
        cursor: pointer;
        text-align: center;
        border: 1px solid #ddd;
        margin-bottom: 20px;
        font-weight: 400;
    }

    .row-recharge > div > label.active {
        border-color: #0d95e8;
        color: #0d95e8;
    }

    .row-recharge > div > label:hover {
        z-index: 4;
        border-color: #27b0d6;
        color: #27b0d6;
    }

    .panel-recharge .custommoney {
        border: none;
        height: 100%;
        width: 100%;
        display: inherit;
        line-height: 100%;
    }

    .row-recharge > div {
        height: 40px;
        line-height: 40px;
    }

    .row-recharge > div input.form-control {
        border: none;
        display: inline-block;
    }

    .row-paytype div input {
        display: none;
    }

    .row-paytype img {
        height: 22px;
        margin: 8px;
        vertical-align: inherit;
    }

    .btn-recharge {
        height: 40px;
        line-height: 40px;
        font-size: 14px;
        padding: 0;
    }

</style>
<div id="content-container" class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="sidenav">
    <?php echo hook('user_sidenav_before'); ?>
    <ul class="list-group">
        <li class="list-group-heading"><?php echo __('User center'); ?></li>
        <li class="list-group-item <?php echo $config['actionname']=='index'?'active':''; ?>"> <a href="<?php echo url('user/index'); ?>"><i class="fa fa-user-circle fa-fw"></i> <?php echo __('User center'); ?></a> </li>
        <li class="list-group-item <?php echo $config['actionname']=='profile'?'active':''; ?>"> <a href="<?php echo url('user/profile'); ?>"><i class="fa fa-user-o fa-fw"></i> <?php echo __('Profile'); ?></a> </li>
        <li class="list-group-item <?php echo $config['actionname']=='changepwd'?'active':''; ?>"> <a href="<?php echo url('user/changepwd'); ?>"><i class="fa fa-key fa-fw"></i> <?php echo __('Change password'); ?></a> </li>
        <li class="list-group-item <?php echo $config['actionname']=='logout'?'active':''; ?>"> <a href="<?php echo url('user/logout'); ?>"><i class="fa fa-sign-out fa-fw"></i> <?php echo __('Sign out'); ?></a> </li>
    </ul>
    <?php echo hook('user_sidenav_after'); ?>
</div>
        </div>
        <div class="col-md-9">
            <div class="panel panel-default panel-recharge">
                <div class="panel-body">
                    <h2 class="page-header">
                        <?php echo __('Withdraw log'); ?>
                        <a href="<?php echo url('withdraw/withdraw'); ?>" class="btn btn-primary btn-withdraw pull-right"><i class="fa fa-cny"></i> <?php echo __('Withdraw'); ?></a>
                    </h2>
                    <?php if(is_array($withdrawloglist) || $withdrawloglist instanceof \think\Collection || $withdrawloglist instanceof \think\Paginator): $i = 0; $__LIST__ = $withdrawloglist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$log): $mod = ($i % 2 );++$i;?>
                    <div class="row">
                        <div class="col-md-9">
                            <p class="text-primary"><?php echo __('Withdraw type'); ?>：支付宝</p>
                            <p class="text-primary"><?php echo __('Withdraw money'); ?>：￥<?php echo $log['money']; ?></p>
                            <?php if($log['status']=='rejected'&&$log['memo']): ?>
                            <p class="text-danger">拒绝原因：<?php echo $log['memo']; ?></p>
                            <?php elseif($log['status']=='successed'): if($log['taxes']>0): ?>
                                <p class="text-danger">扣除税费：￥<?php echo $log['taxes']; ?></p>
                                <?php endif; if($log['handingfee']>0): ?>
                                <p class="text-danger">扣除手续费：￥<?php echo $log['handingfee']; ?></p>
                                <?php endif; ?>
                                <p class="text-success">最终到账：￥<?php echo $log['settledmoney']; ?></p>
                            <?php endif; ?>
                            <p><?php echo __('Operate date'); ?>：<?php echo datetime($log['createtime']); ?></p>
                        </div>
                        <div class="col-md-3 text-right">
                            <?php if($log['status']=='successed'): ?>
                            <a href="javascript:" class="btn btn-success">提现成功</a>
                            <?php elseif($log['status']=='rejected'): ?>
                            <a href="javascript:" class="btn btn-danger" data-toggle="tooltip" data-title="<?php echo $log['memo']; ?>">提现拒绝</a>
                            <?php else: ?>
                            <a href="javascript:" class="btn btn-info" data-toggle="tooltip" data-title="请等待后台审核">申请中</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    <div class="pager"><?php echo $withdrawloglist->render(); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
        </main>
        <!--popover-->
            <!--申请弹窗-->
            <div class="tx-alert-mod" id="dom-suc" style="display: none;">
                <div class="tx-alert-mhead">
                    <i class="mui-icon mui-icon-checkmarkempty"></i>
                </div>
                <div class="tx-alert-mbody">
                    <div class="tx-alert-title">提交充值成功</div>
                    <div class="tx-alert-intro">
                        由于目前【第三方支付通道】支付不是很稳定，充值的会员请保存订单编号，如发现没有实时到账！请联系极限总管。QQ：984415555
                        <!-- 为了您能更好的接收提现最新动态 <br>请添加[<span class="uk-text-red"><?php echo $site['name']; ?></span>]客服QQ <span class="uk-text-red"><?php echo config('site.server_qq'); ?></span> -->
                    </div> 
                </div>
                <!-- <div class="tx-alert-mother">
                    <div class="tx-alert-btns">
                        <a href="javascript:;" class="mui-btn mui-btn-theme mui-btn-block action-clipboard-qq" data-clipboard-text="<?php echo config('site.server_qq'); ?>">复制QQ号添加好友</a>
                    </div>
                    <div class="tx-qrcode-mod">
                        <img class="tx-qrcode-img" src="/assets/pay/images/tg-qrcode.jpg">
                        <div class="tx-qrcode-txt">
                            或者截屏保存二维码<br>打开QQ扫一扫相册二维码即可添加<?php echo $site['name']; ?>客服QQ
                        </div>
                    </div>
                </div> -->
            </div>
        <!--/申请弹窗-->
        <!--/popover-->
        <footer class="footer" style="clear:both">
            <!-- FastAdmin是开源程序，建议在您的网站底部保留一个FastAdmin的链接 -->
            <p class="copyright">Copyright&nbsp;©&nbsp;2017-2019 Powered by <a href="https://www.fastadmin.net" target="_blank">FastAdmin</a> All Rights Reserved <a href="http://www.beian.miit.gov.cn" target="_blank"><?php echo htmlentities($site['beian']); ?></a></p>
        </footer>

        <script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>

    </body>

</html>
<script type="text/javascript">
    function alertlayer() {
        layer.open({
            type: 1,
            title: false,
            closeBtn: 1,
            skin: 'tx-alert-layer',
            shadeClose: false,
            shade: 0.3,
            anim:1,
            content: $('#dom-suc'),
            btn:['确定'],
            btn1:function(){
                location.href = "<?php echo url('index/user/index'); ?>"
            }
        });
    }
</script>