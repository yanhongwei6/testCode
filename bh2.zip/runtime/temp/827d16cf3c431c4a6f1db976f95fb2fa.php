<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:75:"D:\phpstudy_pro\WWW\bh\public/../application/admin\view\qishu\senumber.html";i:1577252004;s:65:"D:\phpstudy_pro\WWW\bh\application\admin\view\layout\default.html";i:1572536367;s:62:"D:\phpstudy_pro\WWW\bh\application\admin\view\common\meta.html";i:1572536366;s:64:"D:\phpstudy_pro\WWW\bh\application\admin\view\common\script.html";i:1572536366;}*/ ?>
<!DOCTYPE html>
<html lang="<?php echo $config['language']; ?>">
    <head>
        <meta charset="utf-8">
<title><?php echo (isset($title) && ($title !== '')?$title:''); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="renderer" content="webkit">

<link rel="shortcut icon" href="/assets/img/favicon.ico" />
<!-- Loading Bootstrap -->
<link href="/assets/css/backend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
  <script src="/assets/js/html5shiv.js"></script>
  <script src="/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    var require = {
        config:  <?php echo json_encode($config); ?>
    };
</script>
    </head>

    <body class="inside-header inside-aside <?php echo defined('IS_DIALOG') && IS_DIALOG ? 'is-dialog' : ''; ?>">
        <div id="main" role="main">
            <div class="tab-content tab-addtabs">
                <div id="content">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <section class="content-header hide">
                                <h1>
                                    <?php echo __('Dashboard'); ?>
                                    <small><?php echo __('Control panel'); ?></small>
                                </h1>
                            </section>
                            <?php if(!IS_DIALOG && !$config['fastadmin']['multiplenav']): ?>
                            <!-- RIBBON -->
                            <div id="ribbon">
                                <ol class="breadcrumb pull-left">
                                    <li><a href="dashboard" class="addtabsit"><i class="fa fa-dashboard"></i> <?php echo __('Dashboard'); ?></a></li>
                                </ol>
                                <ol class="breadcrumb pull-right">
                                    <?php foreach($breadcrumb as $vo): ?>
                                    <li><a href="javascript:;" data-url="<?php echo $vo['url']; ?>"><?php echo $vo['title']; ?></a></li>
                                    <?php endforeach; ?>
                                </ol>
                            </div>
                            <!-- END RIBBON -->
                            <?php endif; ?>
                            <div class="content">
                                <style type="text/css">
  .input-info,.layui-form-item table{
    width: 90%;
    margin: auto;
  }
  .layui-form-item table{
    line-height: 30px;
    text-align: center;
    border: 1px solid #ccc;
  }
  .layui-form-item table tr th{
    text-align: center;
  }
  .input-info-value{
    margin-left: 5px;
    font-weight: bold;
  }
  .cutdown{
    width: 40px;
    height: 40px;
    border:1px solid #ccc;
    border-radius: 20px;
    display: inline-block;
    text-align: center;
    line-height: 40px;
  }
</style>


<link rel="stylesheet" href="/layui/css/layui.css"  media="all">    
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
  <legend>设置开奖号</legend>
</fieldset>
<form class="layui-form" id="set-opennumber" action="">
  <input type="hidden" id="gameid" name="gname" value="<?php echo $row['game']; ?>">
  <input type="hidden" id="issue" name="issue" value="<?php echo $row['issue']; ?>">
  <input type="hidden" id="gsign" value="<?php echo $sign; ?>">
  <div class="layui-form-item">
    <div class="layui-inline" style="margin-left: 13px">
      <label class="layui-form-label">开奖号</label>
      <?php if($row['opentime']): if(is_array($row['number']) || $row['number'] instanceof \think\Collection || $row['number'] instanceof \think\Paginator): $i = 0; $__LIST__ = $row['number'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        <div class="layui-input-inline" style="width: 100px;">
          <input type="number" value="<?php echo $v; ?>" autocomplete="off" class="layui-input" disabled="disabled">
        </div>
        <?php endforeach; endif; else: echo "" ;endif; else: ?>
        <div class="layui-input-inline" style="width: 100px;">
          <input type="number" oninput="if(value.length>1)value=value.slice(0,1)" name="number[]" placeholder="号码一" autocomplete="off" class="layui-input layui-input-info-value" <?php echo $disabled; ?>>
        </div>
        <div class="layui-input-inline" style="width: 100px;">
          <input type="number" oninput="if(value.length>1)value=value.slice(0,1)" name="number[]" placeholder="号码二" autocomplete="off" class="layui-input layui-input-info-value" <?php echo $disabled; ?>>
        </div>
        <div class="layui-input-inline" style="width: 100px;"> 
          <input type="number" oninput="if(value.length>1)value=value.slice(0,1)" name="number[]" placeholder="号码三" autocomplete="off" class="layui-input layui-input-info-value" <?php echo $disabled; ?>>
        </div>
      <?php endif; ?>
      
    </div>
  </div>
  <div class="layui-form-item">
      <div class="layui-form-item"><div class="input-info"><span class="input-info-title">下注倒计时：</span><span class="input-info-value cutdown">20</span></div></div>
      <div class="layui-form-item"><div class="input-info"><span class="input-info-title">期号：</span><span class="input-info-value issue-value"><?php echo $row['issue']; ?></span></div></div>
      <div class="layui-form-item"><div class="input-info"><span class="input-info-title">游戏：</span><span class="input-info-value"><?php echo $data['gname']; ?></span></div></div>
      <div class="layui-form-item"><div class="input-info"><span class="input-info-title">下注总金额：</span><span class="input-info-value bet-all-price"><?php echo !empty($data['betall'])?$data['betall']: '0.00'; ?></span></div></div>
      <div class="layui-form-item">
        <table border="1">
          <thead>
            <tr>
              <th>大(金额)</th>
              <th>小(金额)</th>
              <th>豹子(金额)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="bet-large-price"><?php echo !empty($data['bettype']['large'])?$data['bettype']['large']: '0.00'; ?></td>
              <td class="bet-little-price"><?php echo !empty($data['bettype']['little'])?$data['bettype']['little']: '0.00'; ?></td>
              <td class="bet-leopard-price"><?php echo !empty($data['bettype']['leopard'])?$data['bettype']['leopard']: '0.00'; ?></td>
            </tr>
          </tbody>
        </table>
      </div>
  </div>

  <div class="layui-form-item">
    <div class="layui-input-block">
      <button type="submit" class="layui-btn" flag="<?php if($disabled): ?>true<?php else: ?>false<?php endif; ?>">设置</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-backend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
    </body>
</html>