<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:76:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\recharge.html";i:1577518220;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<!-- <div class="menu-wrap">
   <nav class="menu">
      <div class="icon-list">
         <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
         <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
         <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
         <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
         <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
      </div>
   </nav>
   <button class="close-button" id="close-button">Close Menu</button>
	<div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
		<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
			<path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
		<desc>Created with Snap</desc><defs></defs></svg>
	</div>
</div> -->

<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
	<a class="navbar-tit center-block">充值中心</a>
	<button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<br>
<div class="user-amount">
   <span class="user-title">当前余额：</span>
   <span class="user-balance"><?php echo !empty($user['money'])?$user['money']: '0.00'; ?></span>元
</div>
<div class="price-content">
   <div class="price-content-title">充值金额</div>
   <ul class="price-content-list">
      <?php if(is_array($moneyList) || $moneyList instanceof \think\Collection || $moneyList instanceof \think\Paginator): $i = 0; $__LIST__ = $moneyList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($key==0): ?>
         <li><div class="price-content-list-div active" data-price="<?php echo $item['value']; ?>">￥<?php echo $item['value']; ?></div><span class="myicon-tick-checked"></span></li>
         <?php else: ?>
         <li><div class="price-content-list-div" data-price="<?php echo $item['value']; ?>">￥<?php echo $item['value']; ?></div></li>
         <?php endif; endforeach; endif; else: echo "" ;endif; ?>
      <li><div class="price-content-list-div other-money">其他金额</div></li>
   </ul>
</div>
<div class="custom-price" style="display: none;">
   <span class="custom-title">自定义金额：</span>
   <input type="number" name="price" class="custom-input" placeholder="请输入金额">
</div>
<div class="paytype-title">选择支付方式</div>
<div class="paytype-list">
   <ul>
      <?php if(is_array($paytypeList) || $paytypeList instanceof \think\Collection || $paytypeList instanceof \think\Paginator): $i = 0; $__LIST__ = $paytypeList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($key == 0): ?>
         <li class="paytype-list-li" data-value="<?php echo $item['id']; ?>">
            <span class="paytype-list-image">
               <img src="<?php echo $item['paylog']; ?>">
            </span>
            <span class="paytype-name"><?php echo $item['name']; ?></span>
            <span class="check-btn check-active"></span>
         </li>
      <?php else: ?>
         <li class="paytype-list-li" data-value="<?php echo $item['id']; ?>">
            <span class="paytype-list-image">
               <img src="<?php echo $item['paylog']; ?>">
            </span>
            <span class="paytype-name"><?php echo $item['name']; ?></span>
            <span class="check-btn"></span>
         </li>
      <?php endif; endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
<div class="payinfo-btn">
   <a href="javascript:;" class="btn btn-lg btn-danger btn-submit-data">立即充值</a>
</div>
<script type="text/javascript">
   $(document).ready(function(){  
      bindKeyEvent($(".custom-input"));  
   });
   function bindKeyEvent(obj){  
      obj.keyup(function () {  
         var reg = $(this).val().match(/\d+\.?\d{0,2}/);  
         var txt = '';  
         if (reg != null) {  
            txt = reg[0];  
         }  
         $(this).val(txt);  
      }).change(function () {  
         $(this).keypress();  
         var v = $(this).val();  
         if (/\.$/.test(v))  
         {  
            $(this).val(v.substr(0, v.length - 1));  
         }  
      });  
   }  
</script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>