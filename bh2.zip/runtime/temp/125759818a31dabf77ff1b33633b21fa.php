<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:76:"D:\phpstudy_pro\WWW\bh\public/../application/census\view\calculus\index.html";i:1579180042;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\layout\default.html";i:1579178611;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\common\calmenu.html";i:1579180088;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>首页</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/style.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/responsive.css">
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 header-top">
                    <img src="http://www.77tj.org/assets/images/logo.png" class="logo" alt="亿豪统计">
                </div>
                <div class="col-md-8 header-top header-top-menu">
                    <span>
                        <a href="<?php echo url('qqchat/index'); ?>" class="active">QQ在线统计</a>
                        <a href="<?php echo url('tencent/index'); ?>">腾讯在线统计</a>
                        <a href="<?php echo url('calculus/index'); ?>">数据演算</a>
                    </span>
                </div>
            </div>
        </div>
        <div class="header-top-image">
            <div>
                <p><img alt="" src="http://www.77tj.org/assets/images/time.png">2020-01-08 15:45:00&nbsp;&nbsp; 腾讯同时在线人数</p>
                <p><strong>314,415,591</strong>历史最高：335,684,644</p>
                <span>所有数据均来自腾讯</span>
            </div>
        </div>
        <div class="container">
	<div class="row container-content">
		<div class="col-md-2">
 	<a href="<?php echo url('calculus/index'); ?>" class="<?php echo $active['index']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon1.png">统计结果</a>
    <a href="<?php echo url('calculus/results'); ?>" class="<?php echo $active['results']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon0.png">结果验证</a>
    <a href="<?php echo url('calculus/log'); ?>" class="<?php echo $active['log']; ?>"><img alt="" src="http://www.77tj.org/assets/images/dl.png">日志下载</a>
    <a href="<?php echo url('calculus/explain'); ?>" class="<?php echo $active['explain']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon3.png">统计说明</a>
    <a href="<?php echo url('calculus/interface'); ?>" class="<?php echo $active['interface']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon4.png">接口调用</a>
</div>
        <div class="col-md-10">
         	<form method="post" id="indexform" action="http://www.77tj.org/car/formPost">
				<table class="gridview" style="table-layout:fixed;">
					<tbody>
						<tr>
							<th>统计时间</th>
							<th>在线人数</th>
							<th>哈希算法</th>
							<th class="hash-value">哈希值</th>
							<th>演算结果</th>
							<th>操作</th>
						</tr>
						<tr>
							<td>2020-01-08 19:28:00</td>
							<td>312,037,041</td>
							<td>SHA512</td>
							<td><div class="hash-value" title="469a32b9d94d0b13678128a02df0bef9bcff3dac61f6cffb6df4906575074c3a1115e810ce3af33c58beef4a0d72c274d5a0bf8807bf9187887cfb9686a1014b">469a32b9d94d0b13678128a02df0bef9bcff3dac61f6cffb6df4906575074c3a1115e810ce3af33c58beef4a0d72c274d5a0bf8807bf9187887cfb9686a1014b</div></td>
							<td>4,6,9,3,2,10,1,7,8,5</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482880">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:27:00</td>
							<td>311,955,415</td>
							<td>SHA512</td>
							<td><div class="hash-value">4e48928e842423a2fa7d5910c6d54f3fa09115b73b51837c1a0a61f13b43423b7d151459850bce59ba054514d25f669871ee66d468fe38c9b4b08bc57cf7b125</div></td>
							<td>4,8,9,2,3,7,5,1,10,6</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482820">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:26:00</td>
							<td>311,977,144</td>
							<td>SHA512</td>
							<td><div class="hash-value">cdc2543645397e943f459c2f82fc25e91e64fee9166b92e368cdcadfb0b1f48ca8dfd2b2c1aa2ad5828de962c9bffed573ff344f542e05e965efd8e429f674a7</div></td>
							<td>2,5,4,3,6,9,7,8,1,10</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482760">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:25:00</td>
							<td>311,899,461</td>
							<td>SHA512</td>
							<td><div class="hash-value">1a36cae3182cfb409e1801020d6d22a4daeb85c06bbd308cab40f506c2aa9118214ef8dcc89b1e58bd374ffce55cd5e73ec7891bbbce4ec231b86a317d5acbd1</div></td>
							<td>1,3,6,8,2,4,10,9,5,7</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482700">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:24:00</td>
							<td>311,793,521</td>
							<td>SHA512</td>
							<td><div class="hash-value">be05dda039e84e63155bea2a68a3debccb6110625821663559d069a630fd83ea355cea538d601b3d69a3bcd331557cdeecf36c03ec437eabd275bd9c7fe1e4d9</div></td>
							<td>10,5,3,9,8,4,6,1,2,7</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482640">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:23:00</td>
							<td>311,739,403</td>
							<td>SHA512</td>
							<td><div class="hash-value">2eb2ae5c7516ceee1a39bdc69eaedbb28612291c8178140d33b067d480b7168b15620727f66a6feaf5b8cf27a5c0e8f640c44fac0ac9070dc018dc8178ce6ba2</div></td>
							<td>2,5,7,1,6,3,9,8,4,10</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482580">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:22:00</td>
							<td>311,829,174</td>
							<td>SHA512</td>
							<td><div class="hash-value">8833b9a54ea85991e4c946a28f41ac0cdf033fa1e1a4023620e9269eb33546fc6fe07a274d79f9f170851bc1c1b3cf2acd2123fed0ca747c36f07db7d546f8d6</div></td>
							<td>8,3,9,5,4,1,6,2,10,7</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482520">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:21:00</td>
							<td>311,887,903</td>
							<td class="hash-value">SHA512</td>
							<td><div class="hash-value">ed904cf96c8f362573ad9a0c256d888eeb47ec5a2067a6f8cbd345a0df6a4c321b5f4b249bc212263426ca5b1eb40413d9b2eccbcbc685d99971a9282956053c</div></td>
							<td>9,10,4,6,8,3,2,5,7,1</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482460">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:20:00</td>
							<td>311,883,520</td>
							<td>SHA512</td>
							<td><div class="hash-value">69dae3ec1deee2ebfebaaa396f862d2c6cd0e658e4924fe1260de068b126316a8c34f14363ed48881e084d84ed26dc51f3da266b7f9810bcf26eab46620bf52c</div></td>
							<td>6,9,3,1,2,8,10,5,4,7</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482400">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:19:00</td>
							<td>311,877,257</td>
							<td>SHA512</td>
							<td><div class="hash-value">9f23a5c03c19c45105ceb39bed9785532e74c4320f3dfb2ae93f5d75f7e6feca6645c28c20d2e3f8cdb6a10525702dee140ca377326d96bb103523c0f9517136</div></td>
							<td>9,2,3,5,10,1,4,7,8,6</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482340">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:18:00</td>
							<td>311,729,879</td>
							<td>SHA512</td>
							<td><div class="hash-value">478ac3e28783b2f643ddcf30b9e88e118099eff9727c8360d6e06541e7c11f9ba44392a7fb81792ee6a4bb40666ea4b3f676408b87469fe9e76719f0190d04e7</div></td>
							<td>4,7,8,3,2,6,10,9,1,5</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482280">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:17:00</td>
							<td>311,821,071</td>
							<td>SHA512</td>
							<td><div class="hash-value">2f4ef86bf2ce1929e89e40a63abcee5a75c4cfcb512ab04c246b07c3d0d6c56bbec6281a2aca694196ee9c8fe5379ca651227d9f312eabdeeb40f8c12b2f37a4</div></td>
							<td>2,4,8,6,1,9,10,3,5,7</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482220">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:16:00</td>
							<td>311,973,256</td>
							<td>SHA512</td>
							<td><div class="hash-value">895c58c52479ec2dd959c8ddc337ff7e17a5dee2f4df9179d88bd2c8006b477ed2fe0def53489101308e563a96b078b74d2ebf48e4af32af779c9da9a4ece0f5</div></td>
							<td>8,9,5,2,4,7,3,1,10,6</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482160">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:15:00</td>
							<td>311,956,659</td>
							<td>SHA512</td>
							<td><div class="hash-value">b7a04dd367a3ac8225430381c74b7ad020f8a9fae984b50d9eaa1c384bb6cd5098afb9b75634fbdbaf04694c02e706a6ec305f8fe49691b3f989c81f9538e489</div></td>
							<td>7,10,4,3,6,8,2,5,1,9</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482100">验证</a></td>
						</tr>
						<tr>
							<td>2020-01-08 19:14:00</td>
							<td>311,928,431</td>
							<td>SHA512</td>
							<td><div class="hash-value">851dfeb4ad1b2910a02746b6afaf89efa32b59e0e18b495689d95a80be441fd75d6b69285571e78234ef7cb0cd698678c35ce9fe896a27aefb12c1dd803db52d</div></td>
							<td>8,5,1,4,2,9,10,7,6,3</td>
							<td><a href="http://www.77tj.org/car/yanzheng/1578482040">验证</a></td>
						</tr>
					</tbody>
				</table>
				<div class="pager">
					<div class="col-sm-left"></div>
					<div class="col-sm-right">
						<input type="hidden" value="1" id="PageIndex" name="PageIndex">
						<ul class="pagination">				
							<li class="paginate_button active">
								<a href="javascript:;" class="paging_button" title="1">1</a>
							</li>
							<li class="paginate_button">
									<a href="javascript:;" class="paging_button" title="2">2</a>
								</li>
							<li class="paginate_button">
								<a href="javascript:;" class="paging_button" title="3">3</a>
							</li>
							<li class="paginate_button next">
								<a href="javascript:;" class="paging_button" title="2">
									<i class="fa fa-angle-right">></i>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<input type="hidden" name="tc_token_name" value="28019b6bdf146452754a5586c821b70d">
			</form>
        </div>
    </div>
</div>
        <div class="footer">
            <p>Copyright © 1998- 2016 HuaQi. All Rights Reserved.</p>
            <p>华旗公司 版权所有</p>
        </div>
        <script type="text/javascript" scr="/assets/static/js/jquery.3.4.1.js"></script>
    </body>
</html>