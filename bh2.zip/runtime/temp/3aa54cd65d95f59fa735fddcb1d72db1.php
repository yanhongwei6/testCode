<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"D:\phpstudy_pro\WWW\bh\public/../application/census\view\tencent\index.html";i:1579178679;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\layout\default.html";i:1579178611;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\common\tenmenu.html";i:1579178780;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>首页</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/style.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/responsive.css">
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 header-top">
                    <img src="http://www.77tj.org/assets/images/logo.png" class="logo" alt="亿豪统计">
                </div>
                <div class="col-md-8 header-top header-top-menu">
                    <span>
                        <a href="<?php echo url('qqchat/index'); ?>" class="active">QQ在线统计</a>
                        <a href="<?php echo url('tencent/index'); ?>">腾讯在线统计</a>
                        <a href="<?php echo url('calculus/index'); ?>">数据演算</a>
                    </span>
                </div>
            </div>
        </div>
        <div class="header-top-image">
            <div>
                <p><img alt="" src="http://www.77tj.org/assets/images/time.png">2020-01-08 15:45:00&nbsp;&nbsp; 腾讯同时在线人数</p>
                <p><strong>314,415,591</strong>历史最高：335,684,644</p>
                <span>所有数据均来自腾讯</span>
            </div>
        </div>
        <div class="container">
	<div class="row container-content">
		<div class="col-md-2">
 	<a href="<?php echo url('tencent/index'); ?>" class="<?php echo $active['index']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon1.png">统计结果</a>
    <a href="<?php echo url('tencent/show'); ?>" class="<?php echo $active['show']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon2.png">动态展示</a>
    <a href="<?php echo url('tencent/explain'); ?>" class="<?php echo $active['explain']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon3.png">统计说明</a>
    <a href="<?php echo url('tencent/interface'); ?>" class="<?php echo $active['interface']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon4.png">接口调用</a>
</div>
        <div class="col-md-10">
         	<form method="post" id="indexform" action="http://www.77tj.org/welcome/formPost">
				<table class="gridview">
					<tbody>
						<tr>
							<th>统计时间</th>
							<th>在线人数</th>
							<th>波动值</th>
						</tr>
						<tr>
							<td>2020-01-08 16:22:00</td>
							<td>329,964,577</td>
							<td>+12988</td>
						</tr>
											<tr>
							<td>2020-01-08 16:21:00</td>
							<td>329,951,589</td>
							<td>+32634</td>
						</tr>
											<tr>
							<td>2020-01-08 16:20:00</td>
							<td>329,918,955</td>
							<td>+24895</td>
						</tr>
											<tr>
							<td>2020-01-08 16:19:00</td>
							<td>329,894,060</td>
							<td>+76783</td>
						</tr>
											<tr>
							<td>2020-01-08 16:18:00</td>
							<td>329,817,277</td>
							<td>+54935</td>
						</tr>
											<tr>
							<td>2020-01-08 16:17:00</td>
							<td>329,762,342</td>
							<td>+51988</td>
						</tr>
											<tr>
							<td>2020-01-08 16:16:00</td>
							<td>329,710,354</td>
							<td>+3064</td>
						</tr>
											<tr>
							<td>2020-01-08 16:15:00</td>
							<td>329,707,290</td>
							<td>+13088</td>
						</tr>
											<tr>
							<td>2020-01-08 16:14:00</td>
							<td>329,694,202</td>
							<td>+29618</td>
						</tr>
											<tr>
							<td>2020-01-08 16:13:00</td>
							<td>329,664,584</td>
							<td>+42123</td>
						</tr>
											<tr>
							<td>2020-01-08 16:12:00</td>
							<td>329,622,461</td>
							<td>+46758</td>
						</tr>
											<tr>
							<td>2020-01-08 16:11:00</td>
							<td>329,575,703</td>
							<td>+78321</td>
						</tr>
											<tr>
							<td>2020-01-08 16:10:00</td>
							<td>329,497,382</td>
							<td>+29684</td>
						</tr>
											<tr>
							<td>2020-01-08 16:09:00</td>
							<td>329,467,698</td>
							<td>+9073</td>
						</tr>
											<tr>
							<td>2020-01-08 16:08:00</td>
							<td>329,458,625</td>
							<td>+92590</td>
						</tr>									
					</tbody>
				</table>
				<div class="pager">
					<div class="col-sm-left">
					</div>
					<div class="col-sm-right">
						<input type="hidden" value="1" id="PageIndex" name="PageIndex">
						<ul class="pagination">						
							<li class="paginate_button active">
								<a href="javascript:;" class="paging_button" title="1">1</a>
							</li>
							<li class="paginate_button">
								<a href="javascript:;" class="paging_button" title="2">2</a>
							</li>
							<li class="paginate_button">
								<a href="javascript:;" class="paging_button" title="3">3</a>
							</li>
							<li class="paginate_button next">
								<a href="javascript:;" class="paging_button" title="2">
									<i class="fa fa-angle-right">></i>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<input type="hidden" name="tc_token_name" value="84362c4aa1698b48ccdd440ea8f38a4b">
			</form>
        </div>
    </div>
</div>

        <div class="footer">
            <p>Copyright © 1998- 2016 HuaQi. All Rights Reserved.</p>
            <p>华旗公司 版权所有</p>
        </div>
        <script type="text/javascript" scr="/assets/static/js/jquery.3.4.1.js"></script>
    </body>
</html>