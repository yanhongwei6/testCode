<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:58:"D:\phpstudy_pro\WWW\bh\addons\invite\view\index\index.html";i:1575946239;}*/ ?>
<!DOCTYPE html >
<html >
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <title></title>
    </head>
    <body>
        <script>
            location.href = "/";
        </script>
    </body>
</html>