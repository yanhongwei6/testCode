<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:72:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\index\index.html";i:1579151520;s:65:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\default.html";i:1577345369;s:62:"D:\phpstudy_pro\WWW\bh\application\index\view\common\meta.html";i:1572536367;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
<title><?php echo (isset($title) && ($title !== '')?$title:''); ?> – <?php echo __('The fastest framework based on ThinkPHP5 and Bootstrap'); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="renderer" content="webkit">

<?php if(isset($keywords)): ?>
<meta name="keywords" content="<?php echo $keywords; ?>">
<?php endif; if(isset($description)): ?>
<meta name="description" content="<?php echo $description; ?>">
<?php endif; ?>
<meta name="author" content="FastAdmin">

<link rel="shortcut icon" href="/assets/img/favicon.ico" />

<link href="/assets/css/frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
  <script src="/assets/js/html5shiv.js"></script>
  <script src="/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    var require = {
        config: <?php echo json_encode($config); ?>
    };
</script>
        <link href="/assets/css/user.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">
    </head>

    <body>

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#header-navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo url('/'); ?>" style="padding:6px 15px;"><img src="/assets/img/logo.png" style="height:40px;" alt=""></a>
                </div>
                <div class="collapse navbar-collapse" id="header-navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="https://www.fastadmin.net" target="_blank"><?php echo __('Home'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/store.html" target="_blank"><?php echo __('Store'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/wxapp.html" target="_blank"><?php echo __('Wxapp'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/service.html" target="_blank"><?php echo __('Services'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/download.html" target="_blank"><?php echo __('Download'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/demo.html" target="_blank"><?php echo __('Demo'); ?></a></li>
                        <li><a href="https://www.fastadmin.net/donate.html" target="_blank"><?php echo __('Donation'); ?></a></li>
                        <li><a href="https://forum.fastadmin.net" target="_blank"><?php echo __('Forum'); ?></a></li>
                        <li><a href="https://doc.fastadmin.net" target="_blank"><?php echo __('Docs'); ?></a></li>
                        <li class="dropdown">
                            <?php if($user): ?>
                            <a href="<?php echo url('user/index'); ?>" class="dropdown-toggle" data-toggle="dropdown" style="padding-top: 10px;height: 50px;">
                                <span class="avatar-img"><img src="<?php echo cdnurl($user['avatar']); ?>" alt=""></span>
                            </a>
                            <?php else: ?>
                            <a href="<?php echo url('user/index'); ?>" class="dropdown-toggle" data-toggle="dropdown"><?php echo __('User center'); ?> <b class="caret"></b></a>
                            <?php endif; ?>
                            <ul class="dropdown-menu">
                                <?php if($user): ?>
                                <li><a href="<?php echo url('user/index'); ?>"><i class="fa fa-user-circle fa-fw"></i><?php echo __('User center'); ?></a></li>
                                <li><a href="<?php echo url('user/profile'); ?>"><i class="fa fa-user-o fa-fw"></i><?php echo __('Profile'); ?></a></li>
                                <li><a href="<?php echo url('user/changepwd'); ?>"><i class="fa fa-key fa-fw"></i><?php echo __('Change password'); ?></a></li>
                                <li><a href="<?php echo url('user/logout'); ?>"><i class="fa fa-sign-out fa-fw"></i><?php echo __('Sign out'); ?></a></li>
                                <?php else: ?>
                                <li><a href="<?php echo url('user/login'); ?>"><i class="fa fa-sign-in fa-fw"></i> <?php echo __('Sign in'); ?></a></li>
                                <li><a href="<?php echo url('user/register'); ?>"><i class="fa fa-user-o fa-fw"></i> <?php echo __('Sign up'); ?></a></li>
                                <?php endif; ?>

                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="content">
            
    <style type="text/css">
        #navbar-collapse-menu a{
            color: black;
        }
        .row{
            width: 95%;
            margin: auto;
        }
        .money div{
            width: 80px;
            height: 30px;
            border: 1px solid #ccc;
            text-align: center;
            line-height: 30px;
            color: #ccc;
            clear: both;
            margin-bottom: 5px;
        }
        .content,.layer-alert-type{
            width: 500px;
            margin: auto;
            border:1px solid #ccc;
            height: 300px;
            margin: 50px auto;
        }
        .content{
            height: 400px;
            overflow: auto;
        }
        .content::-webkit-scrollbar{ display:none }
        .layer-alert-type ul{
            width: 90%;
        }
        .active{
            border-color: #ea220d !important;
            color: #ea220d !important;
        }
        .send-btn{
            text-align: center;
        }
        .hongbao-number{
            display: inline-block;
            width: 100%;
            text-align: left !important;
            padding-left: 34px;
            padding-bottom: 16px;
        }
        form{
            padding-top: 25px;
            width: 90%;
            margin: auto;
        }
        .user-info-left{
            text-align: left;
        }
        .user-info-right{
            text-align: right;
        }
        .message-info-left{
            text-align: left;
        }
        .message-info-right{
            text-align: right;
        }
        .message-info-left,.message-info-right{
            padding: 2px;
        }
        .avatar{
            width: 30px;
            height: 30px;
            border: 1px solid #ccc;
            border-radius: 15px;
            margin: 2px auto;
        }
        .avatar img{
            width: 100%;
            height: 100%;
            border-radius: 15px;
        }
        .username{
            width: 70%;
            justify-content: center;
            align-items: center;
            /* overflow: hidden; */
            line-height: 30px;
            padding: 2px;
        }
        .message-content{
            margin: 5px 0;
            display: flex;
             /*justify-content: flex-end; */
            align-items: center;
        }
        .user-info-left .avatar{
            float: left;
        }
        .user-info-right .avatar{
            float: right;
        }
        .hongbal-bar{
            width: 160px;
            height: 80px;
            background: url(/static/image/hongbao.jpg);
            background-size: 100% 100%;
            margin: auto;
            background-repeat: no-repeat;
            border-radius: 10px;
        }
        .message-info-right .hongbal-bar{
            margin-right: -10px;
        }
        .message-info-left .hongbal-bar{
            margin-left: -10px;
        }
        .message-info-right,.message-info-left{
            color: #ccc;
            font-size: 12px;
        }
        .message-tips{
            color: #dc1352;
        }
        .getmoney-tips{
            color: green;
        }
        .layui-layer-title{
            text-align: center !important;
            padding: 0 ;
        }
        .layui-layer-content{
            text-align:center !important;
        }

    .zhuomian{
        width: 60%;
        margin: auto;
        height: 400px;
        background: #ccc;
        border-radius: 10px;
        /*display: flex;
        justify-content: center;
        align-content: center;*/
    }
    .zhuomian span{
        width: 50%;
        display: inline-block;
        float: left;
        height: 200px;
        line-height: 200px;
        text-align: center;
    }
    .zhuomian span:nth-child(2n){
        border-left: 1px solid #fff;
    }
    .zhuomian span{
        border-bottom: 1px solid #fff;
    }
    .chip li{
        list-style-type: none;
        width: 25%;
        display: inline-block;
        float: left;
        height: 40px;
        margin-top: 5px;
    }
    .chip li div{
        width: 35px;
        height: 35px;
        text-align: center;
        line-height: 35px;
        border:1px solid #ccc;
        border-radius: 17px;
    }
    .top-info{
        width: 60%;
        margin: auto;
        display: flex;
        justify-content: center;
        align-content: center;
    }
    .zhuang,.result-info,.countdown-info{
        width: 60%;
        margin: auto;
    }
    .result-info{
        padding-left: 5px;
    }
    .top-fenge{
        display: block;
        width: 50%;
        padding: 5px;
    }
    .type-time{
        width: 40px;
        height: 40px;
        border: 1px solid #f51515;
        border-radius: 20px;
        display: inline-block;
        text-align: center;
        line-height: 40px;
    }
    .number{
        width: 40px;
        height: 40px;
        border-radius: 20px;
        text-align: center;
        line-height: 40px;
        color: red;
        border: 1px solid #3e21ec;
        margin-right: 5px;
    }
    .targe_number_jia{
        border:none;
        color: #ccc;
    }
    .targe_number_result{
        color: blue;
    }
    .zhuang-head{
        width: 40px;
        height: 40px;
        border: 1px solid #ccc;
        border-radius: 20px;
    }
    .zhuang-head-img{
        width: 100%;
        border-radius: 20px;
    }
    .rush_sum{
        width: 100%;
        width: 100%;
        position: fixed;
        z-index: 100;
        height: 50px;
        top: 50%;
        background-image:linear-gradient(to right,#00000033,#3c8dbc,#00000033)
    }
    .rush_sum ul{
        width: 100%;
        margin: 0;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .rush_sum li{
        list-style-type: none;
        display: inline-block;
        width: 24%;
        line-height: 50px;
    }
    .rush_sum_text{
        display: block;
        width: 40px;
        border: 1px solid #ccc;
        text-align: center;
        height: 20px;
        line-height: 20px;
        border-radius: 5px;
        background: #777777;
        color: #fff;
    }
    .zhuang-price{
        margin-left: 20px;
    }
    .get_open_result{
        position: fixed;
        width: 100%;
        text-align: center;
        background: rgba(0, 0, 0, 0.2);
        top: 0;
        bottom: 0;
    }
    .get_open_result_text{
        width: 100%;
        height: 40px;
        background: #fff;
        top: 44%;
        text-align: center;
        position: absolute;
        line-height: 40px;
        font-size: 15px;
        background-image: linear-gradient(to right,#00000033,#3c8dbc,#00000033);
        color: #fff;
    }
    .opennumber-info{
        position: fixed;
        z-index: 1000;
        width: 100%;
        /* height: 50px; */
        top: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.2);
    }
    .opennumber{
        display: inline-block;
        top: 48%;
        width: 100%;
        height: 50px;
        position: absolute;
        text-align: center;
    }
    .baozi{
        width: 100% !important;
    }
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
    }
    input[type="number"]{
        -moz-appearance: textfield;
    }
    @media(max-width: 960px){
        .zhuomian{
            width: 90%;
            height: 260px;
        }
        .zhuang,.result-info,.top-info,.countdown-info{
            width: 90%;
        }
        .opennumber-info,.countdown-info{
            padding-left: 5px;
        }
        .zhuomian span {
            height: 130px;
            line-height: 130px;
        }
        .zhuang{
            margin: auto;
            padding: 5px;
        }
        #member-list li{
            display: block;
            width: 25%;
            float: left;
        }
    }
    
</style>
        <input type="hidden" name="group" value="<?php echo $room; ?>" id="group">
        <!-- <div>倒计时： <span id="counttimer">0</span>秒</div>
        <div>倒计时： <span id="datetimer">00:00</span></div> -->
        <!-- <div>状态: <span id="status"></span></div> -->
        <div class="zhuang">
            <input type="hidden" id="targe-id" value="<?php echo $zhuang_user['id']; ?>">
            <div class="zhuang-head"><img src="<?php echo $zhuang_user['avatar']; ?>" class="zhuang-head-img"></div>
            <div><span class="zhuang-username"><?php echo $zhuang_user['nickname']; ?></span><span class="zhuang-price"><i class="fa fa-rmb"></i><?php echo !empty($zhuang_user['screen_money'])?$zhuang_user['screen_money']: config('site.member_rush_village_min_money'); ?></span></div>
        </div>
        <div class="top-info"><span class="top-fenge">期号：<span class="issue-number"><?php echo $issue; ?></span></span><span class="top-fenge">狀態：<span class="type-title"><?php echo $status['message']; ?></span></span></div>
        <div class="countdown-info" style="display:<?php if(in_array($status['status'],[1,2])): ?>block<?php else: ?>none<?php endif; ?>">倒計時：<span class="type-time">00</span></div>
        
        <div class="opennumber-info" style="display:<?php if($result['status']==1): ?>block<?php else: ?>none<?php endif; ?>">
            <span class="opennumber">
                <?php if(is_array($result['number']) || $result['number'] instanceof \think\Collection || $result['number'] instanceof \think\Paginator): $i = 0; $__LIST__ = $result['number'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                <input type="number" class="number targe_number_<?php echo $key+1; ?>" value="<?php echo $item; ?>">
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <input type="text" class="number targe_number_jia" value="+">
                <input type="text" class="number targe_number_result" value="<?php if($result['status']): ?><?php echo $result['result_num']; else: ?>？<?php endif; ?>">
            </span>
        </div>
        
        <div class="result-info" style="display: <?php if($result['status']): ?>block<?php else: ?>none<?php endif; ?>">
            <b>开奖结果：</b><span class="open-result"><?php if($result['status']): ?><?php echo $result['result_tips']; endif; ?></span>
        </div>

        <div class="zhuomian">
            <?php $_result=config('site.rush_ffc_playtype');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                <span class="<?php echo explode('-',$key)[0]; ?> bet-type" data-targe="<?php echo explode('-',$key)[1]; ?>" data-flag="<?php if($bet_flag): ?>true<?php else: ?>false<?php endif; ?>"><?php echo $item; ?></span>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <!-- 
            <span class="xiao bet-type" data-targe="little" data-flag="<?php if($bet_flag): ?>true<?php else: ?>false<?php endif; ?>">小</span>
            <span class="baozi bet-type" data-targe="leopard" data-flag="<?php if($bet_flag): ?>true<?php else: ?>false<?php endif; ?>">豹子</span> -->
            <!-- <span class="fanbaozi bet-type" data-targe="fleopard" data-flag="<?php if($bet_flag): ?>true<?php else: ?>false<?php endif; ?>">反豹子</span> -->
        </div>
        <ul class="chip">
            <?php $_result=explode(',', config('site.rush_price_list'));if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($key==0): ?>
                <li><div class="active chip-price"><?php echo $item; ?></div></li>
                <?php else: ?>
                <li><div class="chip-price"><?php echo $item; ?></div></li>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div style="clear: both;"></div>
        <div>
            <ul id="member-list">
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;if($zhuang_user['id'] != $item['id']): ?>
                        <li style="list-style-type: none;">
                            <input type="hidden" class="targe" value="<?php echo $item['id']; ?>" readonly="true">
                            <div style="width: 40px;height: 40px;"><img src="<?php echo $item['avatar']; ?>" style="width: 100%;height: 100%;"></div>
                            <div><span>用户名:</span><span class="u-nickname"><?php echo $item['nickname']; ?></span></div>
                        </li>
                    <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        <div class="rush_sum"  style="display: <?php if($screen_show): ?>block<?php else: ?>none<?php endif; ?>;">
            <ul>
                <?php $_result=config('site.rush_sum');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                <li><a class="layui-btn rush_sum_text" data-key="<?php echo $key.'-'.$item; ?>"><?php echo $item; ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        <div class="get_open_result" style="display: <?php if($openresult_show): ?>block<?php else: ?>none<?php endif; ?>">
            <div class="get_open_result_text">获取开奖结果</div>
        </div>
        <!-- jQuery -->
        <script src=/wap/js/jquery.min.js></script>
        <script src="/wap/js/config.js"></script>
        <script type="text/html" id="send-tpl">
            <div class="row message-content">
                <div class="col-xs-3 col-md-2 user-info-left">
                    <div class="avatar"><img src="/static/image/timg.png"></div><div class="username">{{d.list.name}}</div>
                </div>
                <div class="col-xs-9 col-md-4 message-info-left">
                    <div class="hongbal-bar"></div>
                    <div>{{d.list.datetime}}</div>
                </div>
            </div>
        </script>
        <script>
            var group = $("#group").val();
            var ws = new WebSocket("ws://"+window.document.domain+":7272/");
                var bindurl = "<?php echo url('index/bind'); ?>";
                ws.onopen = function(){
                    console.log("联机成功");
                };
            if ('WebSocket' in window) {
                ws.onmessage = function(e){
                    // json数据转换成js对象
                    var data = eval("("+e.data+")");
                    var type = data.type || '';
                    switch(type){
                        // Events.php中返回的init类型的消息，将client_id发给后台进行uid绑定
                        case 'init':
                            // 利用jquery发起ajax请求，将client_id发给后端进行uid绑定
                            $.ajax({type:"POST",url:bindurl,data:{client_id: data.client_id,room:group},dataType:"JSON",success:function(datajson){console.log(datajson);}})
                            break;
                        case 'join':
                            console.log(data);
                            var flag = true;
                            $(".targe").each(function(index,item){
                                var targe = $(item).val();
                                if (data.content.userinfo.id == targe) {
                                    flag = false;
                                }
                            })
                            if (flag) {
                                var str = '<li style="list-style-type: none;">\
                                        <input type="hidden" class="targe" value="'+data.content.userinfo.id+'" readonly="true">\
                                        <div style="width: 40px;height: 40px;"><img src="'+data.content.userinfo.avatar+'" style="width: 100%;height: 100%;"></div>\
                                        <div><span>用户名:</span><span class="u-nickname">'+data.content.userinfo.nickname+'</span></div>\
                                    </li>';
                                $("#member-list").append(str);
                            }
                            break;
                        case 'counttimer':
                            $('#counttimer').html(data.content);
                            $("#datetimer").html(getNewSyTime(data.content));
                            break;
                        case 'rushVillage':
                            if (data.content.countdown == 9) {
                                $(".rush_sum").show();
                            }
                            $(".type-title").html(data.content.msg);
                            $(".type-time").html(data.content.countdown);
                            $(".countdown-info").show();
                            break;
                        case 'screenscreen':
                            $(".rush_sum").hide();
                            $(".type-title").html(data.content.msg);
                            $(".countdown-info").hide();
                            break;
                        case 'shangZhuang':
                            console.log(data);
                            var zhuang_nickname = '系统坐庄';
                            var zhuang_img = "<?php echo config('site.default_header_image'); ?>";
                            if (data.content.uid.userid!=0) {
                                $(".targe").each(function(index,item){
                                    var targe = $(item).val();
                                    if (targe == data.content.uid.userid) {
                                        zhuang_nickname = $(item).parent().find('.u-nickname').html();
                                        zhuang_img = $(item).parent().find('img').attr('src');
                                        console.log(zhuang_nickname);
                                        $("#targe-id").val(targe);
                                        $(item).parent().remove();
                                    }
                                })
                                if (zhuang_nickname == '系统坐庄') {
                                    Fast.api.ajax({
                                        url:"/api/user/getuserinfo",
                                        data:{targe:data.content.uid.userid}
                                    }, function (data, ret) {
                                        console.log(ret);
                                        $(".zhuang-head-img").prop(ret.data.user.avatar);
                                        $(".zhuang-username").html(ret.data.user.nickname);
                                        $("#targe-id").val(ret.data.user.id);
                                        return false;
                                    });
                                }
                            }
                            $(".zhuang-head-img").prop(zhuang_img);
                            $(".zhuang-username").html(zhuang_nickname);
                            var str = '<i class="fa fa-rmb"></i>'+data.content.uid.screen_money;
                            $(".zhuang-price").html(str);
                            $("#targe-id").val(data.content.uid.userid);
                            $(".countdown-info").hide();
                            $(".type-title").html(data.content.msg);
                            break;
                        case 'bets':
                            $(".bet-type").data('flag',true);
                            $(".type-title").html(data.content.msg);
                            $(".type-time").html(data.content.countdown);
                            $(".countdown-info").show();
                            break;
                        case 'stopBets':
                            $(".bet-type").data('flag',false);
                            $(".countdown-info").hide();
                            $(".type-title").html(data.content.msg);
                            break;
                        case 'lottery':
                            $(".get_open_result").show();
                            $(".type-title").html(data.content.msg);
                            break;
                        case 'openlottery':
                            $(".get_open_result").hide();
                            if (data.content.countdown == 7) {
                                $(".opennumber-info").show();
                                var numbers = 0;
                                var interval = setInterval(function () {
                                    number = Math.floor(Math.random()*10);
                                    $(".targe_number_1").val(number);
                                    number = Math.floor(Math.random()*10);
                                    $(".targe_number_2").val(number);
                                    number = Math.floor(Math.random()*10);
                                    $(".targe_number_3").val(number);
                                }, 50)
                                setTimeout(function(){
                                    clearInterval(interval);
                                    $(".type-title").html(data.content.msg);
                                    var str = '';
                                    var result = 0;
                                    for (var i = 0; i < data.content.opennumber.length; i++) {
                                        result += data.content.opennumber[i];
                                        str += '<input type="number" class="number targe_number_'+(i+1)+'" value="'+data.content.opennumber[i]+'">';
                                    }
                                    result = parseInt(result%10);
                                    var result_tips = '';
                                    if (data.content.opennumber[0]==data.content.opennumber[1]&&data.content.opennumber[1]==data.content.opennumber[2]) {
                                        result_tips = '豹子';
                                    }else{
                                        if (result > 4) {
                                            result_tips = '大';
                                        }else{
                                            result_tips = '小';
                                        }
                                    }
                                    str += '<input type="text" class="number targe_number_jia" value="+">\
                                            <input type="text" class="number targe_number_result" value="'+result+'">';
                                    $(".open-result").html(result_tips);
                                    $(".opennumber").html(str);
                                    $(".result-info").show();
                                },4000)
                            }
                            break;
                        case 'settlementData':
                            $(".type-title").html(data.content.msg);
                            
                            break;
                        case 'getReady':
                            $(".issue-number").html(data.content.qishu);
                            $(".opennumber-info").hide();
                            $(".targe_number_result").val('？');
                             $(".result-info").hide();
                            $(".type-title").html(data.content.msg);
                            break;
                        case 'leave_group':
                            $(".targe").each(function(index,item){
                                var targe = $(item).val();
                                if (!data.content.ullist.includes(targe)) {
                                    $(item).parent().remove();
                                }
                            })
                            break;
                        case 'check_list':
                            $(".targe").each(function(index,item){
                                var targe = $(item).val();
                                if (!data.content.ulist.includes(targe)) {
                                    $(item).parent().remove();
                                }
                            })
                            break;        
                        // 当mvc框架调用GatewayClient发消息时直接alert出来
                        default :
                            console.log(data);
                    }
                };
            }
            else {
                alert('当前浏览器 Not support websocket')
            }
            //根据剩余秒数生成时间格式
            function getNewSyTime(sec) {
                var s = sec % 60;
                sec = (sec - s) / 60; //min
                var m = sec % 60;
                sec = (sec - m) / 60; //hour
                var h = sec % 24;
                var d = (sec - h) / 24;//day
                var syTimeStr = "";
                if (d > 0) {
                    syTimeStr += d.toString() + "天";
                }
                syTimeStr += ("0" + h.toString()).substr(-2) + "时"
                    + ("0" + m.toString()).substr(-2) + "分"
                    + ("0" + s.toString()).substr(-2) + "秒";
                return syTimeStr;
            }
            
            /**
            * 验证数据 是数字：返回true；不是数字：返回false
            **/
            function Number(val) {
            　　if (parseFloat(val).toString() == "00") {
            　　　　return false;
            　　} else {
            　　　　return true;
            　　}
            }
        </script>



        </main>
        <!--popover-->
            <!--申请弹窗-->
            <div class="tx-alert-mod" id="dom-suc" style="display: none;">
                <div class="tx-alert-mhead">
                    <i class="mui-icon mui-icon-checkmarkempty"></i>
                </div>
                <div class="tx-alert-mbody">
                    <div class="tx-alert-title">提交充值成功</div>
                    <div class="tx-alert-intro">
                        由于目前【第三方支付通道】支付不是很稳定，充值的会员请保存订单编号，如发现没有实时到账！请联系极限总管。QQ：984415555
                        <!-- 为了您能更好的接收提现最新动态 <br>请添加[<span class="uk-text-red"><?php echo $site['name']; ?></span>]客服QQ <span class="uk-text-red"><?php echo config('site.server_qq'); ?></span> -->
                    </div> 
                </div>
                <!-- <div class="tx-alert-mother">
                    <div class="tx-alert-btns">
                        <a href="javascript:;" class="mui-btn mui-btn-theme mui-btn-block action-clipboard-qq" data-clipboard-text="<?php echo config('site.server_qq'); ?>">复制QQ号添加好友</a>
                    </div>
                    <div class="tx-qrcode-mod">
                        <img class="tx-qrcode-img" src="/assets/pay/images/tg-qrcode.jpg">
                        <div class="tx-qrcode-txt">
                            或者截屏保存二维码<br>打开QQ扫一扫相册二维码即可添加<?php echo $site['name']; ?>客服QQ
                        </div>
                    </div>
                </div> -->
            </div>
        <!--/申请弹窗-->
        <!--/popover-->
        <footer class="footer" style="clear:both">
            <!-- FastAdmin是开源程序，建议在您的网站底部保留一个FastAdmin的链接 -->
            <p class="copyright">Copyright&nbsp;©&nbsp;2017-2019 Powered by <a href="https://www.fastadmin.net" target="_blank">FastAdmin</a> All Rights Reserved <a href="http://www.beian.miit.gov.cn" target="_blank"><?php echo htmlentities($site['beian']); ?></a></p>
        </footer>

        <script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>

    </body>

</html>
<script type="text/javascript">
    function alertlayer() {
        layer.open({
            type: 1,
            title: false,
            closeBtn: 1,
            skin: 'tx-alert-layer',
            shadeClose: false,
            shade: 0.3,
            anim:1,
            content: $('#dom-suc'),
            btn:['确定'],
            btn1:function(){
                location.href = "<?php echo url('index/user/index'); ?>"
            }
        });
    }
</script>