<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:84:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\rechger_tpl\guma_alipay.html";i:1577513307;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<link href="/assets/pay/css/mui.min.css" rel="stylesheet" />
<link href="/assets/pay/css/swiper.min.css" rel="stylesheet" />
<link href="/assets/pay/css/style.css" rel="stylesheet" />
<link href="/assets/pay/css/responsive.css" rel="stylesheet" />
<script src="/assets/pay/js/jquery.min.js"></script>
<script src="/assets/pay/js/mui.min.js"></script>
<script src="/assets/pay/js/uikit.min.js"></script>
<script src="/assets/pay/js/layer/layer.js"></script>
<script src="/assets/pay/js/swiper.min.js"></script>
<script src="/assets/pay/js/main.js"></script>
<script src="/assets/pay/js/clipboard.min.js"></script>
<style type="text/css">
	.layui-layer-setwin .layui-layer-close2{
		display: none;
	}
	.layui-layer{
		z-index: 19999999999 !important;
	}
</style>
<!--[if lt IE 10]>
    <style>
        .browser-alert-box{ display:block}
    </style>
<![endif]-->
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
	<a class="navbar-tit center-block">固码充值入款</a>
	<button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<div class="mui-content" style="padding-top:0">
	<section class="uk-container page-container">
		<!--block-->
		<section class="utmcz-block">
			<div class="utm-vmod">
				<div class="utm-vmhead">
					二维码信息
				</div>
				<div class="utm-vmbody">
					<div class="utm-vinfo" style="text-align: center">
						<img src="<?php echo $payinfo['qrcode']; ?>" />
					</div>
					<div class="utm-vinfo uk-text-red">
						<p>
							1、长按图像或者屏幕截图保存二维码到本地
						</p>
						<p>
							2、打开支付宝，扫一扫选择本地文件
						</p>
					</div>
				</div>
			</div>
			<div class="utm-vmod">
				<div class="utm-vmhead">
					存款信息
				</div>
				<div class="utm-foview">
					<form id="payform">
					<div class="tm-input-cell">
						<div class="tm-input-inner">
							<div class="tm-input-header tm-width-em-6">
								订单编号
							</div>
							<div class="tm-input-body">
								<div class="tm-txt"><?php echo $orderinfo['orderid']; ?></div>
							</div>
						</div>
					</div>
					<div class="tm-input-cell">
						<div class="tm-input-inner">
							<div class="tm-input-header tm-width-em-6">
								真实姓名
							</div>
							<div class="tm-input-body">
								<input class="tm-input" type="text" id="truename" name="truename" placeholder="转账支付宝真实姓名" />
							</div>
						</div>
					</div>
					<div class="tm-input-cell">
						<div class="tm-input-inner">
							<div class="tm-input-header tm-width-em-6">
								存款金额
							</div>
							<div class="tm-input-body">
								<div class="tm-txt"><?php echo $orderinfo['amount']; ?></div>
							</div>
						</div>
					</div>
					<input type="hidden" name="orderid" value="<?php echo $orderinfo['orderid']; ?>">
					</form>
				</div>
			</div>
			
				
			<div class="utm-ations">
				<div class="utm-btns">
					<a class="mui-btn mui-btn-theme mui-btn-section" href="javascript:;" action-tx>提交订单</a>
				</div>
				<div class="utm-tips uk-text-gray uk-text-xsmall">
					<p>
						<?php echo $site['pay_tips']; ?>
					</p>

				</div>
			</div>

		</section>
		<!--/block-->
	</section>
</div>
<!--/mbody-->

<!--popover-->
	<!--申请弹窗-->
	<div class="tx-alert-mod" id="dom-suc" style="display: none;">
		<div class="tx-alert-mhead">
			<i class="mui-icon mui-icon-checkmarkempty"></i>
		</div>
		<div class="tx-alert-mbody">
			<div class="tx-alert-title">提交充值成功</div>
			<div class="tx-alert-intro">
				为了您能更好的接收提现最新动态 <br>请添加[<span class="uk-text-red"><?php echo config('site.name'); ?></span>]客服QQ <span class="uk-text-red"><?php echo config('site.recharge_server_qq'); ?></span>
			</div> 
		</div>
		<div class="tx-alert-mother">
			<div class="tx-alert-btns">
				<a href="javascript:;" class="mui-btn mui-btn-theme mui-btn-block action-clipboard-qq" data-clipboard-text="<?php echo config('site.recharge_server_qq'); ?>">复制QQ号添加好友</a>
			</div>
			<div class="tx-qrcode-mod">
				<img class="tx-qrcode-img" src="/assets/pay/images/tg-qrcode.jpg">
				<div class="tx-qrcode-txt">
					或者截屏保存二维码<br>打开QQ扫一扫相册二维码即可添加平台客服QQ
				</div>
			</div>
		</div>
	</div>
	<!--/申请弹窗-->
<!--/popover-->
<!-- Init -->
<script type="text/javascript" charset="utf-8">
	mui.init();
</script>

<script type="text/javascript">
	$(document).on("click","[action-tx]",function(){
		if($('#truename').val() == ''){
			layer.alert('请输入入款人姓名！');
			return false;
		}
		var jsondata = $('#payform').serialize();
		$.post("<?php echo url('recharge/pay_recharge'); ?>",jsondata,function(result){
			alertlayer();
		})
	});
</script>
 

<script type="text/javascript">
	$(function() {
		var clipboard = new Clipboard('.action-clipboard-qq');
		clipboard.on('success', function(e) {
			//layer.msg("复制成功！即将打开微信");
			layer.msg('复制成功！', {
				time: 1000
			}, function() {
			//	openqq();
                // window.location.href = 'mqqwpa://im/chat?chat_type=wpa&uin=368899999&version=1&src_type=web&web_src=oicqzone.com';
                // 615566666
				window.location.href = "http://wpa.qq.com/msgrd?v=3&uin=227678888&site=qq&menu=yes";
			});
			console.info('Action:', e.action);
			console.info('Text:', e.text);
			console.info('Trigger:', e.trigger);
			e.clearSelection();
		});
	})
	function alertlayer() {
        layer.open({
            type: 1,
            title: false,
            closeBtn: 1,
            skin: 'tx-alert-layer',
            shadeClose: false,
            shade: 0.3,
            anim:1,
            content: $('#dom-suc'),
            btn:['确定'],
            btn1:function(){
                location.href = "<?php echo url('index/user/index'); ?>"
            }
        });
    }
</script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>