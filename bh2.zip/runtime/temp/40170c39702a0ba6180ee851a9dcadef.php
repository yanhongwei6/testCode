<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\index.html";i:1577335000;}*/ ?>
<div class="vipcenter">
    <div class="vipheader">
    <a href="userinfo.html">
    <div class="touxiang"><img src="/static/images/tx.jpg" alt=""></div>
    <div class="name">熊猫天堂 1</div>
    <div class="gztt">认证会员，已关注</div>
    </a>
    </div>
    <div class="vipsan">
    <div class="col-xs-4 text-center"><a><h4>等级</h4><p>Vip1</p></a></div>
    <div class="col-xs-4 text-center"><a><h4>积分</h4><p>1200</p></a></div>
    <div class="col-xs-4 text-center"><a><h4>领取码</h4><p>3</p></a></div>
    </div>
    <ul class="vipul">
    <li>
      <a href="#">
       <div class="icc"><i class="iconfont icon-xitongmingpian"></i></div>
       <div class="lzz">会员认证</div>
       <div class="rizi lvzi">已认证</div>
      </a>
    </li>
    <li>
      <a href="#">
       <div class="icc"><i class="iconfont icon-huodongfj"></i></div>
       <div class="lzz">活动中心</div>
       <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
      </a>
    </li>
    <li>
      <a href="ddcenter.html">
       <div class="icc"><i class="iconfont icon-liebiao"></i></div>
       <div class="lzz">订单中心</div>
       <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
      </a>
    </li>
    <li>
      <a href="userinfo.html">
       <div class="icc"><i class="iconfont icon-yonghux"></i></div>
       <div class="lzz">个人信息</div>
       <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
      </a>
    </li>
    <li>
      <a href="dizhi.html">
       <div class="icc"><i class="iconfont icon-chakangonglve"></i></div>
       <div class="lzz">收货地址</div>
       <div class="rizi"><i class="iconfont icon-jiantouri"></i></div>
      </a>
    </li>
    </ul>
</div>
