<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:74:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\signin.html";i:1578044557;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<!-- <div class="menu-wrap">
   <nav class="menu">
      <div class="icon-list">
         <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
         <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
         <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
         <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
         <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
      </div>
   </nav>
   <button class="close-button" id="close-button">Close Menu</button>
	<div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
		<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
			<path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
		<desc>Created with Snap</desc><defs></defs></svg>
	</div>
</div> -->
<style type="text/css">
	.bind-bank-content{
		width: 98%;
		margin: auto;
		padding: 10px 5px;
	}
	.cash-user-info {
	    width: 70%;
	    height: 100%;
	    float: left;
	}
</style>
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
	<a class="navbar-tit center-block">用户签到</a>
	<button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<br>
<div class="cash-userinfo">
	<div class="cash-user-header"><img src="<?php echo $user['avatar']; ?>"></div>
	<div class="cash-user-info">
		<div class="cash-user-detail cash-user-username"><span><?php echo $user['nickname']; ?></span></div>
		<div class="cash-user-detail"><span>积分：</span><span class="cash-user-money"><?php echo $user['score']; ?></span>分</div>
		<div class="cash-user-detail">
			<a href="javascript:;" class="btn btn-default pull-left btn-rank" style="margin-right:5px;">
                <i class="fa fa-trophy"></i>
                排行榜
            </a>
            <a href="javascript:;" class="btn btn-default pull-left btn-rule" style="margin-right:5px;">
                <i class="fa fa-question-circle"></i>
                签到积分规则
            </a>
			<a class="btn btn-success pull-left btn-signin <?php echo $signin?'disabled':''; ?>" href="javascript:;">
                <i class="fa fa-location-arrow"></i> <span><?php echo $signin?'已签到':'签到'; ?></span>
            </a>
		</div>
	</div>
</div>
<div class="panel-body" style="padding:0;">
    <div class="alert alert-warning-light" style="margin-bottom: 0px;">
        <?php if($signin): ?>
        你当前已经连续签到 <b style="color: #ff2626cf;"><?php echo $successions; ?></b> 天，明天继续签到可获得 <b style="color: #ff2626cf;"><?php echo $score; ?></b> 积分
        <?php else: ?>
        今天签到可获得 <b style="color: #ff2626cf;"><?php echo $score; ?></b> 积分，请点击签到领取积分
        <?php endif; ?>
    </div>
    <div class="calendar calendar3"></div>
    <?php echo $calendar->draw($date);; ?>
</div>
<script type="text/html" id="signintpl">
    <table class="table table-striped" style="margin-bottom:0;">
        <thead>
        <tr>
            <th>连续签到天数</th>
            <th>获得积分</th>
        </tr>
        </thead>
        <tbody>
        <?php if(is_array($signinscore) || $signinscore instanceof \think\Collection || $signinscore instanceof \think\Paginator): $i = 0; $__LIST__ = $signinscore;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <tr>
            <th scope="row">第<?php echo str_replace('s','',$key); ?>天</th>
            <td>+<?php echo $item; ?></td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
</script>
<script type="text/html" id="ranktpl">
    <div style="padding:20px;min-height:300px;">
        <table class="table table-striped table-hover signin-rank-table">
            <thead>
            <tr>
                <th>头像</th>
                <th width="50%">昵称</th>
                <th class="text-center">连续签到</th>
            </tr>
            </thead>
            <tbody>
            {{#  layui.each(d.list, function(index, item){ }}
			    <tr>
	                <td><a href="javascript:;"><img src="{{ item.user.avatar }}" height="30" width="30" alt="" class="img-circle"/></a></td>
	                <td><a href="javascript:;">{{ item.user.nickname }}</a></td>
	                <td class="text-center">{{ item.days }}天</td>
	            </tr>
			{{#  }); }}
           
            </tbody>
        </table>
    </div>
</script>
<script type="text/javascript">
	layui.use(['jquery','layer','laytpl'],function(){
		var $ = layui.jquery,layer = layui.layer,laytpl = layui.laytpl;
		var isMobile = !!("ontouchstart" in window);
	    $(document).on("click", ".btn-signin,.today", function () {
	        $.ajax({
	        	type:"POST",
	        	url:"/index/signin/dosign",
	        	success:function(datajson){
	        		layer.msg(datajson.msg);
	        		if (datajson.code) {
	        			setTimeout(function(){
	        				location.reload();
	        			},2500);
	        		}
	        	}
	        })
	        return false;
	    });
	    $(document).on("click", ".expired[data-date]:not(.today):not(.signed)", function () {
	        var that = this;
	        layer.confirm("确认进行补签日期：" + $(this).data("date") + "？<br>补签将消耗" + Config.fillupscore + " 积分", function () {
	        	$.ajax({
	        		type:"POST",
	        		url:"/index/signin/fillup?date=" + $(that).data("date"),
	        		success:function(datajson){
	        			layer.msg(datajson.msg);
		        		if (datajson.code) {
		        			setTimeout(function(){
		        				location.reload();
		        			},2500);
		        		}
		                return false;
	        		},
	        		error:function(XMLHttpRequest, textStatus, errorThrown){
	        			coco_close_loading();
		                var codetext = XMLHttpRequest.responseText;
		                codejson = eval("(" + codetext + ")");
		               	layer.msg(codejson.msg);
		            }	
	        	})
	        });
	        return false;
	    });
	    $(document).on("click", ".btn-rule", function () {
	        layer.open({
	            title: '签到积分规则',
	            content: Template("signintpl", {}),
	            btn: []
	        });
	        return false;
	    });
	    $(document).on("click", ".btn-rank", function () {
	    	$.ajax({
	    		url:"<?php echo url('index/signin/rank'); ?>",
	    		success:function(datajson){
	    			var string = laytpl($("#ranktpl").html()).render({
					    name: '签到排行榜',
					    list:datajson.data.ranklist
					});
	    			layer.open({
		                title: '签到排行榜',
		                type: 1,
		                zIndex: 88,
		                area: isMobile ? 'auto' : ["400px"],
		                content: string,
		                btn: []
		            });
		            return false;
	    		}
	    	})
	        return false;
	    });
	})
	
</script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>