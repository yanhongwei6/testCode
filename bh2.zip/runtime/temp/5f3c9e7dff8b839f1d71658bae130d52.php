<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:70:"D:\phpstudy_pro\WWW\bh\public/../application/admin\view\bets\edit.html";i:1575943939;s:65:"D:\phpstudy_pro\WWW\bh\application\admin\view\layout\default.html";i:1572536367;s:62:"D:\phpstudy_pro\WWW\bh\application\admin\view\common\meta.html";i:1572536366;s:64:"D:\phpstudy_pro\WWW\bh\application\admin\view\common\script.html";i:1572536366;}*/ ?>
<!DOCTYPE html>
<html lang="<?php echo $config['language']; ?>">
    <head>
        <meta charset="utf-8">
<title><?php echo (isset($title) && ($title !== '')?$title:''); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="renderer" content="webkit">

<link rel="shortcut icon" href="/assets/img/favicon.ico" />
<!-- Loading Bootstrap -->
<link href="/assets/css/backend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
  <script src="/assets/js/html5shiv.js"></script>
  <script src="/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    var require = {
        config:  <?php echo json_encode($config); ?>
    };
</script>
    </head>

    <body class="inside-header inside-aside <?php echo defined('IS_DIALOG') && IS_DIALOG ? 'is-dialog' : ''; ?>">
        <div id="main" role="main">
            <div class="tab-content tab-addtabs">
                <div id="content">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <section class="content-header hide">
                                <h1>
                                    <?php echo __('Dashboard'); ?>
                                    <small><?php echo __('Control panel'); ?></small>
                                </h1>
                            </section>
                            <?php if(!IS_DIALOG && !$config['fastadmin']['multiplenav']): ?>
                            <!-- RIBBON -->
                            <div id="ribbon">
                                <ol class="breadcrumb pull-left">
                                    <li><a href="dashboard" class="addtabsit"><i class="fa fa-dashboard"></i> <?php echo __('Dashboard'); ?></a></li>
                                </ol>
                                <ol class="breadcrumb pull-right">
                                    <?php foreach($breadcrumb as $vo): ?>
                                    <li><a href="javascript:;" data-url="<?php echo $vo['url']; ?>"><?php echo $vo['title']; ?></a></li>
                                    <?php endforeach; ?>
                                </ol>
                            </div>
                            <!-- END RIBBON -->
                            <?php endif; ?>
                            <div class="content">
                                <form id="edit-form" class="form-horizontal" role="form" data-toggle="validator" method="POST" action="">

    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Issue'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-issue" data-rule="required" class="form-control" name="row[issue]" type="text" value="<?php echo htmlentities($row['issue']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Userid'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-userid" data-rule="required" class="form-control" name="row[userid]" type="number" value="<?php echo htmlentities($row['userid']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Game'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-game" data-rule="required" class="form-control" name="row[game]" type="number" value="<?php echo htmlentities($row['game']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Bets'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-bets" data-rule="required" class="form-control" step="0.01" name="row[bets]" type="number" value="<?php echo htmlentities($row['bets']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Playtype'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-playtype" data-rule="required" class="form-control" name="row[playtype]" type="text" value="<?php echo htmlentities($row['playtype']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Winlose'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-winlose" data-rule="required" class="form-control" name="row[winlose]" type="text" value="<?php echo htmlentities($row['winlose']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Wlamount'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-wlamount" data-rule="required" class="form-control" step="0.01" name="row[wlamount]" type="number" value="<?php echo htmlentities($row['wlamount']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Status'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-status" data-rule="required" class="form-control" name="row[status]" type="text" value="<?php echo htmlentities($row['status']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Bettime'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-bettime" class="form-control datetimepicker" data-date-format="YYYY-MM-DD HH:mm:ss" data-use-current="true" name="row[bettime]" type="text" value="<?php echo $row['bettime']?datetime($row['bettime']):''; ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Opentime'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-opentime" class="form-control datetimepicker" data-date-format="YYYY-MM-DD HH:mm:ss" data-use-current="true" name="row[opentime]" type="text" value="<?php echo $row['opentime']?datetime($row['opentime']):''; ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Settledtime'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-settledtime" class="form-control datetimepicker" data-date-format="YYYY-MM-DD HH:mm:ss" data-use-current="true" name="row[settledtime]" type="text" value="<?php echo $row['settledtime']?datetime($row['settledtime']):''; ?>">
        </div>
    </div>
    <div class="form-group layer-footer">
        <label class="control-label col-xs-12 col-sm-2"></label>
        <div class="col-xs-12 col-sm-8">
            <button type="submit" class="btn btn-success btn-embossed disabled"><?php echo __('OK'); ?></button>
            <button type="reset" class="btn btn-default btn-embossed"><?php echo __('Reset'); ?></button>
        </div>
    </div>
</form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-backend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
    </body>
</html>