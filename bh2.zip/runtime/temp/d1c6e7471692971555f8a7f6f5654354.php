<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"D:\phpstudy_pro\WWW\bh\addons\signin\view\hook\user_sidenav_after.html";i:1575946367;}*/ ?>
<ul class="list-group">
    <li class="list-group-item <?php echo $controllername =='signin'?'active':''; ?>"><a href="<?php echo url('index/signin/index'); ?>"><i class="fa fa-map-signs fa-fw"></i> <?php echo __('每日签到'); ?></a></li>
</ul>