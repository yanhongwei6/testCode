<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"D:\phpstudy_pro\WWW\bh\addons\invite\view\hook\user_sidenav_after.html";i:1575946239;}*/ ?>
<ul class="list-group">
    <li class="list-group-item <?php echo $controllername=='invite'&&$actionname=='index'?'active':''; ?>"><a href="<?php echo url('index/invite/index'); ?>"><i class="fa fa-users fa-fw"></i> <?php echo __('邀请好友'); ?></a></li>
</ul>