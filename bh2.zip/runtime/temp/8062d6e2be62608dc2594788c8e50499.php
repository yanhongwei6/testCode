<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:77:"D:\phpstudy_pro\WWW\bh\public/../application/census\view\tencent\zhanshi.html";i:1579178738;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\layout\default.html";i:1579178611;s:66:"D:\phpstudy_pro\WWW\bh\application\census\view\common\tenmenu.html";i:1579178780;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>首页</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/style.css">
    <link rel="stylesheet" type="text/css" href="/assets/static/css/responsive.css">
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 header-top">
                    <img src="http://www.77tj.org/assets/images/logo.png" class="logo" alt="亿豪统计">
                </div>
                <div class="col-md-8 header-top header-top-menu">
                    <span>
                        <a href="<?php echo url('qqchat/index'); ?>" class="active">QQ在线统计</a>
                        <a href="<?php echo url('tencent/index'); ?>">腾讯在线统计</a>
                        <a href="<?php echo url('calculus/index'); ?>">数据演算</a>
                    </span>
                </div>
            </div>
        </div>
        <div class="header-top-image">
            <div>
                <p><img alt="" src="http://www.77tj.org/assets/images/time.png">2020-01-08 15:45:00&nbsp;&nbsp; 腾讯同时在线人数</p>
                <p><strong>314,415,591</strong>历史最高：335,684,644</p>
                <span>所有数据均来自腾讯</span>
            </div>
        </div>
        <div class="container">
	<div class="row container-content">
        <div class="col-md-2">
 	<a href="<?php echo url('tencent/index'); ?>" class="<?php echo $active['index']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon1.png">统计结果</a>
    <a href="<?php echo url('tencent/show'); ?>" class="<?php echo $active['show']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon2.png">动态展示</a>
    <a href="<?php echo url('tencent/explain'); ?>" class="<?php echo $active['explain']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon3.png">统计说明</a>
    <a href="<?php echo url('tencent/interface'); ?>" class="<?php echo $active['interface']; ?>"><img alt="" src="http://www.77tj.org/assets/images/icon4.png">接口调用</a>
</div>
        <div class="col-md-10">
         	<div style="height:42px; font-weight:bolder; color:red;">
			    腾讯QQ中国在线人数区域分布图，仅供参考。
			</div>
			<object width="960" height="740" id="flashBox" data="https://im.qq.com/online/flash/flash20140304.swf" type="application/x-shockwave-flash" style="visibility: visible;"></object>
        </div>
    </div>
</div>
        <div class="footer">
            <p>Copyright © 1998- 2016 HuaQi. All Rights Reserved.</p>
            <p>华旗公司 版权所有</p>
        </div>
        <script type="text/javascript" scr="/assets/static/js/jquery.3.4.1.js"></script>
    </body>
</html>