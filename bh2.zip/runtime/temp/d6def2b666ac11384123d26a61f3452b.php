<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:74:"D:\phpstudy_pro\WWW\bh\public/../application/index\view\center\invite.html";i:1577864985;s:71:"D:\phpstudy_pro\WWW\bh\application\index\view\layout\center_layout.html";i:1577517220;s:64:"D:\phpstudy_pro\WWW\bh\application\index\view\common\script.html";i:1572536367;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="keywords" content="">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	    <meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="">
		<link rel="stylesheet" type="text/css" href="/static/css/font_1459473269_4751618.css">
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="/static/css/style.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/layui/css/layui.css">
	  	<link rel="stylesheet" type="text/css" href="/static/css/menu_elastic.css">
	  	<script src="/wap/js/jquery.min.js"></script>
	  	<script src="/static/js/bootstrap.min.js"></script>
	  	<script src="/static/js/snap.svg-min.js"></script>
	  	<script src="/layer/layer/layer.js"></script>
  		<script src="/layui/layui/layui.js"></script>
  		<script src="/wap/js/coco3gNativeUser.js"></script>
	  	<script src="/wap/js/config.js"></script>
	  	<script src="/wap/js/base_app.js?v=182"></script>
	  	<script src="/wap/js/common.js"></script>
	<!--[if IE]>
	<script src="js/html5.js"></script>
	<![endif]-->
	</head>
	<body class="huibg" style="">
		<!-- <div class="menu-wrap">
   <nav class="menu">
      <div class="icon-list">
         <a href="index.html"><i class="iconfont icon-home"></i><span>首页</span></a>
         <a href="personalcenter.html"><i class="iconfont icon-yonghux"></i><span>个人中心</span></a>
         <a href="ddcenter.html"><i class="iconfont icon-liebiao"></i><span>订单中心</span></a>
         <a href="userinfo.html"><i class="iconfont icon-xitongmingpian"></i><span>个人信息</span></a>
         <a href="dizhi.html"><i class="iconfont icon-dizhi"></i><span>地址信息</span></a>
      </div>
   </nav>
   <button class="close-button" id="close-button">Close Menu</button>
	<div class="morph-shape" id="morph-shape" data-morph-open="M-1,0h101c0,0,0-1,0,395c0,404,0,405,0,405H-1V0z">
		<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100 800" preserveAspectRatio="none">
			<path d="M-1,0h101c0,0-97.833,153.603-97.833,396.167C2.167,627.579,100,800,100,800H-1V0z"></path>
		<desc>Created with Snap</desc><defs></defs></svg>
	</div>
</div> -->
<style type="text/css">
	.bind-bank-content{
		width: 98%;
		margin: auto;
		padding: 10px 5px;
	}
	.cash-user-info {
	    width: 70%;
	    height: 100%;
	    float: left;
	}
	.invite-qrcode{
		width: 98%;
		height: 250px;
		margin: auto;
		background: #fff;
		display: flex;
	}
	.invite-qrcode-div{
		width: 200px;
		height: 200px;
		margin: auto;
	}
	.invite-extend-div{
		position: fixed;
		width: 100%;
		top: 0;
		bottom: 0;
		background: rgba(0,0,0,0.5);
    	z-index: 999;
    	display: flex;
	    justify-content: center;
	    align-items: center;
	}
	.extend-qrcodeimg{
		cursor: pointer;
	}
</style>
<nav class="navbar text-center">
   <button class="topleft" onclick="javascript:history.go(-1);"><span class="iconfont icon-fanhui"></span></button>
	<a class="navbar-tit center-block">提现</a>
	<button class="topnav" id="open-button"><span class="iconfont icon-1"></span></button>
</nav>
<br>
<div class="cash-userinfo">
	<div class="cash-user-header"><img src="<?php echo $user['avatar']; ?>"></div>
	<div class="cash-user-info">
		<div class="cash-user-detail cash-user-username"><span><?php echo $user['nickname']; ?></span></div>
		<div class="cash-user-detail"><span>团队人数：</span><span class="cash-user-money"><?php echo $user['score']; ?></span>人</div>
		<div class="cash-user-detail">
			<a href="javascript:;" class="btn cash-btn-record invete-btn-record">邀请记录</a>
		</div>
	</div>
</div>
<div>
	<div class="alert alert-warning-light" style="margin-bottom: 5px;">
        <div class="row">
            <div class="col-md-12">
                <p>你可以将你的邀请链接发送给你的朋友，邀请TA的加入，注册成功后你将获得 <b><?php echo $inviteConfig['rewardscore']; ?></b> 积分，TA获得 <b><?php echo $inviteConfig['invitedscore']; ?></b> 积分</p>
                <div class="input-group input-group-md">
                    <div class="icon-addon addon-md">
                        <input type="text" placeholder="邀请链接" onfocus="this.select();" value="<?php echo addon_url('invite/index/index',[':id'=>$user['id']],false,true); ?>" class="form-control input-md clipboard-img">
                    </div>
                    <span class="input-group-btn">
                        <button class="btn btn-success btn-invite clipboard" type="button" data-clipboard-text="<?php echo addon_url('invite/index/index',[':id'=>$user['id']],false,true); ?>">复制链接</button>
                    </span>
                    
                </div>

            </div>
        </div>
    </div>
</div>
<div class="invite-qrcode">
	<div class="invite-qrcode-div">
		<img src="" alt="" id='qrcodeimg' style="width: 100%;height: 100%;" />
	</div>
</div>
<div class="invite-extend-div" style="display: none;">
	<div class="invite-extend-show">
		<img src="" style="width: 100%;height: 100%;" class="extend-qrcodeimg">
	</div>
</div>
<script type="text/html">
	
</script>
<script type="text/javascript" charset="utf-8">			
	$(function(){
        var text = $(".clipboard-img").val();
        $("#qrcodeimg").prop("src", "<?php echo addon_url('qrcode/index/build',[],false); ?>?" + 'text='+text);
    })
</script>
<script language="javascript">
	var timeOutEvent=0;
	$(function(){
		$(".invite-extend-show").on({
			touchstart: function(e){
				timeOutEvent = setTimeout("longPress()",500);
				e.preventDefault();
			},
			touchmove: function(){
				clearTimeout(timeOutEvent);
				timeOutEvent = 0;
			},
			touchend: function(){
				clearTimeout(timeOutEvent);
				if(timeOutEvent!=0){
				// alert("你这是点击，不是长按");
				}
				return false;
			}
		})
	});
	function longPress(){
		coco_confirm('是否下载二维码？',function(){
			timeOutEvent = 0;
			var src =$(".extend-qrcodeimg").attr("src");
			var arr=src.split(".");
			downloadIamge('.extend-qrcodeimg','invite_qrcode'+arr[1]+'.jpg');
		},'',function(){
			coco_msg('已取消下载');
			$(".invite-extend-div").hide();
		});
	}
	function downloadIamge(selector, name) {
		// 通过选择器获取img元素
		var img = document.querySelector(selector);
		// 将图片的src属性作为URL地址
		var url = img.src;
		var a = document.createElement('a');
		var event = new MouseEvent('click');
		a.download = name || '下载图片名称';
		a.href = url;
		a.dispatchEvent(event);
	}
</script>
	<script src="/static/js/classie.js"></script>
	<script type="text/javascript">
		var require = {
	        config: <?php echo json_encode($config); ?>
	    };
	</script>
	<script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-frontend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
	<!-- <script src="/static/js/main3.js"></script> -->
	</body>
</html>