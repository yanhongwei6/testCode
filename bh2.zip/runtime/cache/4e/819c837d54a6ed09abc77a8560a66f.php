<?php
//000000000000
 exit();?>
a:7:{s:8:"sms_send";a:1:{i:0;s:19:"\addons\clsms\Clsms";}s:10:"sms_notice";a:1:{i:0;s:19:"\addons\clsms\Clsms";}s:9:"sms_check";a:1:{i:0;s:19:"\addons\clsms\Clsms";}s:18:"user_sidenav_after";a:4:{i:0;s:21:"\addons\invite\Invite";i:1;s:25:"\addons\recharge\Recharge";i:2;s:21:"\addons\signin\Signin";i:3;s:25:"\addons\withdraw\Withdraw";}s:23:"user_register_successed";a:1:{i:0;s:21:"\addons\invite\Invite";}s:16:"admin_login_init";a:1:{i:0;s:23:"\addons\loginbg\Loginbg";}s:12:"upload_after";a:1:{i:0;s:19:"\addons\thumb\Thumb";}}